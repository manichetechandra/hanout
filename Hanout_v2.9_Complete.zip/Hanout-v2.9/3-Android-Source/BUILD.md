# 🔨 بناء حانوت v2.0

## ⚠️ قبل البناء — تعديلان إلزاميان
افتح `app/src/main/assets/app.js` وغيّر:
1. `SELLER.phone` → رقم واتسابك
2. `SALT` → قيمة سرية خاصة بك (وغيّرها بنفسها في `أدوات_البائع/keygen.html`)

## البناء
```bash
export JAVA_HOME=~/jdk17
export ANDROID_HOME=~/android-sdk
cp local.properties.example local.properties   # وعدّل المسار
~/gradle-8.7/bin/gradle assembleDebug --no-daemon
```
المخرَج: `app/build/outputs/apk/debug/app-debug.apk`

📘 الشرح الكامل في `دليل_البناء/` · 💼 دليل البيع في `أدوات_البائع/`
