# حافظ على الجسر — وإلا انهار التطبيق في نسخة release
-keepclassmembers class dz.hanout.pos.MainActivity$Bridge {
   public *;
}
-keepattributes JavascriptInterface
-keep class * implements android.webkit.JavascriptInterface { *; }
