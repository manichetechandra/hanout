package dz.hanout.pos;

import android.content.res.AssetManager;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

/** خادم HTTP محلي — الكاميرا محظورة على file:// ومسموحة على localhost */
public class AssetServer extends Thread {

    private final AssetManager assets;
    private ServerSocket server;
    private int port = -1;
    private volatile boolean running = true;

    public AssetServer(AssetManager assets) {
        this.assets = assets;
        setDaemon(true);   // يموت تلقائياً مع التطبيق
    }

    /** يجرّب عدة منافذ — إن كانت مشغولة يطلب أي منفذ حر (0) */
    public int startServer() {
        int[] tryPorts = {8731, 8732, 8733, 8734, 0};
        for (int p : tryPorts) {
            try {
                server = new ServerSocket(p, 8, InetAddress.getByName("127.0.0.1"));
                port = server.getLocalPort();
                start();
                return port;
            } catch (Exception ignored) { }
        }
        return -1;
    }

    public void stopServer() {
        running = false;
        try { if (server != null) server.close(); } catch (Exception ignored) { }
    }

    @Override
    public void run() {
        while (running) {
            Socket sock = null;
            try {
                sock = server.accept();     // انتظر طلباً
                handle(sock);
            } catch (Exception ignored) {
            } finally {
                try { if (sock != null) sock.close(); } catch (Exception ignored) { }
            }
        }
    }

    private void handle(Socket sock) throws Exception {
        BufferedReader in = new BufferedReader(
                new InputStreamReader(sock.getInputStream(), "UTF-8"), 8192);

        // قراءة أول سطر:  GET /app.js HTTP/1.1
        String line = in.readLine();
        if (line == null) return;
        String[] parts = line.split(" ");
        if (parts.length < 2) return;

        String path = parts[1];
        int q = path.indexOf('?');
        if (q >= 0) path = path.substring(0, q);          // احذف ?query
        if (path.equals("/") || path.isEmpty()) path = "/index.html";
        if (path.startsWith("/")) path = path.substring(1);
        if (path.contains("..")) path = "index.html";      // 🔒 حماية أمنية

        OutputStream out = sock.getOutputStream();
        try {
            InputStream is = assets.open(path);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
            is.close();
            byte[] data = bos.toByteArray();

            String head = "HTTP/1.1 200 OK\r\n"
                    + "Content-Type: " + mime(path) + "\r\n"
                    + "Content-Length: " + data.length + "\r\n"
                    + "Cache-Control: no-cache\r\n"
                    + "Connection: close\r\n\r\n";
            out.write(head.getBytes("UTF-8"));
            out.write(data);
        } catch (Exception e) {
            byte[] body = "404".getBytes("UTF-8");
            out.write(("HTTP/1.1 404 Not Found\r\nContent-Length: " + body.length
                    + "\r\nConnection: close\r\n\r\n").getBytes("UTF-8"));
            out.write(body);
        }
        out.flush();
    }

    private String mime(String p) {
        String lp = p.toLowerCase();
        if (lp.endsWith(".html")) return "text/html; charset=utf-8";
        if (lp.endsWith(".js"))   return "application/javascript; charset=utf-8";
        if (lp.endsWith(".css"))  return "text/css; charset=utf-8";
        if (lp.endsWith(".json")) return "application/json; charset=utf-8";
        if (lp.endsWith(".png"))  return "image/png";
        if (lp.endsWith(".jpg") || lp.endsWith(".jpeg")) return "image/jpeg";
        if (lp.endsWith(".svg"))  return "image/svg+xml";
        return "application/octet-stream";
    }
}
