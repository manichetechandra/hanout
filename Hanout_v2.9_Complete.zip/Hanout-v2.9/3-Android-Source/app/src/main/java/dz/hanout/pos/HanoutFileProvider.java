package dz.hanout.pos;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;

/**
 * مزوّد ملفات بسيط بديل عن androidx FileProvider.
 * يسمح بمشاركة الملفات مع التطبيقات الأخرى على أندرويد 7+ (بلا FileUriExposedException).
 */
public class HanoutFileProvider extends ContentProvider {

    private static final String AUTH_SUFFIX = ".fp";

    public static Uri getUriForFile(Context ctx, String authority, File file) {
        String name = file.getName();
        String sub = file.getParentFile() != null ? file.getParentFile().getName() : "share";
        return Uri.parse("content://" + authority + "/" + sub + "/" + Uri.encode(name));
    }

    private File resolve(Uri uri) {
        String path = uri.getPath();
        if (path == null) return null;
        if (path.startsWith("/")) path = path.substring(1);
        int slash = path.indexOf('/');
        if (slash < 0) return null;
        String sub = path.substring(0, slash);
        String name = Uri.decode(path.substring(slash + 1));
        if (name.contains("..") || sub.contains("..")) return null;
        File base = getContext().getExternalFilesDir(null);
        return new File(new File(base, sub), name);
    }

    @Override
    public boolean onCreate() { return true; }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) {
        File f = resolve(uri);
        if (f == null || !f.exists()) return null;
        try {
            return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        File f = resolve(uri);
        if (f == null || !f.exists()) return null;
        String[] cols = { OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE };
        MatrixCursor c = new MatrixCursor(cols, 1);
        c.addRow(new Object[]{ f.getName(), f.length() });
        return c;
    }

    @Override
    public String getType(Uri uri) {
        String n = uri.toString().toLowerCase();
        if (n.endsWith(".json")) return "application/json";
        if (n.endsWith(".csv")) return "text/csv";
        if (n.endsWith(".txt")) return "text/plain";
        return "application/octet-stream";
    }

    @Override public Uri insert(Uri uri, ContentValues values) { return null; }
    @Override public int delete(Uri uri, String s, String[] a) { return 0; }
    @Override public int update(Uri uri, ContentValues v, String s, String[] a) { return 0; }
}
