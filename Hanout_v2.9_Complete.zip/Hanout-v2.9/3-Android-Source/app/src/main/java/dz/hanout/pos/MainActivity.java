package dz.hanout.pos;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {

    private WebView web;
    private PermissionRequest pendingReq;
    private AssetServer srv;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingPickTarget = "";
    private static final int REQ_CAMERA = 101;
    private static final int REQ_BT = 102;
    private static final int REQ_FILE = 201;
    private static final int REQ_PICK_JSON = 202;
    private static final int REQ_PICK_CSV = 203;
    private static final int REQ_SAVE_DOC = 204;
    private static final UUID SPP_UUID =
            UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private String pendingSaveName = "";
    private String pendingSaveData = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);

        if (Build.VERSION.SDK_INT >= 19) WebView.setWebContentsDebuggingEnabled(true);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        if (Build.VERSION.SDK_INT >= 17) s.setMediaPlaybackRequiresUserGesture(false);

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    public void run() {
                        boolean wantsCam = false;
                        for (String r : request.getResources()) {
                            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) wantsCam = true;
                        }
                        if (!wantsCam) { request.deny(); return; }
                        if (hasCam()) {
                            request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                        } else {
                            pendingReq = request;
                            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
                        }
                    }
                });
            }

            /** يفعّل <input type="file"> داخل WebView */
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                try {
                    Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    startActivityForResult(Intent.createChooser(i, "اختر ملفاً"), REQ_FILE);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    ui("تعذّر فتح مدير الملفات");
                    return false;
                }
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage cm) { return true; }
        });

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                return handleExternal(url);
            }

            @Override
            @android.annotation.TargetApi(24)
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                return handleExternal(req.getUrl().toString());
            }

            private boolean handleExternal(String url) {
                if (url == null) return false;
                if (url.startsWith("http://127.0.0.1") || url.startsWith("file://")) return false;
                if (url.startsWith("data:") || url.startsWith("blob:")) return false;
                openExternal(url);
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "Android");

        if (!hasCam()) requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);

        srv = new AssetServer(getAssets());
        int port = srv.startServer();
        if (port > 0) web.loadUrl("http://127.0.0.1:" + port + "/index.html");
        else web.loadUrl("file:///android_asset/index.html");
    }

    private void openExternal(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            ui("لا يوجد تطبيق لفتح هذا الرابط");
        } catch (Exception e) {
            ui("تعذّر فتح الرابط");
        }
    }

    private boolean hasCam() {
        if (Build.VERSION.SDK_INT < 23) return true;
        return checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasBt() {
        if (Build.VERSION.SDK_INT < 31) return true;
        return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        if (code == REQ_CAMERA) {
            boolean ok = res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED;
            if (pendingReq != null) {
                if (ok) pendingReq.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                else pendingReq.deny();
                pendingReq = null;
            }
            if (!ok) ui("تم رفض إذن الكاميرا — فعّله من إعدادات التطبيق");
        }
    }

    /** استقبال نتائج اختيار/حفظ الملفات */
    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);

        if (req == REQ_FILE) {
            if (filePathCallback == null) return;
            Uri[] out = null;
            if (res == RESULT_OK && data != null && data.getData() != null) {
                out = new Uri[]{data.getData()};
            }
            filePathCallback.onReceiveValue(out);
            filePathCallback = null;
            return;
        }

        if (req == REQ_PICK_JSON || req == REQ_PICK_CSV) {
            if (res != RESULT_OK || data == null || data.getData() == null) {
                jsCall("window._fileCancel && window._fileCancel()");
                return;
            }
            final Uri uri = data.getData();
            final String target = (req == REQ_PICK_JSON) ? "json" : "csv";
            new Thread(new Runnable() {
                public void run() {
                    try {
                        InputStream is = getContentResolver().openInputStream(uri);
                        ByteArrayOutputStream bos = new ByteArrayOutputStream();
                        byte[] buf = new byte[8192];
                        int n;
                        while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
                        is.close();
                        String content = new String(bos.toByteArray(), "UTF-8");
                        if (content.length() > 0 && content.charAt(0) == '\uFEFF')
                            content = content.substring(1);
                        final String payload = content;
                        runOnUiThread(new Runnable() {
                            public void run() {
                                jsCall("window._fileLoaded && window._fileLoaded('" + target
                                        + "', " + jsQuote(payload) + ")");
                            }
                        });
                    } catch (final Exception e) {
                        runOnUiThread(new Runnable() {
                            public void run() {
                                ui("تعذّرت قراءة الملف: " + e.getMessage());
                                jsCall("window._fileCancel && window._fileCancel()");
                            }
                        });
                    }
                }
            }).start();
            return;
        }

        if (req == REQ_SAVE_DOC) {
            if (res != RESULT_OK || data == null || data.getData() == null) {
                jsCall("window._saveCancel && window._saveCancel()");
                return;
            }
            try {
                OutputStream os = getContentResolver().openOutputStream(data.getData());
                os.write(pendingSaveData.getBytes("UTF-8"));
                os.flush();
                os.close();
                ui("✅ حُفظ الملف: " + pendingSaveName);
                jsCall("window._saveDone && window._saveDone('" + jsEsc(pendingSaveName) + "')");
            } catch (Exception e) {
                ui("فشل الحفظ: " + e.getMessage());
                jsCall("window._saveCancel && window._saveCancel()");
            }
            pendingSaveData = "";
        }
    }

    private void jsCall(final String code) {
        runOnUiThread(new Runnable() {
            public void run() {
                if (Build.VERSION.SDK_INT >= 19) web.evaluateJavascript(code, null);
                else web.loadUrl("javascript:" + code);
            }
        });
    }

    private static String jsEsc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("'", "\\'")
                .replace("\n", "\\n").replace("\r", "");
    }

    /** يحوّل نصاً إلى سلسلة JS آمنة */
    private static String jsQuote(String s) {
        StringBuilder sb = new StringBuilder("'");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '\\': sb.append("\\\\"); break;
                case '\'': sb.append("\\'"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': break;
                case '\t': sb.append("\\t"); break;
                case '\u2028': sb.append("\\u2028"); break;
                case '\u2029': sb.append("\\u2029"); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
            }
        }
        return sb.append("'").toString();
    }

    @Override
    public void onBackPressed() {
        if (Build.VERSION.SDK_INT >= 19) {
            web.evaluateJavascript("window.onAndroidBack&&window.onAndroidBack()", value -> {
                if (value == null || "false".equals(value) || "null".equals(value)) {
                    MainActivity.super.onBackPressed();
                }
            });
        } else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (srv != null) srv.stopServer();
        super.onDestroy();
    }

    private void ui(final String m) {
        runOnUiThread(new Runnable() {
            public void run() { Toast.makeText(MainActivity.this, m, Toast.LENGTH_LONG).show(); }
        });
    }

    public class Bridge {

        @JavascriptInterface
        public void toast(final String m) {
            runOnUiThread(new Runnable() {
                public void run() { Toast.makeText(MainActivity.this, m, Toast.LENGTH_SHORT).show(); }
            });
        }

        @JavascriptInterface
        public boolean isAndroid() { return true; }

        /**
         * معرّف ثابت للجهاز — يبقى بعد حذف التطبيق وإعادة تثبيته.
         * ANDROID_ID فريد لكل (جهاز + مفتاح توقيع التطبيق)، ولا يتغيّر
         * إلا بإعادة ضبط المصنع. هذا يمنع الحصول على مفاتيح مجانية بالحذف.
         */
        @JavascriptInterface
        public String hwId() {
            StringBuilder sb = new StringBuilder();
            try {
                String aid = Settings.Secure.getString(getContentResolver(),
                        Settings.Secure.ANDROID_ID);
                if (aid != null && !aid.isEmpty() && !"9774d56d682e549c".equals(aid)) {
                    sb.append(aid);
                }
            } catch (Exception ignored) { }
            // تدعيم بخصائص العتاد (تبقى ثابتة أيضاً)
            try {
                sb.append('|').append(Build.BOARD).append(Build.BRAND)
                  .append(Build.DEVICE).append(Build.MODEL)
                  .append(Build.MANUFACTURER).append(Build.HARDWARE);
            } catch (Exception ignored) { }
            String raw = sb.toString();
            if (raw.length() < 4) return "";
            // تجزئة FNV-1a 64-bit → معرّف مقروء
            long h = 0xcbf29ce484222325L;
            for (int i = 0; i < raw.length(); i++) {
                h ^= raw.charAt(i);
                h *= 0x100000001b3L;
            }
            String out = Long.toString(Math.abs(h), 36).toUpperCase();
            while (out.length() < 10) out = "0" + out;
            return out.substring(0, 10);
        }

        /* ===================== الملفات ===================== */

        /** حفظ ملف في مجلد التنزيلات مباشرة — يعمل بلا أذونات على كل الإصدارات */
        @JavascriptInterface
        public String saveToDownloads(final String name, final String content) {
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
                    cv.put(MediaStore.Downloads.MIME_TYPE, guessMime(name));
                    cv.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri uri = getContentResolver().insert(
                            MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    if (uri == null) return "";
                    OutputStream os = getContentResolver().openOutputStream(uri);
                    os.write(content.getBytes("UTF-8"));
                    os.flush(); os.close();
                    cv.clear();
                    cv.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(uri, cv, null, null);
                    ui("✅ حُفظ في التنزيلات: " + name);
                    return "Download/" + name;
                } else {
                    File dir = Environment.getExternalStoragePublicDirectory(
                            Environment.DIRECTORY_DOWNLOADS);
                    if (!dir.exists()) dir.mkdirs();
                    File f = new File(dir, name);
                    FileOutputStream o = new FileOutputStream(f);
                    o.write(content.getBytes("UTF-8"));
                    o.flush(); o.close();
                    ui("✅ حُفظ في التنزيلات: " + name);
                    return f.getAbsolutePath();
                }
            } catch (Exception e) {
                // احتياطي: احفظ داخل مساحة التطبيق
                try {
                    File f = new File(getExternalFilesDir(null), name);
                    FileOutputStream o = new FileOutputStream(f);
                    o.write(content.getBytes("UTF-8"));
                    o.flush(); o.close();
                    ui("✅ حُفظ في: " + f.getAbsolutePath());
                    return f.getAbsolutePath();
                } catch (Exception e2) {
                    ui("فشل الحفظ: " + e2.getMessage());
                    return "";
                }
            }
        }

        /** حفظ باسم — يفتح نافذة النظام ليختار المستخدم المكان */
        @JavascriptInterface
        public void saveAs(final String name, final String content) {
            pendingSaveName = name;
            pendingSaveData = content;
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        if (Build.VERSION.SDK_INT >= 19) {
                            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                            i.addCategory(Intent.CATEGORY_OPENABLE);
                            i.setType(guessMime(name));
                            i.putExtra(Intent.EXTRA_TITLE, name);
                            startActivityForResult(i, REQ_SAVE_DOC);
                        } else {
                            saveToDownloads(name, content);
                        }
                    } catch (Exception e) {
                        saveToDownloads(name, content);
                    }
                }
            });
        }

        /** فتح منتقي الملفات وقراءة المحتوى */
        @JavascriptInterface
        public void pickFile(final String kind) {
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType("*/*");
                        String[] mimes = "csv".equals(kind)
                                ? new String[]{"text/csv", "text/comma-separated-values",
                                               "text/plain", "application/vnd.ms-excel", "*/*"}
                                : new String[]{"application/json", "text/plain", "*/*"};
                        i.putExtra(Intent.EXTRA_MIME_TYPES, mimes);
                        startActivityForResult(Intent.createChooser(i,
                                "csv".equals(kind) ? "اختر ملف CSV" : "اختر ملف النسخة الاحتياطية"),
                                "csv".equals(kind) ? REQ_PICK_CSV : REQ_PICK_JSON);
                    } catch (Exception e) {
                        ui("تعذّر فتح مدير الملفات");
                        jsCall("window._fileCancel && window._fileCancel()");
                    }
                }
            });
        }

        /** مشاركة ملف (واتساب، بريد، درايف...) */
        @JavascriptInterface
        public void shareFile(final String name, final String content) {
            new Thread(new Runnable() {
                public void run() {
                    try {
                        File dir = new File(getExternalFilesDir(null), "share");
                        if (!dir.exists()) dir.mkdirs();
                        final File f = new File(dir, name);
                        FileOutputStream o = new FileOutputStream(f);
                        o.write(content.getBytes("UTF-8"));
                        o.flush(); o.close();
                        final Uri uri = androidx_FileProvider(f);
                        runOnUiThread(new Runnable() {
                            public void run() {
                                try {
                                    Intent sh = new Intent(Intent.ACTION_SEND);
                                    sh.setType(guessMime(name));
                                    sh.putExtra(Intent.EXTRA_STREAM, uri);
                                    sh.putExtra(Intent.EXTRA_SUBJECT, name);
                                    sh.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                    startActivity(Intent.createChooser(sh, "مشاركة " + name)
                                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                                } catch (Exception e) {
                                    ui("تعذّرت المشاركة: " + e.getMessage());
                                }
                            }
                        });
                    } catch (Exception e) {
                        ui("فشل تجهيز الملف: " + e.getMessage());
                    }
                }
            }).start();
        }

        /** قائمة النسخ الاحتياطية المحفوظة داخل التطبيق */
        @JavascriptInterface
        public String listBackups() {
            try {
                File dir = new File(getExternalFilesDir(null), "backups");
                if (!dir.exists()) return "[]";
                File[] fs = dir.listFiles();
                if (fs == null) return "[]";
                StringBuilder sb = new StringBuilder("[");
                boolean first = true;
                for (File f : fs) {
                    if (!f.isFile()) continue;
                    if (!first) sb.append(",");
                    sb.append("{\"name\":\"").append(jsEsc(f.getName()))
                      .append("\",\"size\":").append(f.length())
                      .append(",\"time\":").append(f.lastModified()).append("}");
                    first = false;
                }
                return sb.append("]").toString();
            } catch (Exception e) { return "[]"; }
        }

        /** نسخة احتياطية داخلية (تلقائية) */
        @JavascriptInterface
        public boolean saveInternal(String name, String content) {
            try {
                File dir = new File(getExternalFilesDir(null), "backups");
                if (!dir.exists()) dir.mkdirs();
                File f = new File(dir, name);
                FileOutputStream o = new FileOutputStream(f);
                o.write(content.getBytes("UTF-8"));
                o.flush(); o.close();
                // احتفظ بآخر 5 نسخ فقط
                File[] fs = dir.listFiles();
                if (fs != null && fs.length > 5) {
                    java.util.Arrays.sort(fs, (x, y) ->
                            Long.compare(x.lastModified(), y.lastModified()));
                    for (int i = 0; i < fs.length - 5; i++) fs[i].delete();
                }
                return true;
            } catch (Exception e) { return false; }
        }

        @JavascriptInterface
        public String readInternal(String name) {
            try {
                File f = new File(new File(getExternalFilesDir(null), "backups"), name);
                if (!f.exists()) return "";
                byte[] b = new byte[(int) f.length()];
                java.io.FileInputStream i = new java.io.FileInputStream(f);
                i.read(b); i.close();
                return new String(b, "UTF-8");
            } catch (Exception e) { return ""; }
        }

        /* ===================== واتساب ومشاركة ===================== */

        @JavascriptInterface
        public void openWhatsApp(final String phone, final String msg) {
            runOnUiThread(new Runnable() {
                public void run() {
                    String[] pkgs = {"com.whatsapp", "com.whatsapp.w4b"};
                    Uri uri = Uri.parse("https://api.whatsapp.com/send?phone=" + phone
                            + "&text=" + Uri.encode(msg));
                    for (String p : pkgs) {
                        try {
                            Intent i = new Intent(Intent.ACTION_VIEW, uri);
                            i.setPackage(p);
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(i);
                            return;
                        } catch (Exception ignored) { }
                    }
                    try {
                        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/"
                                + phone + "?text=" + Uri.encode(msg)));
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);
                        return;
                    } catch (Exception ignored) { }
                    try {
                        Intent sh = new Intent(Intent.ACTION_SEND);
                        sh.setType("text/plain");
                        sh.putExtra(Intent.EXTRA_TEXT, msg);
                        sh.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(Intent.createChooser(sh, "إرسال التذكير")
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (Exception e) {
                        ui("واتساب غير مثبّت على الجهاز");
                    }
                }
            });
        }

        @JavascriptInterface
        public void openUrl(final String url) {
            runOnUiThread(new Runnable() {
                public void run() { openExternal(url); }
            });
        }

        @JavascriptInterface
        public void shareText(final String text) {
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        Intent sh = new Intent(Intent.ACTION_SEND);
                        sh.setType("text/plain");
                        sh.putExtra(Intent.EXTRA_TEXT, text);
                        startActivity(Intent.createChooser(sh, "مشاركة")
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (Exception e) { ui("تعذّرت المشاركة"); }
                }
            });
        }

        /* ===================== الطباعة ===================== */

        @JavascriptInterface
        public void printReceipt(final String html) {
            runOnUiThread(new Runnable() {
                public void run() {
                    if (Build.VERSION.SDK_INT < 19) { ui("الطباعة تتطلب أندرويد 4.4+"); return; }
                    final WebView pw = new WebView(MainActivity.this);
                    pw.setWebViewClient(new WebViewClient() {
                        @Override
                        public void onPageFinished(WebView v, String u) {
                            PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                            PrintAttributes attrs = new PrintAttributes.Builder()
                                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                    .build();
                            pm.print("Hanout_Facture",
                                    v.createPrintDocumentAdapter("Hanout_Facture"), attrs);
                        }
                    });
                    pw.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
                }
            });
        }

        @JavascriptInterface
        public String listPrinters() {
            try {
                if (!hasBt()) return "[]";
                BluetoothAdapter a = BluetoothAdapter.getDefaultAdapter();
                if (a == null || !a.isEnabled()) return "[]";
                Set<BluetoothDevice> devs = a.getBondedDevices();
                StringBuilder sb = new StringBuilder("[");
                boolean first = true;
                for (BluetoothDevice d : devs) {
                    if (!first) sb.append(",");
                    sb.append("{\"name\":\"").append(d.getName())
                      .append("\",\"mac\":\"").append(d.getAddress()).append("\"}");
                    first = false;
                }
                return sb.append("]").toString();
            } catch (Exception e) { return "[]"; }
        }

        @JavascriptInterface
        public void printThermal(final String mac, final String text) {
            new Thread(new Runnable() {
                public void run() {
                    BluetoothSocket sock = null;
                    try {
                        if (!hasBt()) {
                            if (Build.VERSION.SDK_INT >= 31) {
                                runOnUiThread(new Runnable() {
                                    public void run() {
                                        requestPermissions(new String[]{
                                                Manifest.permission.BLUETOOTH_CONNECT,
                                                Manifest.permission.BLUETOOTH_SCAN}, REQ_BT);
                                    }
                                });
                            }
                            return;
                        }
                        BluetoothAdapter a = BluetoothAdapter.getDefaultAdapter();
                        if (a == null || !a.isEnabled()) { ui("فعّل البلوتوث أولاً"); return; }
                        BluetoothDevice dev = a.getRemoteDevice(mac);
                        sock = dev.createRfcommSocketToServiceRecord(SPP_UUID);
                        a.cancelDiscovery();
                        sock.connect();
                        OutputStream o = sock.getOutputStream();
                        o.write(new byte[]{0x1B, 0x40});
                        o.write(new byte[]{0x1C, 0x26});
                        o.write(new byte[]{0x1B, 0x74, 0x16});
                        o.write(new byte[]{0x1B, 0x61, 0x01});
                        o.write(text.getBytes("UTF-8"));
                        o.write("\n\n\n".getBytes("UTF-8"));
                        o.write(new byte[]{0x1D, 0x56, 0x42, 0x00});
                        o.flush();
                        Thread.sleep(600);
                        ui("تمت الطباعة");
                    } catch (Exception e) {
                        ui("فشل الاتصال بالطابعة: " + e.getMessage());
                    } finally {
                        try { if (sock != null) sock.close(); } catch (Exception ignored) {}
                    }
                }
            }).start();
        }
    }

    /** FileProvider بلا AndroidX */
    private Uri androidx_FileProvider(File f) {
        try {
            return HanoutFileProvider.getUriForFile(this,
                    getPackageName() + ".fp", f);
        } catch (Exception e) {
            return Uri.fromFile(f);
        }
    }

    private static String guessMime(String name) {
        String n = name.toLowerCase();
        if (n.endsWith(".json")) return "application/json";
        if (n.endsWith(".csv")) return "text/csv";
        if (n.endsWith(".txt")) return "text/plain";
        if (n.endsWith(".pdf")) return "application/pdf";
        return "application/octet-stream";
    }
}
