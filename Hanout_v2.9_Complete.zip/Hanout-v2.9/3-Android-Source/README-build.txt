╔══════════════════════════════════════════════════════════╗
║        بناء تطبيق حانوت للأندرويد                        ║
╚══════════════════════════════════════════════════════════╝

  ما بداخل هذا المجلد؟
  ─────────────────────────────────────────────────────
  كل الكود المصدري للتطبيق. يمكنك تعديله وإعادة بنائه.

  app/src/main/assets/       ← الواجهة والمنطق
      index.html                 الشاشات
      app.css                    التصميم
      app.js                     كل المنطق (2900 سطر)
      lib/zxing.js               مكتبة الباركود

  app/src/main/java/dz/hanout/pos/
      MainActivity.java          الشاشة الرئيسية والجسر
      AssetServer.java           الخادم المحلي (للكاميرا)
      HanoutFileProvider.java    مشاركة الملفات

  app/src/main/AndroidManifest.xml   الأذونات
  app/build.gradle                   إعدادات البناء


  الأدوات المطلوبة (مرة واحدة)
  ─────────────────────────────────────────────────────
  1. JDK 17      من adoptium.net  →  ثبّته في C:\jdk17
  2. Android SDK من developer.android.com/studio#command-tools
                 →  C:\android-sdk\cmdline-tools\latest
  3. Gradle 8.7  من gradle.org/releases  →  C:\gradle-8.7

  الشرح الكامل بالصور في: دليل_بناء_حانوت.pdf (الباب 1)


  البناء
  ─────────────────────────────────────────────────────
  افتح PowerShell داخل هذا المجلد والصق:

      $env:JAVA_HOME="C:\jdk17"
      $env:ANDROID_HOME="C:\android-sdk"
      "sdk.dir=C\:\\android-sdk" | Out-File -Encoding ASCII local.properties
      C:\gradle-8.7\bin\gradle.bat assembleDebug --no-daemon

  المخرَج:
      app\build\outputs\apk\debug\app-debug.apk


  بناء نسخة البيع (موقّعة)
  ─────────────────────────────────────────────────────
  1. انسخ ملف hanout-release.jks إلى C:\
     (تجده في حزمة البائع)

  2. انسخ keystore.properties.example إلى keystore.properties
     وعدّل المسار وكلمة المرور

  3. شغّل:
      C:\gradle-8.7\bin\gradle.bat assembleRelease --no-daemon

  المخرَج:
      app\build\outputs\apk\release\app-release.apk


  تنبيهات
  ─────────────────────────────────────────────────────
  • إن فشل البناء بخطأ "Daemon disappeared":
    افتح gradle.properties وقلّل الرقم في -Xmx إلى 512m

  • SALT في app.js هو مفتاحك السري — لا تغيّره
    إلا إن غيّرته في keygen.html بنفس القيمة

  • لا ترفع keystore.properties على الأنترنت


  الدعم: 0699592820 — ميلود سوفت
