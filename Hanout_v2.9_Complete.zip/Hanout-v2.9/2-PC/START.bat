@echo off
chcp 65001 >nul 2>&1
title Hanout - Point of Sale
cd /d "%~dp0"

echo.
echo   ========================================
echo      HANOUT - Point of Sale
echo      Miloud Soft
echo   ========================================
echo.

if not exist "app\index.html" (
    echo   [ERROR] app\index.html not found!
    echo.
    echo   Make sure this file is inside the
    echo   hanout-pc folder next to the app folder.
    echo.
    pause
    exit /b 1
)

set PORT=8731

REM ---- Find Python ----
set PYCMD=
python --version >nul 2>&1 && set PYCMD=python
if not defined PYCMD py --version >nul 2>&1 && set PYCMD=py

if defined PYCMD goto :runserver

REM ---- Try Node ----
node --version >nul 2>&1 && goto :runnode

REM ---- No server: open directly ----
echo   [!] Python / Node.js not found.
echo.
echo   The app will open directly.
echo   Everything works EXCEPT the camera.
echo   USB barcode scanner works fine.
echo.
echo   To enable camera install Python:
echo   https://python.org  (check "Add to PATH")
echo.
timeout /t 5 /nobreak >nul
start "" "%~dp0app\index.html"
exit /b

:runnode
echo   [+] Starting server (Node.js)...
start "Hanout Server" /min node "%~dp0server.js"
goto :openapp

:runserver
echo   [+] Starting server (Python)...
start "Hanout Server" /min %PYCMD% -m http.server %PORT% --directory "%~dp0app" --bind 127.0.0.1

:openapp
timeout /t 3 /nobreak >nul
echo   [+] Opening app...
echo.
echo   ========================================
echo      RUNNING: http://127.0.0.1:%PORT%
echo.
echo      DO NOT CLOSE THIS WINDOW
echo   ========================================
echo.

set BROWSER=
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set BROWSER=%ProgramFiles%\Google\Chrome\Application\chrome.exe
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set BROWSER=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set BROWSER=%LocalAppData%\Google\Chrome\Application\chrome.exe
if not defined BROWSER if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set BROWSER=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe
if not defined BROWSER if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set BROWSER=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe

if defined BROWSER (
    start "" "%BROWSER%" --app=http://127.0.0.1:%PORT%/index.html --window-size=1280,860
) else (
    start "" http://127.0.0.1:%PORT%/index.html
)

echo   Press any key to STOP the app...
pause >nul
echo.
echo   [+] Stopping server...
taskkill /FI "WINDOWTITLE eq Hanout Server*" /T /F >nul 2>&1
exit /b
