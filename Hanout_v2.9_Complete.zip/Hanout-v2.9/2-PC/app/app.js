/* ============ حانوت — محرك التطبيق ============ */
const AND = (typeof Android !== 'undefined');
const DB = {
  get(k, d) { try { return JSON.parse(localStorage.getItem('hn_' + k)) ?? d; } catch (e) { return d; } },
  set(k, v) { localStorage.setItem('hn_' + k, JSON.stringify(v)); }
};
let CFG = DB.get('cfg', null);
let PRODS = DB.get('prods', []);
let CUSTS = DB.get('custs', []);
let SALES = DB.get('sales', []);
let CART = [];
let PRINTER = DB.get('printer', null);
let stF = 'all', repD = 7, lastSale = null, scanMode = '';
let saleCust = null;   // الزبون المرتبط بالفاتورة الحالية (اختياري)
let viewingOld = null; // معرّف الفاتورة القديمة المعروضة (null = بيع جديد)

const fmt = n => Math.round(n).toLocaleString('en-US');
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[<>&"]/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;' }[c]));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const today = () => new Date().toISOString().slice(0, 10);

/* save() معرّفة في وحدة v2.0 أدناه (نسخة آمنة) */
function tst(m) {
  const t = $('toast'); t.textContent = m; t.classList.add('on');
  clearTimeout(window._t); window._t = setTimeout(() => t.classList.remove('on'), 2400);
  if (AND) try { Android.toast(m); } catch (e) {}
}

/* ============================================================
   حانوت v2.0 — وحدة التخزين الآمن + التراخيص + الخدمات
   ============================================================ */

/* ---------- إعدادات البائع (غيّرها قبل البيع) ---------- */
const SELLER = {
  phone: '213699592820',       // رقم الدعم الفني (واتساب)
  name: 'حانوت — برامج تسيير المتاجر',
  priceP: 5000,                 // سعر PRO
  priceBundle: 25000,           // سعر الباقة الكاملة
  priceStock: 3000,             // إدخال المخزون
  priceSupport: 4000            // الدعم السنوي
};
const SALT = 'MLD-UxEO-Pp?PtS$x1%=91Ct-DZ26';  // ⚠️ غيّرها ولا تنشرها

/* ============ 1) التخزين الآمن ============ */
const QUOTA = 5 * 1024 * 1024;

function storageUsed() {
  let b = 0;
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith('hn_')) b += (k.length + (localStorage.getItem(k) || '').length) * 2;
    }
  } catch (e) {}
  return b;
}
function storagePct() { return storageUsed() / QUOTA * 100; }

let _quotaWarned = 0;
/* الحفظ الآمن — لا يفشل بصمت أبداً */
/* ============================================================
   v2.8 — IndexedDB للمبيعات (سعة ×20)
   المنتجات والزبائن يبقون في localStorage (صغار وسريعو القراءة)
   المبيعات تنتقل إلى IndexedDB (الكبيرة والمتراكمة)
   ============================================================ */

const IDB = {
  db: null,
  ready: false,
  failed: false,

  async open() {
    if (this.db) return this.db;
    if (this.failed) return null;
    return new Promise((res) => {
      try {
        if (!window.indexedDB) { this.failed = true; return res(null); }
        const r = indexedDB.open('hanout_db', 1);
        r.onupgradeneeded = e => {
          const db = e.target.result;
          if (!db.objectStoreNames.contains('sales')) {
            const st = db.createObjectStore('sales', { keyPath: 'id' });
            st.createIndex('date', 'date');
            st.createIndex('cust', 'cust');
          }
        };
        r.onsuccess = e => { this.db = e.target.result; this.ready = true; res(this.db); };
        r.onerror = () => { this.failed = true; res(null); };
        setTimeout(() => { if (!this.ready) { this.failed = true; res(null); } }, 4000);
      } catch (e) { this.failed = true; res(null); }
    });
  },

  async putMany(arr) {
    const db = await this.open();
    if (!db) return false;
    return new Promise((res) => {
      try {
        const tx = db.transaction('sales', 'readwrite');
        const st = tx.objectStore('sales');
        arr.forEach(s => st.put(s));
        tx.oncomplete = () => res(true);
        tx.onerror = () => res(false);
      } catch (e) { res(false); }
    });
  },

  async put(sale) { return this.putMany([sale]); },

  async del(id) {
    const db = await this.open();
    if (!db) return false;
    return new Promise(res => {
      try {
        const tx = db.transaction('sales', 'readwrite');
        tx.objectStore('sales').delete(id);
        tx.oncomplete = () => res(true);
        tx.onerror = () => res(false);
      } catch (e) { res(false); }
    });
  },

  async delMany(ids) {
    const db = await this.open();
    if (!db) return false;
    return new Promise(res => {
      try {
        const tx = db.transaction('sales', 'readwrite');
        const st = tx.objectStore('sales');
        ids.forEach(i => st.delete(i));
        tx.oncomplete = () => res(true);
        tx.onerror = () => res(false);
      } catch (e) { res(false); }
    });
  },

  async all() {
    const db = await this.open();
    if (!db) return null;
    return new Promise(res => {
      try {
        const out = [];
        const cur = db.transaction('sales').objectStore('sales').openCursor();
        cur.onsuccess = e => {
          const c = e.target.result;
          if (c) { out.push(c.value); c.continue(); }
          else { out.sort((a, b) => a.date < b.date ? -1 : 1); res(out); }
        };
        cur.onerror = () => res(null);
      } catch (e) { res(null); }
    });
  },

  async count() {
    const db = await this.open();
    if (!db) return 0;
    return new Promise(res => {
      try {
        db.transaction('sales').objectStore('sales').count().onsuccess =
          e => res(e.target.result);
      } catch (e) { res(0); }
    });
  },

  async clear() {
    const db = await this.open();
    if (!db) return false;
    return new Promise(res => {
      try {
        const tx = db.transaction('sales', 'readwrite');
        tx.objectStore('sales').clear();
        tx.oncomplete = () => res(true);
        tx.onerror = () => res(false);
      } catch (e) { res(false); }
    });
  }
};

/* هل نستعمل IndexedDB؟ */
let USE_IDB = false;

/* ============ الترحيل التلقائي ============ */
async function migrateToIDB() {
  if (DB.get('idbDone', false)) {
    USE_IDB = !IDB.failed;
    if (USE_IDB) {
      const loaded = await IDB.all();
      if (loaded) SALES = loaded;
    }
    return;
  }

  const db = await IDB.open();
  if (!db) { USE_IDB = false; return; }   // المتصفح لا يدعمه — نبقى على القديم

  const old = DB.get('sales', []);
  if (old.length) {
    const okk = await IDB.putMany(old);
    if (!okk) { USE_IDB = false; return; }
    // تحقق قبل الحذف
    const n = await IDB.count();
    if (n < old.length) { USE_IDB = false; return; }
    localStorage.removeItem('hn_sales');
  }
  DB.set('idbDone', true);
  USE_IDB = true;
  const loaded = await IDB.all();
  if (loaded) SALES = loaded;
}

/* ============ حفظ المبيعات ============ */
/* تُستدعى بعد أي تعديل على SALES */
function saveSales() {
  if (USE_IDB) {
    // نكتب فقط ما تغيّر — لكن للبساطة والأمان نكتب الكل
    IDB.putMany(SALES).catch(() => {});
    return true;
  }
  try { DB.set('sales', SALES); return true; }
  catch (e) {
    if (e && (e.name === 'QuotaExceededError' || e.code === 22)) quotaFull();
    return false;
  }
}

/* حفظ فاتورة واحدة (أسرع) */
function saveOneSale(s) {
  if (USE_IDB) { IDB.put(s).catch(() => {}); return true; }
  return saveSales();
}

/* حذف فواتير */
function deleteSales(ids) {
  SALES = SALES.filter(s => ids.indexOf(s.id) < 0);
  if (USE_IDB) { IDB.delMany(ids).catch(() => {}); return true; }
  return saveSales();
}

/* ============ معلومات السعة ============ */
async function idbInfo() {
  if (!USE_IDB) return null;
  let quota = 0, usage = 0;
  try {
    if (navigator.storage && navigator.storage.estimate) {
      const e = await navigator.storage.estimate();
      quota = e.quota || 0; usage = e.usage || 0;
    }
  } catch (e) {}
  const n = await IDB.count();
  return { count: n, quota, usage };
}

function save() {
  try {
    DB.set('prods', PRODS);
    DB.set('custs', CUSTS);
    if (USE_IDB) { IDB.putMany(SALES).catch(() => {}); }
    else { DB.set('sales', SALES); }
    checkQuota();
    return true;
  } catch (e) {
    if (e && (e.name === 'QuotaExceededError' || e.code === 22 || e.code === 1014)) {
      quotaFull();
    } else {
      tst('⚠ خطأ في الحفظ: ' + (e && e.message ? e.message : 'غير معروف'));
    }
    return false;
  }
}

function checkQuota() {
  const p = storagePct();
  const now = Date.now();
  if (p > 90 && now - _quotaWarned > 60000) {
    _quotaWarned = now;
    tst('🔴 التخزين ممتلئ ' + p.toFixed(0) + '% — أرشِف الآن!');
  } else if (p > 75 && now - _quotaWarned > 300000) {
    _quotaWarned = now;
    tst('🟠 التخزين ' + p.toFixed(0) + '% — يُنصح بالأرشفة');
  }
}

function quotaFull() {
  sheet(`<div class="grab"></div>
    <div style="text-align:center;padding:8px 0 14px">
      <div style="font-size:46px">🔴</div>
      <h2 style="margin-top:10px;color:var(--dan)">امتلأت مساحة التخزين</h2>
      <p class="mut" style="margin-top:6px">لم تُحفظ آخر عملية! اتبع الخطوات فوراً:</p>
    </div>
    <div class="card">
      <b>1️⃣ احفظ نسخة احتياطية</b>
      <p class="mut" style="font-size:12px;margin:5px 0 9px">احتفظ بكل بياناتك في ملف آمن</p>
      <button class="btn sm" onclick="closeSheet();backupMenu()">💾 حفظ نسخة احتياطية</button>
    </div>
    <div class="card">
      <b>2️⃣ أرشِف المبيعات القديمة</b>
      <p class="mut" style="font-size:12px;margin:5px 0 9px">تُصدَّر كملف وتبقى الإحصائيات محفوظة</p>
      <button class="btn sm" onclick="archiveOld()">🗄️ أرشفة الآن</button>
    </div>
    <button class="btn g sm" onclick="closeSheet();show('s_store')">📊 عرض تفاصيل التخزين</button>`);
}

/* ---------- الأرشفة ---------- */
function archiveOld(months) {
  months = months || 12;
  const cut = new Date();
  cut.setMonth(cut.getMonth() - months);
  const iso = cut.toISOString();

  const old = SALES.filter(s => s.date < iso);
  const keep = SALES.filter(s => s.date >= iso);

  if (!old.length) {
    tst('لا توجد مبيعات أقدم من ' + months + ' شهراً');
    return;
  }
  const totalOld = old.reduce((a, s) => a + s.total, 0);
  if (!confirm('أرشفة ' + old.length + ' فاتورة (' + fmt(totalOld) + ' دج)؟\n\n' +
               'سيُحفظ ملف على هاتفك، وتبقى الإحصائيات الإجمالية محفوظة في التطبيق.')) return;

  const payload = JSON.stringify({
    type: 'hanout_archive', v: 2, store: CFG && CFG.name,
    from: old[0].date, to: old[old.length - 1].date,
    count: old.length, total: totalOld, sales: old
  });
  const fname = 'hanout_أرشيف_' + old[0].date.slice(0, 7) + '_' + today() + '.json';
  if (!saveFile(fname, payload)) {
    tst('⚠ لم يُحفظ ملف الأرشيف — أُلغيت العملية');
    return;
  }
  if (AND && Android.saveInternal) { try { Android.saveInternal(fname, payload); } catch (e) {} }

  // احفظ الملخص حتى لا تفقد الإحصائيات
  const sum = DB.get('archSum', { count: 0, total: 0, profit: 0, first: null, last: null });
  sum.count += old.length;
  sum.total += totalOld;
  sum.profit += old.reduce((a2, s) =>
    a2 + s.items.reduce((x, i) => x + (i.price - (i.cost || 0)) * i.qty, 0), 0);
  if (!sum.first) sum.first = old[0].date;
  sum.last = old[old.length - 1].date;
  DB.set('archSum', sum);

  const delIds = old.map(x => x.id);
  SALES = keep;
  if (USE_IDB) { IDB.delMany(delIds).catch(() => {}); } else { save(); }
  DB.set('prods', PRODS); DB.set('custs', CUSTS);
  closeSheet();
  tst('✅ أُرشفت ' + old.length + ' فاتورة');
  if (curScr === 's_store') renderStore();
}

/* ---------- شاشة التخزين ---------- */
function renderStore() {
  const used = storageUsed(), pct = used / QUOTA * 100;
  const col = pct > 90 ? 'var(--dan)' : pct > 75 ? 'var(--or)' : 'var(--ok)';
  const arch = DB.get('archSum', null);

  // تقدير العمر المتبقي
  const last30 = SALES.filter(s => s.date >= new Date(Date.now() - 30 * 864e5).toISOString());
  const perDay = last30.length / 30;
  const bytesPerSale = SALES.length ? used / SALES.length : 350;
  const left = QUOTA - used;
  const daysLeft = perDay > 0.1 ? Math.floor(left / (perDay * bytesPerSale)) : 9999;

  $('st_body').innerHTML = `
    <div class="card" style="background:linear-gradient(135deg,#16293E,#1E3F5C)">
      <div class="row sp" style="margin-bottom:8px">
        <span class="mut">المساحة المستعملة</span>
        <b style="color:${col};font-size:16px">${(used / 1024 / 1024).toFixed(2)} / 5 MB</b>
      </div>
      <div class="prog"><i style="width:${Math.min(100, pct)}%;background:${col}"></i></div>
      <div style="font-size:23px;font-weight:800;color:${col};text-align:center;margin:6px 0">
        ${pct.toFixed(1)}%
      </div>
      ${daysLeft < 9999 ? `<div class="mut" style="text-align:center;font-size:12.5px">
        ${daysLeft > 400 ? '✅ المساحة تكفي أكثر من سنة'
          : daysLeft > 90 ? '🟢 تكفي حوالي ' + Math.round(daysLeft / 30) + ' أشهر'
          : daysLeft > 30 ? '🟠 تكفي حوالي ' + Math.round(daysLeft / 30) + ' أشهر — خطّط للأرشفة'
          : '🔴 تكفي ' + daysLeft + ' يوماً فقط — أرشِف الآن!'}
      </div>` : ''}
    </div>

    <div class="grid3">
      <div class="card" style="margin:0;padding:11px;text-align:center">
        <div class="mut" style="font-size:11px">الفواتير</div>
        <b style="font-size:17px">${SALES.length}</b></div>
      <div class="card" style="margin:0;padding:11px;text-align:center">
        <div class="mut" style="font-size:11px">المنتجات</div>
        <b style="font-size:17px">${PRODS.length}</b></div>
      <div class="card" style="margin:0;padding:11px;text-align:center">
        <div class="mut" style="font-size:11px">الزبائن</div>
        <b style="font-size:17px">${CUSTS.length}</b></div>
    </div>

    ${arch ? `<div class="card">
      <b style="font-size:14px">🗄️ الأرشيف</b>
      <div class="row sp" style="margin-top:8px;font-size:13px">
        <span class="mut">فواتير مؤرشفة</span><b>${arch.count}</b></div>
      <div class="row sp" style="font-size:13px">
        <span class="mut">مبيعاتها</span><b>${fmt(arch.total)} دج</b></div>
      <div class="row sp" style="font-size:13px">
        <span class="mut">أرباحها</span><b style="color:var(--ok)">${fmt(arch.profit)} دج</b></div>
      <div class="mut" style="font-size:11px;margin-top:6px">
        محفوظة في ملفات على هاتفك · الإحصائيات مدمجة في التقارير</div>
    </div>` : ''}

    <div class="card">
      <b style="font-size:14px">🧹 تحرير مساحة</b>
      <p class="mut" style="font-size:12px;margin:6px 0 10px">
        احذف أو أرشف الفواتير القديمة لتفريغ مساحة</p>
      <div class="row" style="gap:8px">
        <button class="btn sm" style="flex:1" onclick="quickPurge()">🧹 تنظيف سريع</button>
        <button class="btn g sm" style="flex:1" onclick="show('s_hist')">🔍 اختيار يدوي</button>
      </div>
    </div>

    ${capacityCard()}

    <div class="card">
      <b style="font-size:14px">🗄️ أرشفة المبيعات القديمة</b>
      <p class="mut" style="font-size:12px;margin:6px 0 10px">
        تُصدَّر كملف على هاتفك وتُزال من الذاكرة النشطة.<br>
        الإحصائيات الإجمالية تبقى محفوظة.</p>
      <div class="row" style="gap:7px">
        <button class="btn g sm" style="flex:1" onclick="archiveOld(24)">أقدم من سنتين</button>
        <button class="btn g sm" style="flex:1" onclick="archiveOld(12)">أقدم من سنة</button>
        <button class="btn g sm" style="flex:1" onclick="archiveOld(6)">أقدم من 6 أشهر</button>
      </div>
    </div>

    <div class="card">
      <b style="font-size:14px">💾 النسخ الاحتياطي</b>
      <p class="mut" style="font-size:12px;margin:6px 0 10px">
        ⚠️ بياناتك تُمحى إن أزلت التطبيق. احفظ نسخة أسبوعياً!</p>
      <button class="btn sm" onclick="backupMenu()">💾 خيارات النسخ الاحتياطي</button>
      ${lastBackupInfo()}
    </div>

    <div class="card">
      <b style="font-size:14px">📦 المنتجات</b>
      <p class="mut" style="font-size:12px;margin:6px 0 10px">
        استورد مخزونك من Excel أو صدّره كملف</p>
      <div class="row" style="gap:8px">
        <button class="btn g sm" style="flex:1" onclick="importSheet()">📥 استيراد</button>
        <button class="btn g sm" style="flex:1" onclick="exportProds()">📤 تصدير</button>
      </div>
    </div>`;
}

/* تقدير السعة المتبقية بالأرقام الحقيقية */
function capacityCard() {
  // وضع IndexedDB: سعة ضخمة
  if (USE_IDB) {
    const avgSale = SALES.length
      ? SALES.reduce((a, s) => a + JSON.stringify(s).length * 2, 0) / SALES.length : 890;
    const est = Math.floor((50 * 1024 * 1024) / avgSale);   // تقدير محافظ 50 ميجا
    const from = new Date(Date.now() - 30 * 864e5).toISOString();
    const per = SALES.filter(s => s.date >= from).length / 30;
    const dl = per > 0.1 ? Math.floor((est - SALES.length) / per) : null;
    return `<div class="card" style="border-color:var(--ok);background:rgba(39,192,122,.06)">
      <div class="row sp" style="margin-bottom:7px">
        <b style="font-size:14px;color:var(--ok)">⚡ التخزين المتقدّم مفعّل</b>
        <span class="pill">IndexedDB</span></div>
      <div class="mut" style="font-size:12px;line-height:1.8;margin-bottom:9px">
        سعة المبيعات ارتفعت من 5,900 إلى أكثر من ${fmt(est)} فاتورة.</div>
      <div class="row sp" style="padding:5px 0;border-top:1px solid var(--line);font-size:13px">
        <span class="mut">الفواتير الحالية</span><b>${fmt(SALES.length)}</b></div>
      <div class="row sp" style="padding:5px 0;font-size:13px">
        <span class="mut">المتاح تقريباً</span>
        <b style="color:var(--ok)">${fmt(Math.max(0, est - SALES.length))}</b></div>
      ${dl !== null ? `<div class="mut" style="font-size:11.5px;margin-top:7px">
        بمعدلك الحالي تكفيك ${dl > 365 ? (dl / 365).toFixed(1) + ' سنة' : dl + ' يوماً'}</div>` : ''}
      <div class="mut" style="font-size:11px;margin-top:7px;opacity:.75">
        💡 المنتجات والزبائن ما زالوا في التخزين العادي (${storagePct().toFixed(0)}% مستعمل)</div>
    </div>`;
  }

  const used = storageUsed();
  const left = Math.max(0, QUOTA - used);

  // متوسط حجم السجل من بيانات المستخدم نفسه
  const avgSale = SALES.length
    ? SALES.reduce((a, s) => a + JSON.stringify(s).length * 2, 0) / SALES.length : 890;
  const avgProd = PRODS.length
    ? PRODS.reduce((a, p) => a + JSON.stringify(p).length * 2, 0) / PRODS.length : 350;

  const moreSales = Math.floor(left / avgSale);
  const moreProds = Math.floor(left / avgProd);

  // معدل البيع اليومي من آخر 30 يوماً
  const from = new Date(Date.now() - 30 * 864e5).toISOString();
  const recent30 = SALES.filter(s => s.date >= from).length;
  const perDay = recent30 / 30;
  const daysLeft = perDay > 0.1 ? Math.floor(moreSales / perDay) : null;

  return `<div class="card">
    <b style="font-size:14px">📊 السعة المتبقية</b>
    <div class="mut" style="font-size:11.5px;margin:5px 0 9px">
      محسوبة من متوسط حجم سجلاتك الفعلية</div>
    <div class="row sp" style="padding:6px 0;border-bottom:1px solid var(--line);font-size:13px">
      <span>🧾 فواتير إضافية</span>
      <b style="color:var(--ok)">${fmt(moreSales)}</b></div>
    <div class="row sp" style="padding:6px 0;border-bottom:1px solid var(--line);font-size:13px">
      <span>📦 منتجات إضافية</span>
      <b style="color:var(--ok)">${fmt(moreProds)}</b></div>
    <div class="row sp" style="padding:6px 0;font-size:13px">
      <span>👤 زبائن إضافيون</span>
      <b style="color:var(--ok)">${fmt(Math.floor(left / 270))}</b></div>
    ${daysLeft !== null ? `<div class="mut" style="font-size:11.5px;margin-top:8px;line-height:1.7">
      بمعدلك الحالي (${perDay.toFixed(0)} فاتورة/يوم) تكفيك
      <b style="color:${daysLeft > 180 ? 'var(--ok)' : daysLeft > 60 ? 'var(--or2)' : 'var(--dan)'}">
      ${daysLeft > 365 ? (daysLeft / 365).toFixed(1) + ' سنة' : daysLeft + ' يوماً'}</b></div>` : ''}
    <div class="mut" style="font-size:11px;margin-top:7px;opacity:.75">
      💡 ملاحظة: الأرقام تقديرية — الفاتورة بأصناف أكثر تشغل مساحة أكبر</div>
  </div>`;
}

function lastBackupInfo() {
  const lb = DB.get('lastBackup', null);
  if (!lb) return `<div class="mut" style="font-size:11.5px;margin-top:9px;color:var(--or2)">
    ⚠️ لم تحفظ أي نسخة احتياطية بعد</div>`;
  const days = Math.floor((Date.now() - new Date(lb)) / 864e5);
  const c = days > 14 ? 'var(--dan)' : days > 7 ? 'var(--or2)' : 'var(--ok)';
  return `<div class="mut" style="font-size:11.5px;margin-top:9px;color:${c}">
    ${days === 0 ? '✅ آخر نسخة: اليوم' : '📅 آخر نسخة منذ ' + days + ' يوماً'}</div>`;
}

/* تذكير النسخ الاحتياطي */
function backupReminder() {
  const lb = DB.get('lastBackup', null);
  if (SALES.length < 20) return;
  const days = lb ? Math.floor((Date.now() - new Date(lb)) / 864e5) : 999;
  if (days < 7) return;
  const lastAsk = DB.get('lastBackupAsk', null);
  if (lastAsk && Date.now() - new Date(lastAsk) < 2 * 864e5) return;
  DB.set('lastBackupAsk', new Date().toISOString());
  setTimeout(() => {
    sheet(`<div class="grab"></div>
      <div style="text-align:center;padding:10px 0 16px">
        <div style="font-size:44px">💾</div>
        <h2 style="margin-top:10px">احفظ نسخة احتياطية</h2>
        <p class="mut" style="margin-top:7px">
          ${lb ? 'آخر نسخة منذ ' + days + ' يوماً' : 'لم تحفظ أي نسخة بعد'}<br>
          لديك <b style="color:var(--tx)">${SALES.length} فاتورة</b> و
          <b style="color:var(--tx)">${PRODS.length} منتج</b><br><br>
          ⚠️ إن أزلت التطبيق أو تعطّل الهاتف، ستفقد كل شيء.
        </p>
      </div>
      <button class="btn" onclick="closeSheet();backupMenu()">💾 احفظ الآن</button>
      <button class="btn g sm" style="margin-top:8px" onclick="closeSheet()">لاحقاً</button>`);
  }, 1800);
}

/* ============ 2) نظام التراخيص ============ */
const LIMITS = {
  free: { prods: 50, custs: 20, salesPerDay: 30, days: 30, reports: false, brand: false },
  pro:  { prods: Infinity, custs: Infinity, salesPerDay: Infinity, days: Infinity, reports: true, brand: true }
};
let LIC = DB.get('lic', null);

/**
 * رقم الجهاز — مرتبط بالعتاد لا بالتطبيق.
 * يبقى نفسه بعد حذف التطبيق وإعادة تثبيته، فلا يمكن الحصول
 * على مفتاح مجاني جديد بحذف التطبيق.
 */
function deviceId() {
  // 1) الأفضل: معرّف العتاد من أندرويد (ثابت بعد الحذف)
  if (AND && Android.hwId) {
    try {
      const h = Android.hwId();
      if (h && h.length >= 8) {
        DB.set('devId', h);   // خزّنه للعرض السريع فقط
        return h;
      }
    } catch (e) {}
  }
  // 2) احتياطي (المتصفح أو جهاز نادر لا يعطي معرّفاً)
  let d = DB.get('devId', null);
  if (!d) {
    d = (Date.now().toString(36) + Math.random().toString(36).slice(2, 8)).toUpperCase();
    DB.set('devId', d);
  }
  return d;
}

/** هل الرقم من العتاد فعلاً؟ (لتمييز الحالات النادرة) */
function hwIdStable() {
  if (!AND || !Android.hwId) return false;
  try { const h = Android.hwId(); return !!(h && h.length >= 8); } catch (e) { return false; }
}
function hashK(s) {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; }
  return h.toString(36).toUpperCase().padStart(7, '0');
}
function genKey(d, p) {
  const t = p === 'pro' ? 'P' : 'F';
  return (t + '-' + hashK(d + SALT + t).slice(0, 4) + '-' + hashK(SALT + d).slice(0, 4)).toUpperCase();
}
/* ينظّف المفتاح من أي رموز زائدة (نجوم واتساب، مسافات، أقواس...) */
function cleanKey(k) {
  if (!k) return '';
  // أبقِ الحروف والأرقام فقط
  let c = String(k).toUpperCase().replace(/[^A-Z0-9]/g, '');
  // أعد تنسيقه: حرف + 4 + 4
  if (c.length === 9) return c[0] + '-' + c.slice(1, 5) + '-' + c.slice(5);
  return c;
}

function verifyKey(k) {
  if (!k) return null;
  const want = genKey(deviceId(), 'pro');
  const wantClean = want.replace(/[^A-Z0-9]/g, '');
  const gotClean = String(k).toUpperCase().replace(/[^A-Z0-9]/g, '');
  return gotClean === wantClean ? 'pro' : null;
}
function plan() { return (LIC && LIC.plan === 'pro') ? 'pro' : 'free'; }
function lim() { return LIMITS[plan()]; }
function isPro() { return plan() === 'pro'; }

const GRACE_DAYS = 3;   // مهلة سماح بعد انتهاء التجربة

/* الأيام المستهلكة منذ أول تشغيل */
function trialUsed() {
  let st = DB.get('firstRun', null);
  if (!st) { st = today(); DB.set('firstRun', st); }
  return Math.floor((Date.now() - new Date(st)) / 864e5);
}

/* أيام التجربة المتبقية (بلا المهلة) */
function trialLeft() {
  if (isPro()) return Infinity;
  return Math.max(0, LIMITS.free.days - trialUsed());
}

/* هل نحن داخل مهلة السماح؟ */
function inGrace() {
  if (isPro()) return false;
  const d = trialUsed();
  return d >= LIMITS.free.days && d < LIMITS.free.days + GRACE_DAYS;
}

/* أيام المهلة المتبقية */
function graceLeft() {
  if (isPro()) return Infinity;
  return Math.max(0, LIMITS.free.days + GRACE_DAYS - trialUsed());
}

/* التوقف الفعلي: بعد التجربة + المهلة */
function trialOver() {
  if (isPro()) return false;
  return trialUsed() >= LIMITS.free.days + GRACE_DAYS;
}

/* الحاجز */
function canAdd(type) {
  if (isPro()) return true;
  const L = lim();
  if (trialOver()) {
    showUpgrade('انتهت الفترة التجريبية والمهلة',
                'فعّل النسخة الكاملة لمواصلة تسجيل العمليات');
    return false;
  }
  // داخل المهلة: يعمل كل شيء لكن مع تذكير
  if (inGrace()) graceNotice();
  if (type === 'prod' && PRODS.length >= L.prods) {
    showUpgrade('وصلت للحد: ' + L.prods + ' منتج', 'النسخة الكاملة تتيح منتجات بلا حدود');
    return false;
  }
  if (type === 'cust' && CUSTS.length >= L.custs) {
    showUpgrade('وصلت للحد: ' + L.custs + ' زبون', 'النسخة الكاملة تتيح زبائن بلا حدود');
    return false;
  }
  if (type === 'sale') {
    const t = today();
    const n = SALES.filter(s => s.date.slice(0, 10) === t).length;
    if (n >= L.salesPerDay) {
      showUpgrade('وصلت لحد ' + L.salesPerDay + ' فاتورة اليوم', 'النسخة الكاملة بلا حدود يومية');
      return false;
    }
  }
  return true;
}

/* تذكير خفيف داخل المهلة — مرة يومياً */
function graceNotice() {
  const last = DB.get('graceAsk', null);
  if (last === today()) return;
  DB.set('graceAsk', today());
  const g = graceLeft();
  setTimeout(() => {
    tst('⏳ مهلة السماح: ' + g + (g === 1 ? ' يوم أخير' : ' أيام متبقية'));
  }, 900);
}

/* تحذير تدريجي عند بدء التطبيق */
function trialWarn() {
  if (isPro()) return;
  const d = trialLeft();
  const g = graceLeft();
  const key = DB.get('warnShown', '');
  const td = today();
  if (key === td) return;      // مرة واحدة يومياً

  let title = '', body = [], kind = '';

  if (trialOver()) {
    title = '🔴 توقّف تسجيل العمليات';
    body = ['انتهت الفترة التجريبية ومهلة السماح.',
            'لا يمكنك تسجيل مبيعات أو إضافة منتجات وزبائن.',
            '',
            'لكن بياناتك سليمة: تستطيع التصفّح والطباعة وحفظ نسخة احتياطية.'];
    kind = 'stop';
  } else if (inGrace()) {
    title = '⏳ مهلة السماح — ' + g + (g === 1 ? ' يوم أخير' : ' أيام');
    body = ['انتهت فترتك التجريبية، لكن منحناك ' + GRACE_DAYS + ' أيام إضافية.',
            'كل شيء يعمل بشكل طبيعي خلالها.',
            '',
            'بعدها سيتوقف تسجيل المبيعات.'];
    kind = 'grace';
  } else if (d === 1) {
    title = '⚠️ آخر يوم في التجربة';
    body = ['غداً تنتهي فترتك التجريبية.',
            'لكن لا تقلق — لديك ' + GRACE_DAYS + ' أيام مهلة سماح بعدها.'];
    kind = 'warn';
  } else if (d === 3 || d === 7) {
    title = '🎁 باقي ' + d + ' أيام في التجربة';
    body = ['فترتك التجريبية تنتهي بعد ' + d + ' أيام.',
            'ثم لديك ' + GRACE_DAYS + ' أيام مهلة سماح إضافية.'];
    kind = 'warn';
  } else {
    return;
  }

  DB.set('warnShown', td);

  setTimeout(() => {
    sheet(`<div class="grab"></div>
      <div style="text-align:center;padding:10px 0 14px">
        <h2>${title}</h2>
      </div>
      <div class="card" style="padding:13px;${
        kind === 'stop' ? 'border-color:#5A2A2A;background:rgba(255,92,92,.07)'
        : kind === 'grace' ? 'border-color:var(--or)' : ''}">
        <div class="mut" style="font-size:12.5px;line-height:1.9">
          ${body.map(b => b || '<br>').join('<br>')}
        </div>
      </div>
      <div class="card" style="padding:12px">
        <div class="row sp" style="font-size:12.5px">
          <span class="mut">رقم جهازك</span>
          <b style="font-family:monospace;color:var(--or2)">${deviceId()}</b>
        </div>
      </div>
      <button class="btn" onclick="closeSheet();showUpgrade('ترقية إلى PRO','افتح كل الميزات بلا حدود')">
        🔓 ترقية الآن</button>
      <button class="btn g sm" style="margin-top:8px" onclick="closeSheet()">
        ${kind === 'stop' ? 'تصفّح البيانات' : 'لاحقاً'}</button>`);
  }, 1400);
}

/* شاشة الترقية */
function showUpgrade(title, sub) {
  const d = deviceId();
  sheet(`<div class="grab"></div>
    <div style="text-align:center;margin-bottom:16px">
      <div style="font-size:44px">🔓</div>
      <h2 style="margin-top:8px">${esc(title)}</h2>
      <p class="mut" style="margin-top:5px">${esc(sub)}</p>
    </div>

    <div class="card" style="background:linear-gradient(135deg,#1E3F5C,#16293E);border-color:var(--gold)">
      <div class="row sp" style="margin-bottom:11px">
        <b style="font-size:17px;color:var(--gold)">⭐ حانوت PRO</b>
        <b style="font-size:21px">${fmt(SELLER.priceP)} دج</b>
      </div>
      <div style="font-size:13.5px;line-height:2.05">
        ✅ منتجات وزبائن <b>بلا حدود</b><br>
        ✅ فواتير بلا حدود يومية<br>
        ✅ <b>التقارير المتقدمة</b> — الأرباح وأفضل المنتجات وأوقات الذروة<br>
        ✅ تخصيص الفاتورة بشعارك<br>
        ✅ استيراد المنتجات من ملف<br>
        ✅ دعم فني <b>سنة كاملة</b><br>
        ✅ تحديثات مجانية مدى الحياة
      </div>
      <div style="border-top:1px solid var(--line);margin:12px 0 9px"></div>
      <div class="mut" style="font-size:12px">💳 دفعة واحدة — بلا اشتراك شهري</div>
    </div>

    <div class="card" style="padding:12px">
      <div class="mut" style="font-size:11.5px;margin-bottom:5px">رقم جهازك (أرسله لنا):</div>
      <div class="row sp">
        <b style="font-family:monospace;font-size:16px;letter-spacing:1.5px;color:var(--or2)">${d}</b>
        <button class="chip" onclick="copyTxt('${d}','📋 نُسخ رقم الجهاز')">📋 نسخ</button>
      </div>
      <div class="mut" style="font-size:10.5px;margin-top:7px;line-height:1.6">
        ${hwIdStable()
          ? '🔒 هذا الرقم مرتبط بهاتفك ولا يتغيّر — المفتاح يعمل عليه مدى الحياة حتى لو أعدت تثبيت التطبيق.'
          : '⚠️ تعذّر قراءة معرّف الجهاز — تواصل معنا للتفعيل.'}
      </div>
    </div>

    <button class="btn" style="background:linear-gradient(135deg,#25D366,#128C7E);box-shadow:none"
      onclick="orderService('ترخيص حانوت PRO — ${fmt(SELLER.priceP)} دج')">📲 اطلب عبر واتساب</button>
    <div class="row" style="gap:8px;margin-top:9px">
      <button class="btn g sm" style="flex:1" onclick="enterKey()">🔑 لدي مفتاح</button>
      <button class="btn g sm" style="flex:1" onclick="closeSheet()">لاحقاً</button>
    </div>`);
}

function enterKey() {
  sheet(`<div class="grab"></div><h2 style="margin-bottom:6px">🔑 تفعيل النسخة الكاملة</h2>
    <p class="mut" style="margin-bottom:14px">الصق المفتاح الذي وصلك</p>
    <div class="inp" style="margin-bottom:6px">🔑
      <input id="lic_key" placeholder="P-XXXX-XXXX" autocomplete="off"
        oninput="keyHint()"
        style="font-family:monospace;letter-spacing:2px;text-transform:uppercase"></div>
    <div id="keyMsg" class="mut" style="font-size:11.5px;margin-bottom:12px">
      يمكنك لصقه مع النجوم أو بدونها — سيُنظَّف تلقائياً</div>
    <div class="mut" style="font-size:11.5px;margin-bottom:14px">
      رقم جهازك: <b style="font-family:monospace;color:var(--or2)">${deviceId()}</b></div>
    <button class="btn" onclick="activate()">تفعيل</button>
    <button class="btn g sm" style="margin-top:8px" onclick="closeSheet()">إلغاء</button>`);
  setTimeout(() => { const e = $('lic_key'); if (e) e.focus(); }, 200);
}

/* تلميح فوري أثناء الكتابة */
function keyHint() {
  const el = $('keyMsg'), inp = $('lic_key');
  if (!el || !inp) return;
  const c = String(inp.value).toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (!c.length) {
    el.innerHTML = 'يمكنك لصقه مع النجوم أو بدونها — سيُنظَّف تلقائياً';
    el.style.color = '';
    return;
  }
  if (c.length < 9) {
    el.innerHTML = 'الحروف المدخلة: ' + c.length + ' من 9';
    el.style.color = '';
  } else if (c.length > 9) {
    el.innerHTML = '⚠ عدد الحروف أكثر من المطلوب (' + c.length + ')';
    el.style.color = 'var(--or2)';
  } else {
    const okk = verifyKey(inp.value);
    el.innerHTML = okk ? '✅ المفتاح صحيح — اضغط تفعيل'
                       : '❌ المفتاح لا يطابق رقم جهازك';
    el.style.color = okk ? 'var(--ok)' : 'var(--dan)';
  }
}

function activate() {
  const k = ($('lic_key').value || '').trim();
  const p = verifyKey(k);
  if (!p) {
    const c = String(k).toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (c.length !== 9) {
      tst('⚠ المفتاح ناقص — يجب أن يحوي 9 حروف وأرقام');
    } else {
      tst('⚠ هذا المفتاح لجهاز آخر — تأكد من رقم جهازك');
    }
    return;
  }
  LIC = { plan: p, key: k.toUpperCase(), date: today(),
          supportUntil: new Date(Date.now() + 365 * 864e5).toISOString().slice(0, 10) };
  DB.set('lic', LIC);
  closeSheet();
  setTimeout(() => {
    sheet(`<div class="grab"></div>
      <div style="text-align:center;padding:22px 0">
        <div class="okc">✓</div>
        <h2 style="margin-top:18px">تم التفعيل! 🎉</h2>
        <p class="mut" style="margin-top:9px">
          نسخة <b style="color:var(--gold)">PRO</b> — بلا حدود<br>
          الدعم الفني ساري حتى ${LIC.supportUntil}</p>
      </div>
      <button class="btn" onclick="closeSheet();show('s_home');buildNav()">ابدأ الآن</button>`);
  }, 200);
  buildNav();
}

function copyTxt(t, m) {
  try {
    navigator.clipboard.writeText(t);
    tst(m || '📋 نُسخ');
  } catch (e) {
    const ta = document.createElement('textarea');
    ta.value = t; document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); tst(m || '📋 نُسخ'); } catch (er) {}
    ta.remove();
  }
}

/* ============ 3) الخدمات الإضافية ============ */
function orderService(name) {
  const msg = 'السلام عليكم 🌿\nأريد: *' + name + '*\n\n' +
    'رقم الجهاز: *' + deviceId() + '*\n' +
    'المتجر: ' + ((CFG && CFG.name) || '—') + '\n' +
    'الولاية: ' + ((CFG && CFG.addr) || '—') + '\n' +
    'الهاتف: ' + ((CFG && CFG.phone) || '—');
  waOpen(SELLER.phone, msg);
}

/* نقل الترخيص لهاتف جديد */
function transferLicense() {
  const msg = 'السلام عليكم 🌿\n*طلب نقل الترخيص لهاتف جديد*\n\n' +
    'رقم الجهاز الجديد: *' + deviceId() + '*\n' +
    'المتجر: ' + ((CFG && CFG.name) || '—') + '\n' +
    'الهاتف: ' + ((CFG && CFG.phone) || '—') + '\n\n' +
    'ملاحظة: سأتوقف عن استعمال الهاتف القديم.';
  waOpen(SELLER.phone, msg);
}


/* بطاقة الدعم الفني */
function supportCard() {
  const exp = LIC && LIC.supportUntil;
  const active = exp && new Date(exp) > new Date();
  const days = active ? Math.floor((new Date(exp) - Date.now()) / 864e5) : 0;
  const disp = SELLER.phone.replace(/^213/, '0');
  return `<div class="card">
    <div class="row sp" style="margin-bottom:8px">
      <b style="font-size:14.5px">🛟 الدعم الفني</b>
      ${active ? `<span class="pill">${days} يوماً</span>` : ''}
    </div>
    <div class="row sp" style="padding:7px 0;border-top:1px solid var(--line);
      border-bottom:1px solid var(--line);margin-bottom:10px">
      <span class="mut" style="font-size:12.5px">📞 رقم الدعم</span>
      <b style="font-family:monospace;font-size:15px;color:var(--or2);letter-spacing:.5px"
        onclick="copyTxt('${disp}','📋 نُسخ الرقم')">${disp}</b>
    </div>
    ${active ? `<div class="mut" style="font-size:12px;margin-bottom:9px">
      ✅ اشتراكك ساري حتى ${exp}</div>` : ''}
    <div class="row" style="gap:8px">
      <button class="btn sm" style="flex:1;background:linear-gradient(135deg,#25D366,#128C7E);box-shadow:none"
        onclick="contactSupport()">📲 واتساب</button>
      <button class="btn g sm" style="flex:1" onclick="callSupport()">📞 اتصال</button>
    </div>
    ${!active ? `<button class="btn g sm" style="margin-top:8px"
      onclick="orderService('الدعم الفني السنوي — ' + fmt(SELLER.priceSupport) + ' دج')">
      🔄 اشترك في الدعم — ${fmt(SELLER.priceSupport)} دج/سنة</button>` : ''}
  </div>`;
}

function callSupport() {
  const url = 'tel:+' + SELLER.phone;
  if (AND && Android.openUrl) { try { Android.openUrl(url); return; } catch (e) {} }
  location.href = url;
}

function contactSupport() {
  const msg = 'السلام عليكم 🌿\n*طلب دعم فني*\n\n' +
    'المتجر: ' + ((CFG && CFG.name) || '—') + '\n' +
    'رقم الجهاز: ' + deviceId() + '\n' +
    'النسخة: 2.9\n\nالمشكلة: ';
  waOpen(SELLER.phone, msg);
}

/* ---------- استيراد المنتجات من ملف ---------- */








/* ---------- تخصيص الفاتورة ---------- */
function brandSettings() {
  if (!isPro()) {
    showUpgrade('تخصيص الفاتورة', 'أضف شعارك ورسالتك الخاصة — ميزة PRO');
    return;
  }
  sheet(`<div class="grab"></div><h2 style="margin-bottom:12px">🎨 تخصيص الفاتورة</h2>
    ${CFG.logo ? `<div style="text-align:center;margin-bottom:12px">
      <img src="${CFG.logo}" style="max-width:110px;border-radius:10px;background:#fff;padding:6px">
      <div><button class="chip" style="margin-top:7px" onclick="delLogo()">🗑️ حذف الشعار</button></div>
    </div>` : ''}
    <div class="fld"><label class="lbl">شعار المتجر (يظهر على الفاتورة)</label>
      <div class="inp">🖼️<input type="file" accept="image/*" onchange="setLogo(this.files[0])"
        style="font-size:13px"></div></div>
    <div class="fld"><label class="lbl">رسالة أسفل الفاتورة</label>
      <div class="inp">💬<input id="b_foot" value="${esc((CFG && CFG.footer) || 'شكراً لزيارتكم 🌿')}"
        placeholder="شكراً لزيارتكم"></div></div>
    <button class="btn" onclick="saveBrand()">حفظ</button>
    <div class="card" style="margin-top:14px;padding:12px">
      <div class="mut" style="font-size:12px">
        تريد تخصيصاً أعمق؟ حقول خاصة، تصميم فاتورة مختلف، أو ميزات لنشاطك تحديداً.</div>
      <button class="btn g sm" style="margin-top:9px"
        onclick="orderService('تخصيص خاص للتطبيق')">🛠️ اطلب تخصيصاً</button>
    </div>`);
}

function setLogo(file) {
  if (!file) return;
  const r = new FileReader();
  r.onload = e => {
    const img = new Image();
    img.onload = () => {
      const cv = document.createElement('canvas');
      const W = 150;
      cv.width = W; cv.height = Math.round(W * img.height / img.width);
      const cx = cv.getContext('2d');
      cx.fillStyle = '#fff'; cx.fillRect(0, 0, cv.width, cv.height);
      cx.drawImage(img, 0, 0, cv.width, cv.height);
      CFG.logo = cv.toDataURL('image/jpeg', 0.72);
      try { DB.set('cfg', CFG); tst('✅ حُفظ الشعار'); brandSettings(); }
      catch (er) { tst('⚠ الشعار كبير — جرّب صورة أصغر'); CFG.logo = null; }
    };
    img.onerror = () => tst('⚠ ملف صورة غير صالح');
    img.src = e.target.result;
  };
  r.readAsDataURL(file);
}
function delLogo() { CFG.logo = null; DB.set('cfg', CFG); tst('حُذف الشعار'); brandSettings(); }
function saveBrand() {
  CFG.footer = ($('b_foot').value || '').trim() || 'شكراً لزيارتكم 🌿';
  DB.set('cfg', CFG);
  closeSheet();
  tst('✅ حُفظت الإعدادات');
}

/* ============================================================
   v2.8 — تعدد المستخدمين (مالك / بائع)
   ============================================================ */

/* الصلاحيات حسب الدور */
const ROLES = {
  owner: {
    label: 'مالك',
    icon: '👑',
    reports: true,      // التقارير والأرباح
    cost: true,         // رؤية سعر الشراء
    stock: true,        // تعديل المخزون
    delete: true,       // حذف الفواتير
    settings: true,     // الإعدادات الكاملة
    debt: true,         // إدارة الديون
    backup: true        // النسخ الاحتياطي
  },
  seller: {
    label: 'بائع',
    icon: '🧑‍💼',
    reports: false,
    cost: false,
    stock: false,
    delete: false,
    settings: false,
    debt: true,         // يسجّل الكريدي لكن لا يحذف
    backup: false
  }
};

let USER = null;        // المستخدم الحالي

function getUsers() { return DB.get('users', []); }
function setUsers(l) { DB.set('users', l); }

/* هل نظام المستخدمين مفعّل؟ */
function usersOn() { return getUsers().length > 0; }

/* الدور الحالي */
function role() {
  if (!usersOn()) return 'owner';       // بلا مستخدمين = كل الصلاحيات
  return (USER && USER.role) || 'seller';
}
function can(what) { return !!ROLES[role()][what]; }
function isOwner() { return role() === 'owner'; }

/* تجزئة الرمز السري */
function pinHash(p) {
  let h = 0x811c9dc5;
  const s = String(p) + '|HNT-PIN';
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; }
  return h.toString(36);
}

/* ============ شاشة الدخول ============ */
function lockScreen() {
  const us = getUsers();
  if (!us.length) return false;

  // جلسة محفوظة؟
  const sess = DB.get('session', null);
  if (sess) {
    const u = us.find(x => x.id === sess);
    if (u) { USER = u; return false; }
  }

  document.body.insertAdjacentHTML('beforeend', `
    <div id="lockOv" style="position:fixed;inset:0;background:var(--bg);z-index:9999;
         display:flex;flex-direction:column;align-items:center;justify-content:center;padding:24px">
      <div class="mark" style="margin-bottom:14px">🏪</div>
      <b style="font-size:20px;margin-bottom:4px">${esc((CFG && CFG.name) || 'حانوت')}</b>
      <div class="mut" style="font-size:13px;margin-bottom:22px">اختر المستخدم</div>

      <div style="width:100%;max-width:330px" id="lockList">
        ${us.map(u => `
          <div class="card" style="padding:13px" onclick="pickUser('${u.id}')">
            <div class="row">
              <div class="ic" style="font-size:20px">${ROLES[u.role].icon}</div>
              <div style="flex:1">
                <b style="font-size:15px">${esc(u.name)}</b>
                <div class="mut" style="font-size:11.5px">${ROLES[u.role].label}</div>
              </div>
              <span style="font-size:17px">›</span>
            </div></div>`).join('')}
      </div>
    </div>`);
  return true;
}

let pinUser = null;
function pickUser(id) {
  const u = getUsers().find(x => x.id === id);
  if (!u) return;
  if (!u.pin) { doLogin(u); return; }
  pinUser = u;
  $('lockList').innerHTML = `
    <div class="card" style="padding:16px;text-align:center">
      <div style="font-size:26px">${ROLES[u.role].icon}</div>
      <b style="font-size:16px;display:block;margin:7px 0 3px">${esc(u.name)}</b>
      <div class="mut" style="font-size:12px;margin-bottom:14px">أدخل الرمز السري</div>
      <div class="inp" style="margin-bottom:8px">
        <input id="pinIn" type="password" inputmode="numeric" maxlength="6"
          placeholder="••••" style="text-align:center;font-size:24px;letter-spacing:8px"
          onkeydown="if(event.key==='Enter')tryPin()"></div>
      <div id="pinMsg" class="mut" style="font-size:11.5px;min-height:16px"></div>
      <button class="btn sm" style="margin-top:10px" onclick="tryPin()">دخول</button>
      <button class="btn g sm" style="margin-top:7px" onclick="backToUsers()">رجوع</button>
    </div>`;
  setTimeout(() => { const e = $('pinIn'); if (e) e.focus(); }, 150);
}

function backToUsers() {
  const ov = $('lockOv');
  if (ov) ov.remove();
  lockScreen();
}

function tryPin() {
  const v = ($('pinIn').value || '').trim();
  if (!v) return;
  if (pinHash(v) !== pinUser.pin) {
    $('pinMsg').innerHTML = '<span style="color:var(--dan)">رمز خاطئ</span>';
    $('pinIn').value = '';
    return;
  }
  doLogin(pinUser);
}

function doLogin(u) {
  USER = u;
  DB.set('session', u.id);
  const ov = $('lockOv');
  if (ov) ov.remove();
  applyRole();
  buildNav();
  show('s_home');
  tst('أهلاً ' + u.name);
}

function logout() {
  DB.set('session', null);
  USER = null;
  location.reload();
}

/* ============ تطبيق الصلاحيات على الواجهة ============ */
function applyRole() {
  const owner = isOwner();
  // إخفاء عناصر المالك
  document.querySelectorAll('[data-own]').forEach(el => {
    el.style.display = owner ? '' : 'none';
  });
  // شريط التنقل
  const navRep = document.querySelectorAll('.nav div[data-t="s_rep"]');
  navRep.forEach(el => { el.style.display = owner ? '' : 'none'; });
}

/* ============ إدارة المستخدمين ============ */
function renderUsers() {
  const us = getUsers();
  $('us_body').innerHTML = `
    ${!us.length ? `
      <div class="card" style="padding:14px;border-color:var(--or)">
        <b style="font-size:14px;color:var(--or2)">نظام المستخدمين معطّل</b>
        <div class="mut" style="font-size:12.5px;line-height:1.85;margin-top:6px">
          حالياً أي شخص يفتح التطبيق يرى كل شيء: الأرباح، أسعار الشراء، الإعدادات.<br><br>
          فعّله لتحمي بياناتك من البائع أو أي شخص يستعمل الهاتف.
        </div>
      </div>` : ''}

    <button class="btn" style="margin-bottom:13px" onclick="openUser()">
      ＋ ${us.length ? 'مستخدم جديد' : 'ابدأ — أضف نفسك كمالك'}</button>

    ${us.map(u => `
      <div class="card" style="padding:12px 13px" onclick="openUser('${u.id}')">
        <div class="row">
          <div class="ic" style="font-size:19px">${ROLES[u.role].icon}</div>
          <div style="flex:1;min-width:0">
            <b style="font-size:14.5px">${esc(u.name)}</b>
            <div class="mut" style="font-size:11.5px;margin-top:2px">
              ${ROLES[u.role].label}${u.pin ? ' · 🔒 محمي برمز' : ' · بلا رمز'}
              ${USER && USER.id === u.id ? ' · <b style="color:var(--ok)">أنت</b>' : ''}
            </div>
          </div>
          <span style="font-size:17px">›</span>
        </div></div>`).join('')}

    ${us.length ? `
      <div class="card" style="padding:12px;margin-top:11px">
        <b style="font-size:13.5px">الصلاحيات</b>
        <div style="margin-top:8px">
          ${[['التقارير والأرباح','reports'],['أسعار الشراء','cost'],
             ['تعديل المخزون','stock'],['حذف الفواتير','delete'],
             ['الإعدادات','settings'],['النسخ الاحتياطي','backup']]
            .map(x => `<div class="row sp" style="padding:4px 0;font-size:12.5px">
              <span class="mut">${x[0]}</span>
              <span>👑 ✅ &nbsp;&nbsp; 🧑‍💼 ${ROLES.seller[x[1]] ? '✅' : '❌'}</span>
            </div>`).join('')}
        </div>
      </div>

      <button class="btn g sm" style="margin-top:11px" onclick="logout()">
        🚪 تسجيل الخروج</button>` : ''}`;
}

function openUser(id) {
  const us = getUsers();
  const u = id ? us.find(x => x.id === id) : null;
  const first = !us.length;

  sheet(`<div class="grab"></div>
    <h2 style="margin-bottom:12px">${u ? 'تعديل مستخدم' : (first ? 'المالك' : 'مستخدم جديد')}</h2>

    <div class="fld"><label class="lbl">الاسم *</label>
      <div class="inp">👤<input id="u_n" value="${esc(u?.name || '')}"
        placeholder="مثال: محمد"></div></div>

    <div class="fld"><label class="lbl">الدور</label>
      <div class="inp">🎭<select id="u_r" ${first ? 'disabled' : ''}>
        <option value="owner" ${(u?.role === 'owner' || first) ? 'selected' : ''}>👑 مالك — كل الصلاحيات</option>
        <option value="seller" ${u?.role === 'seller' ? 'selected' : ''}>🧑‍💼 بائع — البيع فقط</option>
      </select></div>
      ${first ? '<div class="mut" style="font-size:11px;margin-top:4px">أول مستخدم يكون المالك دائماً</div>' : ''}
    </div>

    <div class="fld"><label class="lbl">رمز سري (اختياري)</label>
      <div class="inp">🔒<input id="u_p" type="number" inputmode="numeric"
        placeholder="${u?.pin ? 'اتركه فارغاً للإبقاء على الحالي' : '4 أرقام مثلاً'}"></div>
      <div class="mut" style="font-size:11px;margin-top:4px">
        بلا رمز = دخول مباشر بالضغط على الاسم</div>
    </div>

    <button class="btn" onclick="saveUser('${id || ''}')">
      ${u ? 'حفظ' : 'إضافة'}</button>
    ${u && us.length > 1 ? `<button class="btn d sm" style="margin-top:8px"
      onclick="delUser('${id}')">🗑️ حذف</button>` : ''}`);
}

function saveUser(id) {
  const n = ($('u_n').value || '').trim();
  if (!n) { tst('⚠ أدخل الاسم'); return; }
  const us = getUsers();
  const first = !us.length;
  const r = first ? 'owner' : $('u_r').value;
  const p = ($('u_p').value || '').trim();

  if (id) {
    const i = us.findIndex(x => x.id === id);
    if (i < 0) return;
    // لا تترك التطبيق بلا مالك
    if (us[i].role === 'owner' && r !== 'owner'
        && us.filter(x => x.role === 'owner').length === 1) {
      tst('⚠ يجب أن يبقى مالك واحد على الأقل'); return;
    }
    us[i].name = n;
    us[i].role = r;
    if (p) us[i].pin = pinHash(p);
    if (USER && USER.id === id) USER = us[i];
  } else {
    const nu = { id: uid(), name: n, role: r, pin: p ? pinHash(p) : null };
    us.push(nu);
    if (first) { USER = nu; DB.set('session', nu.id); }
  }
  setUsers(us);
  closeSheet();
  applyRole();
  buildNav();
  tst('✅ تم الحفظ');
  renderUsers();
}

function delUser(id) {
  const us = getUsers();
  const u = us.find(x => x.id === id);
  if (!u) return;
  if (u.role === 'owner' && us.filter(x => x.role === 'owner').length === 1) {
    tst('⚠ لا يمكن حذف المالك الوحيد'); return;
  }
  if (!confirm('حذف «' + u.name + '»؟')) return;
  setUsers(us.filter(x => x.id !== id));
  if (USER && USER.id === id) { logout(); return; }
  closeSheet();
  tst('حُذف المستخدم');
  renderUsers();
}

/* حارس عام للعمليات المحمية */
function needOwner(what) {
  if (can(what)) return true;
  sheet(`<div class="grab"></div>
    <div style="text-align:center;padding:14px 0">
      <div style="font-size:40px">🔒</div>
      <h2 style="margin-top:9px">صلاحية المالك</h2>
      <p class="mut" style="margin-top:7px">
        هذه العملية متاحة للمالك فقط.<br>
        أنت مسجّل باسم <b style="color:var(--tx)">${esc(USER ? USER.name : '')}</b> (بائع).
      </p>
    </div>
    <button class="btn g sm" onclick="closeSheet();logout()">
      🚪 تسجيل الدخول كمالك</button>
    <button class="btn g sm" style="margin-top:8px" onclick="closeSheet()">إلغاء</button>`);
  return false;
}

/* ---------- NAV ---------- */
const NAV = [['s_home', '🏠', 'الرئيسية'], ['s_pos', '🛒', 'البيع'], ['s_stock', '📦', 'المخزون'], ['s_debt', '🤝', 'الديون'], ['s_rep', '📊', 'التقارير']];
function buildNav() {
  ['nav1', 'nav3', 'nav4', 'nav5'].forEach(id => {
    const el = $(id); if (!el) return;
    el.innerHTML = NAV.map(n => `<div data-t="${n[0]}" onclick="show('${n[0]}')"><span>${n[1]}</span>${n[2]}</div>`).join('');
  });
}
let curScr = 's_home';
function show(id) {
  document.querySelectorAll('.scr').forEach(s => s.classList.remove('on'));
  $(id).classList.add('on'); curScr = id;
  document.querySelectorAll('.nav div').forEach(d => d.classList.toggle('on', d.dataset.t === id));
  $('sh').classList.remove('on');
  if (id === 's_home') renderHome();
  if (id === 's_home') trialBanner();
  if (id === 's_more') renderMore();
  if (id === 's_store') renderStore();
  if (id === 's_alert') renderAlert();
  if (id === 's_sups') renderSups();
  if (id === 's_users') renderUsers();
  if (id === 's_labels') renderLabels();
  if (id === 's_pos') renderPos();
  if (id === 's_stock') renderStock();
  if (id === 's_debt') renderDebt();
  if (id === 's_rep') renderRep();
  if (id === 's_hist') renderHist();
  if (id === 's_setup') fillSetup();
  document.querySelectorAll('.body').forEach(b => b.scrollTop = 0);
}
window.onAndroidBack = function () {
  if ($('scanWrap').classList.contains('on')) { stopScan(); return true; }
  if ($('sh').classList.contains('on')) { $('sh').classList.remove('on'); return true; }
  if (curScr !== 's_home' && CFG) { show('s_home'); return true; }
  return false;
};
function sheet(html) { $('shIn').innerHTML = html; $('sh').classList.add('on'); }
function closeSheet() { $('sh').classList.remove('on'); }
$('sh').onclick = e => { if (e.target.id === 'sh') closeSheet(); };

/* ---------- SETUP ---------- */
function fillSetup() {
  if (!CFG) return;
  cf_name.value = CFG.name || ''; cf_owner.value = CFG.owner || ''; cf_phone.value = CFG.phone || '';
  cf_addr.value = CFG.addr || ''; cf_rc.value = CFG.rc || ''; cf_nif.value = CFG.nif || ''; cf_tva.value = CFG.tva ?? 19;
}
function saveSetup() {
  if (!cf_name.value.trim()) { tst('⚠ أدخل اسم المتجر'); return; }
  CFG = { name: cf_name.value.trim(), owner: cf_owner.value.trim(), phone: cf_phone.value.trim(), addr: cf_addr.value.trim(), rc: cf_rc.value.trim(), nif: cf_nif.value.trim(), tva: +cf_tva.value };
  DB.set('cfg', CFG); tst('✅ تم الحفظ'); show('s_home');
}

/* ---------- HOME ---------- */
function renderHome() {
  $('h_store').textContent = CFG?.name || 'متجري';
  const h = new Date().getHours();
  $('h_greet').textContent = (h < 12 ? 'صباح الخير' : h < 18 ? 'مساء الخير' : 'مساء الخير') + ' 👋';
  const t = SALES.filter(s => s.date.slice(0, 10) === today());
  $('k_today').textContent = fmt(t.reduce((a, s) => a + s.total, 0));
  $('k_cnt').textContent = t.length;
  // بطاقة مبيعات اليوم كاملة: للمالك فقط
  const kt = $('kToday');
  if (kt) kt.style.display = can('reports') ? '' : 'none';

  const profEl = $('k_prof');
  if (can('reports')) {
    profEl.textContent = fmt(t.reduce((a, s) => a + s.items.reduce((x, i) => x + (i.price - (i.cost || 0)) * i.qty, 0), 0));
    if (profEl.parentElement) profEl.parentElement.style.display = '';
  } else {
    if (profEl.parentElement) profEl.parentElement.style.display = 'none';
  }
  $('k_debt').textContent = fmt(CUSTS.reduce((a, c) => a + c.debt, 0));
  $('k_low').textContent = PRODS.filter(p => p.qty <= (p.min || 5)).length;
  homeAlert();
  const last = SALES.slice(-4).reverse();
  $('h_last').innerHTML = last.length ? last.map(s => `
    <div class="card" style="padding:10px 13px" onclick="viewSale('${s.id}')"><div class="row sp">
      <div class="row"><div class="ic" style="${s.pay === 'credit' ? 'background:rgba(255,92,92,.13)' : ''}">${s.pay === 'credit' ? '🤝' : '🧾'}</div>
      <div><b style="font-size:14px">فاتورة #${s.no}</b><div class="mut" style="font-size:11.5px">${payName(s.pay)} · ${s.date.slice(11, 16)}</div></div></div>
      <b style="${s.pay === 'credit' ? 'color:var(--dan)' : ''}">${fmt(s.total)} دج</b></div></div>`).join('')
    : `<div class="empty"><div>🧾</div>لا توجد عمليات بعد<br><small>اضغط «بيع جديد» للبدء</small></div>`;
}
const payName = p => ({ cash: 'نقداً', card: 'بطاقة CIB', baridi: 'BaridiMob', credit: 'كريدي (آجل)' }[p] || p);

/* ---------- POS ---------- */
function cats() { return [...new Set(PRODS.map(p => p.cat).filter(Boolean))]; }
let posCat = '';
function renderPos() {
  const cs = cats();
  $('pos_cats').innerHTML = `<div class="chip ${posCat === '' ? 'on' : ''}" onclick="posCat='';renderPos()">الكل</div>` +
    cs.map(c => `<div class="chip ${posCat === c ? 'on' : ''}" onclick="posCat='${esc(c)}';renderPos()">${esc(c)}</div>`).join('');
  const q = ($('pos_q').value || '').trim().toLowerCase();
  let list = PRODS.filter(p => (!posCat || p.cat === posCat) && (!q || p.name.toLowerCase().includes(q) || (p.bc || '').includes(q)));
  $('pos_grid').innerHTML = list.length ? list.map(p => `
    <div class="card" style="margin:0;padding:10px 5px;text-align:center;position:relative;${p.qty <= 0 ? 'opacity:.45' : ''}${isBulk(p) ? ';border-color:var(--gold)' : ''}" onclick="addCart('${p.id}')">
      ${p.qty <= 0 ? '<div class="badge">نفد</div>' : ''}
      ${isBulk(p) ? `<div style="position:absolute;top:-6px;right:-6px;background:var(--gold);color:#241a00;font-size:11px;font-weight:800;min-width:19px;height:19px;border-radius:10px;display:grid;place-items:center;padding:0 4px">⚖️</div>` : ''}
      <div style="font-size:23px">${p.emo || '📦'}</div>
      <div style="font-size:11px;margin-top:3px;line-height:1.3;height:28px;overflow:hidden">${esc(p.name)}</div>
      <b style="font-size:12.5px;color:var(--or2)">${fmt(p.price)} دج${
        isBulk(p) ? '<span style="font-size:9px;opacity:.75">/' + (p.unit||'كغ') + '</span>' : ''}</b>
      <div class="mut" style="font-size:9.5px">${qtyLabel(p, p.qty)}</div></div>`).join('')
    : `<div class="empty" style="grid-column:1/-1"><div>📦</div>لا توجد منتجات<br><small>أضف منتجاتك من «المخزون»</small></div>`;
  renderCart();
}
function addCart(id, q) {
  const p = PRODS.find(x => x.id === id); if (!p) return;
  // منتج بالوزن: افتح نافذة المبلغ/الكمية
  if (isBulk(p) && q === undefined) { openBulk(id); return; }
  if (p.qty <= 0) { tst('⚠ هذا المنتج نفد من المخزون'); return; }
  const e = CART.find(c => c.id === id);
  if (e) { if (e.qty + 1 > p.qty) { tst('⚠ الكمية المتوفرة: ' + p.qty); return; } e.qty++; }
  else CART.push({ id, name: p.name, price: p.price, cost: p.cost || 0, qty: q || 1, emo: p.emo });
  renderCart();
}
function chQty(i, d) {
  CART[i].qty += d;
  if (CART[i].qty <= 0) CART.splice(i, 1);
  renderCart();
}
function renderCart() {
  const cu = saleCust ? CUSTS.find(c => c.id === saleCust) : null;
  const pn = $('pc_n'), pi = $('pc_ic');
  if (pn) {
    if (cu) {
      pi.textContent = '👤';
      pn.textContent = cu.name + (cu.debt > 0 ? ' · دين ' + fmt(cu.debt) + ' دج' : '');
      pn.className = '';
      $('posCust').style.borderColor = 'var(--or)';
    } else {
      pi.textContent = '🧍';
      pn.textContent = 'زبون عابر — اضغط للاختيار';
      pn.className = 'mut';
      $('posCust').style.borderColor = 'var(--line)';
    }
  }
  const tot = CART.reduce((a, c) => a + c.price * c.qty, 0);
  // عدّ الأصناف: الكسرية تُحسب صنفاً واحداً
  $('c_n').textContent = CART.reduce((a, c) =>
    a + ((c.bulk || c.free) ? 1 : c.qty), 0);
  $('c_t').textContent = fmt(tot);
  const sub = $('c_sub');
  if (sub) {
    const tv = (CFG && CFG.tva) || 0;
    if (tot > 0 && tv) {
      const ht = tot / (1 + tv / 100);
      sub.textContent = 'HT ' + fmt(ht) + ' + TVA ' + fmt(tot - ht);
    } else sub.textContent = '';
  }
  const tb = $('totalBox');
  if (tb) tb.style.borderColor = tot > 0 ? 'var(--or)' : 'var(--line)';

  $('cart_list').innerHTML = CART.map((c, i) => {
    const frac = !!(c.bulk || c.free);
    return `<div class="row sp" style="padding:5px 0;font-size:13px;border-bottom:1px solid var(--line)">
      <span style="flex:1">${c.emo || '📦'} ${esc(c.name)}${
        c.bulk ? `<span class="mut" style="font-size:11px"> · ${qtyLabel(c, c.qty)}</span>` : ''}</span>
      <div class="row" style="gap:6px">
        ${frac
          ? `<button onclick="editLine(${i})" style="padding:3px 10px;border-radius:7px;border:0;background:var(--bg2);color:var(--or2);font-size:11.5px">تعديل</button>
             <button onclick="delLine(${i})" style="width:25px;height:25px;border-radius:7px;border:0;background:var(--bg2);color:var(--dan);font-size:13px">✕</button>`
          : `<button onclick="chQty(${i},-1)" style="width:25px;height:25px;border-radius:7px;border:0;background:var(--bg2);color:#fff;font-size:15px">−</button>
             <b style="min-width:18px;text-align:center">${c.qty}</b>
             <button onclick="chQty(${i},1)" style="width:25px;height:25px;border-radius:7px;border:0;background:var(--or);color:#fff;font-size:15px">+</button>`}
      </div><b style="min-width:62px;text-align:left">${fmt(c.price * c.qty)}</b></div>`;
  }).join('');
}

/* تعديل سطر كسري في السلة */
function editLine(i) {
  const c = CART[i];
  if (!c) return;
  if (c.free) {
    const v = prompt('المبلغ الجديد لـ ' + c.name + ':', c.price);
    if (v === null) return;
    const amt = +v;
    if (!amt || amt <= 0) { tst('⚠ مبلغ غير صالح'); return; }
    c.price = amt;
    renderCart();
    return;
  }
  CART.splice(i, 1);     // احذف ثم أعد الفتح للتعديل
  renderCart();
  openBulk(c.id);
}

function delLine(i) {
  CART.splice(i, 1);
  renderCart();
}
function clearCart() { CART = []; saleCust = null; renderCart(); }

/* ---------- PAYMENT ---------- */
function openPay() {
  if (!CART.length) { tst('⚠ السلة فارغة'); return; }
  if (!canAdd('sale')) return;
  const t = CART.reduce((a, c) => a + c.price * c.qty, 0);
  const cu = saleCust ? CUSTS.find(c => c.id === saleCust) : null;
  sheet(`<div class="grab"></div><h2 style="margin-bottom:3px">طريقة الدفع</h2>
    <div class="mut" style="margin-bottom:11px">المبلغ: <b style="color:var(--or2);font-size:18px">${fmt(t)} دج</b></div>

    <div class="card" style="padding:11px 13px;margin-bottom:12px" onclick="pickCust()">
      <div class="row">
        <div class="ic" style="${cu ? '' : 'background:rgba(141,166,190,.13)'}">${cu ? '👤' : '🧍'}</div>
        <div style="flex:1">
          <b style="font-size:14px">${cu ? esc(cu.name) : 'زبون عابر'}</b>
          <div class="mut" style="font-size:11.5px">${cu ? (cu.debt > 0 ? 'دين حالي: ' + fmt(cu.debt) + ' دج' : 'لا دين عليه') : 'اضغط لاختيار زبون مسجّل (اختياري)'}</div>
        </div>
        ${cu ? `<button onclick="event.stopPropagation();clearCust()" style="background:rgba(255,92,92,.15);border:0;color:var(--dan);padding:6px 10px;border-radius:9px;font-size:12px">إزالة</button>` : '<span style="color:var(--or2);font-size:13px">اختيار ›</span>'}
      </div>
    </div>

    <div class="li" onclick="pay('cash')"><div class="ic">💵</div><span style="flex:1">نقداً</span>›</div>
    <div class="li" onclick="pay('card')"><div class="ic">💳</div><span style="flex:1">بطاقة CIB / الذهبية</span>›</div>
    <div class="li" onclick="pay('baridi')"><div class="ic">📱</div><span style="flex:1">BaridiMob</span>›</div>
    <div class="li" onclick="payCredit()"><div class="ic" style="background:rgba(255,92,92,.13)">🤝</div>
      <div style="flex:1"><span>كريدي (آجل)</span>${cu ? '' : '<div class="mut" style="font-size:11px">يتطلب اختيار زبون</div>'}</div>›</div>`);
}

/* اختيار الزبون — مع بحث وإضافة سريعة */
function pickCust(forCredit) {
  if (forCredit === undefined && curScr === 's_pos' && !$('sh').classList.contains('on')) custFromPos = true;
  const list = [...CUSTS].sort((a, b) => a.name.localeCompare(b.name, 'ar'));
  sheet(`<div class="grab"></div>
    <div class="row sp" style="margin-bottom:9px"><h2>اختر الزبون</h2>
      <button class="chip on" style="border:0" onclick="quickCust(${forCredit ? 1 : 0})">＋ زبون جديد</button></div>
    <div class="inp" style="padding:11px;margin-bottom:10px">🔍<input id="cq" placeholder="ابحث بالاسم أو الهاتف..." oninput="filtCust(${forCredit ? 1 : 0})"></div>
    ${forCredit ? '' : `<div class="li" onclick="setCust(null,0)"><div class="ic" style="background:rgba(141,166,190,.13)">🧍</div>
      <div style="flex:1"><b>زبون عابر</b><div class="mut" style="font-size:11.5px">بدون تسجيل</div></div>
      ${!saleCust ? '<span class="pill">الحالي</span>' : '›'}</div>`}
    <div id="cust_l">${custRows(list, forCredit)}</div>`);
}
function custRows(list, forCredit) {
  if (!list.length) return `<div class="empty" style="padding:26px"><div style="font-size:40px">🤝</div>لا يوجد زبائن<br><small>اضغط «＋ زبون جديد»</small></div>`;
  return list.map(c => `<div class="li" onclick="setCust('${c.id}',${forCredit ? 1 : 0})">
    <div class="ic">👤</div>
    <div style="flex:1"><b>${esc(c.name)}</b>
      <div class="mut" style="font-size:11.5px">${c.phone ? esc(c.phone) + ' · ' : ''}${c.debt > 0 ? '<span style="color:var(--dan)">دين ' + fmt(c.debt) + ' دج</span>' : 'لا دين'}</div></div>
    ${saleCust === c.id ? '<span class="pill">الحالي</span>' : '›'}</div>`).join('');
}
function filtCust(forCredit) {
  const q = ($('cq').value || '').trim().toLowerCase();
  const l = CUSTS.filter(c => !q || c.name.toLowerCase().includes(q) || (c.phone || '').includes(q));
  $('cust_l').innerHTML = custRows(l, forCredit);
}
function setCust(id, forCredit) {
  saleCust = id;
  if (forCredit) { doCredit(); return; }
  if (custFromPos) { custFromPos = false; closeSheet(); renderCart(); tst(id ? '✅ الزبون: ' + CUSTS.find(c=>c.id===id).name : 'زبون عابر'); return; }
  openPay();
}
let custFromPos = false;
function clearCust() { saleCust = null; openPay(); }

/* إضافة زبون سريعة من داخل شاشة الدفع */
function quickCust(forCredit) {
  sheet(`<div class="grab"></div><h2 style="margin-bottom:12px">زبون جديد</h2>
    <div class="fld"><label class="lbl">الاسم *</label><div class="inp">👤<input id="qc_n" placeholder="اسم الزبون"></div></div>
    <div class="fld"><label class="lbl">الهاتف</label><div class="inp">📞<input id="qc_p" inputmode="tel" placeholder="05 XX XX XX XX"></div></div>
    <button class="btn" onclick="saveQuickCust(${forCredit ? 1 : 0})">حفظ واختيار</button>
    <button class="btn g sm" style="margin-top:8px" onclick="pickCust(${forCredit ? 1 : 0})">رجوع</button>`);
}
function saveQuickCust(forCredit) {
  const n = $('qc_n').value.trim();
  if (!n) { tst('⚠ أدخل اسم الزبون'); return; }
  if (!canAdd('cust')) return;
  const c = { id: uid(), name: n, phone: $('qc_p').value.trim(), debt: 0, spent: 0, visits: 0, last: today(), ledger: [] };
  CUSTS.push(c); save();
  saleCust = c.id;
  tst('✅ أُضيف ' + n);
  if (forCredit) doCredit(); else openPay();
}

function payCredit() {
  if (!saleCust) { pickCust(true); return; }
  doCredit();
}
function doCredit() {
  if (!saleCust) { tst('⚠ اختر زبوناً أولاً'); return; }
  pay('credit', saleCust);
}

function pay(mode, cid) {
  const sub = CART.reduce((a, c) => a + c.price * c.qty, 0);
  const tvaR = CFG?.tva || 0;
  const ht = tvaR ? sub / (1 + tvaR / 100) : sub;
  const who = cid || saleCust || null;
  const sale = {
    id: uid(), no: 1000 + SALES.length + 1, date: new Date().toISOString(),
    items: CART.map(c => ({ ...c })), total: sub, ht: ht, tva: sub - ht,
    pay: mode, cust: who
  };
  CART.forEach(c => { const p = PRODS.find(x => x.id === c.id); if (p) p.qty -= c.qty; });

  if (who) {
    const cu = CUSTS.find(x => x.id === who);
    if (cu) {
      sale.custName = cu.name;
      cu.last = today();
      cu.spent = (cu.spent || 0) + sub;         // إجمالي مشترياته
      cu.visits = (cu.visits || 0) + 1;          // عدد زياراته
      if (mode === 'credit') cu.debt += sub;     // الدين يزيد فقط في الآجل
    }
  }

  SALES.push(sale); save(); lastSale = sale;
  saleCust = null;                                // تصفير لأجل الفاتورة القادمة
  viewingOld = null;                              // بيع جديد لا عرض فاتورة قديمة
  closeSheet(); buildReceipt(sale); show('s_rcpt');
}

/* ============================================================
   v2.9 — إرجاع المنتجات
   لا نحذف الفاتورة الأصلية — ننشئ فاتورة إرجاع مرتبطة بها
   ============================================================ */

/* الكمية المرجَعة سابقاً من صنف في فاتورة */
function returnedQty(saleId, itemId) {
  let n = 0;
  SALES.forEach(s => {
    if (s.ret && s.refId === saleId) {
      (s.items || []).forEach(i => { if (i.id === itemId) n += Math.abs(i.qty); });
    }
  });
  return n;
}

/* هل الفاتورة مرجَعة كلياً؟ */
function fullyReturned(s) {
  if (s.ret) return false;
  return (s.items || []).every(i => returnedQty(s.id, i.id) >= i.qty);
}

/* مجموع ما أُرجع من فاتورة */
function returnedTotal(saleId) {
  let t = 0;
  SALES.forEach(s => { if (s.ret && s.refId === saleId) t += Math.abs(s.total); });
  return t;
}

/* ============ نافذة الإرجاع ============ */
let retSale = null, retQty = {};

function openReturn(id) {
  const s = SALES.find(x => x.id === id);
  if (!s) { tst('⚠ الفاتورة غير موجودة'); return; }
  if (s.ret) { tst('⚠ هذه فاتورة إرجاع'); return; }

  retSale = s;
  retQty = {};
  // مبدئياً: لا شيء محدّد
  drawReturn();
}

function drawReturn() {
  const s = retSale;
  if (!s) return;
  const items = (s.items || []).map(i => {
    const done = returnedQty(s.id, i.id);
    return { ...i, done, avail: i.qty - done };
  });
  const canRet = items.filter(i => i.avail > 0);
  const total = items.reduce((a, i) => a + (retQty[i.id] || 0) * i.price, 0);
  const nSel = items.reduce((a, i) => a + (retQty[i.id] || 0), 0);

  if (!canRet.length) {
    sheet(`<div class="grab"></div>
      <div style="text-align:center;padding:16px 0">
        <div style="font-size:42px">✅</div>
        <h2 style="margin-top:10px">أُرجعت كاملة</h2>
        <p class="mut" style="margin-top:7px">
          كل أصناف هذه الفاتورة أُرجعت سابقاً.</p>
      </div>
      <button class="btn g sm" onclick="closeSheet()">إغلاق</button>`);
    return;
  }

  sheet(`<div class="grab"></div>
    <h2 style="margin-bottom:3px">↩️ إرجاع من الفاتورة #${s.no}</h2>
    <p class="mut" style="margin-bottom:12px">
      ${s.date.slice(0, 10).split('-').reverse().join('/')} ·
      ${fmt(s.total)} دج · ${payName(s.pay)}</p>

    <label class="lbl">حدّد ما يريد الزبون إرجاعه</label>
    <div class="card" style="padding:10px;margin-bottom:11px">
      ${items.map(i => {
        const q = retQty[i.id] || 0;
        const out = i.avail <= 0;
        return `<div class="row sp" style="padding:8px 0;border-bottom:1px solid var(--line);
             font-size:13px;${out ? 'opacity:.4' : ''}">
          <div style="flex:1;min-width:0">
            <b>${esc(i.name)}</b>
            <div class="mut" style="font-size:11px;margin-top:1px">
              ${fmt(i.price)} دج × ${i.bulk ? qtyLabel(i, i.qty) : i.qty}
              ${i.done ? ` · <span style="color:var(--or2)">أُرجع ${i.done}</span>` : ''}
            </div>
          </div>
          ${out ? '<span class="mut" style="font-size:11px">مُرجَع</span>' : `
          <div class="row" style="gap:6px">
            <button onclick="retChange('${i.id}',-1)" style="width:26px;height:26px;border-radius:7px;
              border:0;background:var(--bg2);color:#fff;font-size:15px">−</button>
            <b style="min-width:20px;text-align:center;${q ? 'color:var(--or2)' : ''}">${q}</b>
            <button onclick="retChange('${i.id}',1)" style="width:26px;height:26px;border-radius:7px;
              border:0;background:var(--or);color:#fff;font-size:15px">+</button>
          </div>`}
        </div>`;
      }).join('')}
      <div class="row sp" style="padding-top:9px;margin-top:3px">
        <span class="chip" onclick="retAll()">إرجاع الكل</span>
        ${nSel ? `<span class="chip" onclick="retNone()">إلغاء التحديد</span>` : ''}
      </div>
    </div>

    <div class="card" style="background:linear-gradient(135deg,#16293E,#1E3F5C);
         padding:13px;text-align:center">
      <div class="mut" style="font-size:12px">المبلغ المُرجَع للزبون</div>
      <div style="font-size:28px;font-weight:800;color:var(--dan);margin-top:2px">
        ${fmt(total)} <span style="font-size:14px">دج</span></div>
    </div>

    ${s.pay === 'credit' && s.cust ? `
      <div class="card" style="padding:12px;margin-top:10px;border-color:var(--or)">
        <div class="mut" style="font-size:12px">
          🤝 فاتورة آجلة — سيُخصم <b style="color:var(--or2)">${fmt(total)} دج</b>
          من دين <b style="color:var(--tx)">${esc(s.custName || '')}</b></div>
      </div>` : ''}

    <div class="card" style="padding:12px;margin-top:10px">
      <div class="mut" style="font-size:11.5px;line-height:1.8">
        ℹ️ ستُعاد الكميات للمخزون، وتُسجَّل فاتورة إرجاع مرتبطة.<br>
        الفاتورة الأصلية تبقى في السجل كما هي.</div>
    </div>

    <button class="btn d" style="margin-top:12px" onclick="doReturn()"
      ${!nSel ? 'disabled style="opacity:.5;margin-top:12px"' : ''}>
      ↩️ ${nSel ? 'تأكيد إرجاع ' + nSel + ' قطعة' : 'حدّد الأصناف أولاً'}</button>
    <button class="btn g sm" style="margin-top:8px" onclick="closeSheet()">إلغاء</button>`);
}

function retChange(itemId, d) {
  const s = retSale;
  const it = (s.items || []).find(i => i.id === itemId);
  if (!it) return;
  const avail = it.qty - returnedQty(s.id, itemId);
  const cur = retQty[itemId] || 0;
  const step = it.bulk ? Math.min(avail, 1) : 1;
  let v = cur + d * (it.bulk ? avail : 1);
  if (it.bulk) v = d > 0 ? avail : 0;      // الوزن: كل أو لا شيء
  v = Math.max(0, Math.min(avail, v));
  if (v) retQty[itemId] = v; else delete retQty[itemId];
  drawReturn();
}

function retAll() {
  const s = retSale;
  retQty = {};
  (s.items || []).forEach(i => {
    const avail = i.qty - returnedQty(s.id, i.id);
    if (avail > 0) retQty[i.id] = avail;
  });
  drawReturn();
}

function retNone() { retQty = {}; drawReturn(); }

/* ============ تنفيذ الإرجاع ============ */
function doReturn() {
  const s = retSale;
  if (!s) return;
  const ids = Object.keys(retQty);
  if (!ids.length) return;

  const retItems = [];
  ids.forEach(id => {
    const it = (s.items || []).find(i => i.id === id);
    if (!it) return;
    retItems.push({ ...it, qty: retQty[id] });
  });

  const total = retItems.reduce((a, i) => a + i.price * i.qty, 0);
  const tvaR = (CFG && CFG.tva) || 0;
  const ht = tvaR ? total / (1 + tvaR / 100) : total;

  if (!confirm('تأكيد إرجاع ' + fmt(total) + ' دج؟\n\n'
    + retItems.map(i => '• ' + i.name + ' × ' + (i.bulk ? qtyLabel(i, i.qty) : i.qty)).join('\n'))) return;

  // 1) أعد الكميات للمخزون
  retItems.forEach(i => {
    const p = PRODS.find(x => x.id === i.id);
    if (p) p.qty = Math.round((p.qty + i.qty) * 10000) / 10000;
  });

  // 2) فاتورة إرجاع (قيم سالبة)
  const rs = {
    id: uid(),
    no: 1000 + SALES.length + 1,
    date: new Date().toISOString(),
    items: retItems.map(i => ({ ...i, qty: -i.qty })),
    total: -total, ht: -ht, tva: -(total - ht),
    pay: s.pay,
    cust: s.cust || null,
    custName: s.custName,
    ret: 1,                    // علم الإرجاع
    refId: s.id,               // الفاتورة الأصلية
    refNo: s.no
  };

  // 3) الزبون: خصم من الدين أو من المشتريات
  if (s.cust) {
    const cu = CUSTS.find(c => c.id === s.cust);
    if (cu) {
      cu.spent = Math.max(0, (cu.spent || 0) - total);
      if (s.pay === 'credit') {
        cu.debt = Math.max(0, cu.debt - total);
        cu.ledger = cu.ledger || [];
        cu.ledger.push({ t: 'ret', v: total, d: new Date().toISOString(),
                         note: 'إرجاع فاتورة #' + s.no });
      }
    }
  }

  SALES.push(rs);
  if (!save()) return;
  if (USE_IDB) { IDB.put(rs).catch(() => {}); }

  retSale = null; retQty = {};
  closeSheet();
  tst('✅ أُرجع ' + fmt(total) + ' دج للزبون');

  // اعرض إيصال الإرجاع
  lastSale = rs;
  viewingOld = rs.id;
  buildReceipt(rs);
  show('s_rcpt');
}

/* ---------- RECEIPT ---------- */
function buildReceipt(s) {
  const isRet = !!s.ret;
  $('rc_body').innerHTML = `
    ${isRet ? `<div style="text-align:center;background:#FFE8E8;color:#B02020;
      padding:5px;border-radius:6px;font-weight:800;font-size:13px;margin-bottom:6px">
      ↩️ إيصال إرجاع — مرجع الفاتورة #${s.refNo}</div>` : ''}
    ${CFG?.logo ? `<div style="text-align:center;margin-bottom:6px"><img src="${CFG.logo}" style="max-width:96px;max-height:60px"></div>` : ''}
    <div style="text-align:center;font-weight:800;font-size:15px">${esc(CFG?.name || 'متجري')}</div>
    ${CFG?.addr ? `<div style="text-align:center;font-size:11px">${esc(CFG.addr)}</div>` : ''}
    ${CFG?.phone ? `<div style="text-align:center;font-size:11px">${esc(CFG.phone)}</div>` : ''}
    ${CFG?.rc || CFG?.nif ? `<div style="text-align:center;font-size:10px">${CFG.rc ? 'RC: ' + esc(CFG.rc) : ''} ${CFG.nif ? '· NIF: ' + esc(CFG.nif) : ''}</div>` : ''}
    <div class="dash"></div>
    ${s.items.map(i => `<div class="l"><span>${esc(i.name)}${
      i.bulk ? ' ' + qtyLabel(i, i.qty) : (i.free ? '' : ' × ' + i.qty)
    }</span><span>${fmt(i.price * i.qty)}</span></div>`).join('')}
    <div class="dash"></div>
    ${s.tva > 0 ? `<div class="l"><span>المجموع HT</span><span>${s.ht.toFixed(2)}</span></div>
    <div class="l"><span>TVA ${CFG.tva}%</span><span>${s.tva.toFixed(2)}</span></div>` : ''}
    <div class="l" style="font-weight:800;font-size:15px"><span>الإجمالي</span><span>${fmt(s.total)} دج</span></div>
    <div class="dash"></div>
    <div class="l"><span>الدفع</span><span>${payName(s.pay)}</span></div>
    ${s.custName ? `<div class="l"><span>الزبون</span><span>${esc(s.custName)}</span></div>` : ''}
    <div style="text-align:center;margin-top:9px;font-size:10.5px">فاتورة #${s.no} · ${s.date.slice(0, 10).split('-').reverse().join('/')} ${s.date.slice(11, 16)}<br>${esc(CFG?.footer || 'شكراً لزيارتكم 🌿')}</div>`;
  rcptActions();
}
function rcptText(s) {
  let L = [];
  L.push(CFG?.name || 'متجري');
  if (CFG?.phone) L.push(CFG.phone);
  if (CFG?.rc) L.push('RC: ' + CFG.rc);
  L.push('------------------------------');
  s.items.forEach(i => L.push(`${i.name} x${i.qty}  ${fmt(i.price * i.qty)}`));
  L.push('------------------------------');
  if (s.tva > 0) { L.push(`HT: ${s.ht.toFixed(2)}`); L.push(`TVA ${CFG.tva}%: ${s.tva.toFixed(2)}`); }
  L.push(`TOTAL: ${fmt(s.total)} DA`);
  L.push(payName(s.pay));
  L.push(`#${s.no}  ${s.date.slice(0, 10)} ${s.date.slice(11, 16)}`);
  L.push('Merci / شكرا');
  return L.join('\n');
}
function doPrint() {
  const html = `<html dir="rtl"><head><meta charset="utf-8"><style>
    body{font-family:monospace;width:280px;margin:0 auto;padding:10px;font-size:12px;line-height:1.8}
    .l{display:flex;justify-content:space-between}.d{border-top:1px dashed #555;margin:7px 0}
    </style></head><body>${$('rc_body').innerHTML.replace(/class="dash"/g, 'class="d"')}</body></html>`;
  if (AND) { try { Android.printReceipt(html); return; } catch (e) {} }
  const w = window.open('', '_blank'); w.document.write(html); w.print();
}
function doThermal() {
  if (!AND) { tst('⚠ الطباعة الحرارية متاحة في تطبيق أندرويد فقط'); return; }
  if (!PRINTER) { openPrinters(); return; }
  try { Android.printThermal(PRINTER.mac, rcptText(lastSale)); } catch (e) { tst('❌ خطأ: ' + e); }
}
function openPrinters() {
  if (!AND) { tst('⚠ متاح في تطبيق أندرويد فقط'); return; }
  let list = []; try { list = JSON.parse(Android.listPrinters()); } catch (e) {}
  sheet(`<div class="grab"></div><h2 style="margin-bottom:4px">الطابعة الحرارية</h2>
    <p class="mut" style="margin-bottom:12px">اقرن الطابعة من إعدادات بلوتوث الهاتف أولاً، ثم اخترها هنا.</p>
    ${list.length ? list.map(p => `<div class="li" onclick="pickPrinter('${p.mac}','${esc(p.name)}')">
      <div class="ic">🖨️</div><div style="flex:1"><b>${esc(p.name)}</b><div class="mut" style="font-size:11px">${p.mac}</div></div>
      ${PRINTER?.mac === p.mac ? '<span class="pill">مختارة</span>' : '›'}</div>`).join('')
      : `<div class="empty"><div>🖨️</div>لا توجد أجهزة مقترنة<br><small>فعّل البلوتوث واقرن الطابعة من إعدادات الهاتف</small></div>`}`);
}
function pickPrinter(mac, name) {
  PRINTER = { mac, name }; DB.set('printer', PRINTER);
  $('pr_st').textContent = name; closeSheet(); tst('✅ تم اختيار: ' + name);
}
function doShare() {
  const txt = rcptText(lastSale);
  if (AND) { try { Android.shareText(txt); return; } catch (e) {} }
  if (navigator.share) navigator.share({ title: 'فاتورة', text: txt }).catch(function(){});
  else { try { navigator.clipboard.writeText(txt); } catch (e) {} tst('📋 تم نسخ الفاتورة'); }
}
/* أزرار أسفل الفاتورة — تختلف بين بيع جديد وعرض قديم */
function rcptActions() {
  const el = $('rc_actions');
  if (!el) return;
  const hd = $('rc_head');
  if (viewingOld) {
    if (hd) hd.style.display = 'none';
    const sv = SALES.find(x => x.id === viewingOld);
    const isRet = sv && sv.ret;
    const done = sv && !isRet && fullyReturned(sv);
    el.innerHTML = `
      ${(sv && !isRet) ? `<button class="btn sm" style="margin-top:8px;background:linear-gradient(135deg,#C85A2A,#A03D18);box-shadow:none"
        onclick="openReturn('${viewingOld}')" ${done ? 'disabled style="opacity:.45;margin-top:8px"' : ''}>
        ↩️ ${done ? 'أُرجعت كاملة' : 'إرجاع منتج'}</button>` : ''}
      <div class="row" style="gap:8px;margin-top:8px">
        <button class="btn g sm" style="flex:1" onclick="viewingOld=null;show('s_hist')">↩ رجوع للسجل</button>
        <button class="btn d sm" style="flex:1" onclick="delOneSale('${viewingOld}')">🗑️ حذف</button>
      </div>`;
  } else {
    if (hd) hd.style.display = '';
    el.innerHTML = `<button class="btn" style="margin-top:8px"
      onclick="viewingOld=null;clearCart();show('s_pos')">بيع جديد ›</button>`;
  }
}

function viewSale(id) {
  const s = SALES.find(x => x.id === id);
  if (!s) return;
  lastSale = s;
  viewingOld = id;          // نعرض فاتورة قديمة ← أظهر زر الحذف
  buildReceipt(s);
  show('s_rcpt');
}

/* ---------- BARCODE SCANNER v1.5 — سريع ودقيق ---------- */
let scanStream = null, scanLoop = null, zReader = null, zHints = null;
let multiMode = false, multiList = [], busy = false;
let cvA = null, ctxA = null, cvB = null, ctxB = null;
let torchTrack = null, torchOn = false, camTrack = null;
let recent = {}, frameNo = 0, tries = 0, startT = 0;
let zoomCap = null, curZoom = 1, bdReady = false;

function scanMsg(t) { const e = $('scanHint'); if (e) e.textContent = t; }

function initZ() {
  if (zReader || !window.ZXing) return;
  try {
    zHints = new Map();
    // صيغ المنتجات الشائعة فقط = بحث أسرع بكثير
    zHints.set(ZXing.DecodeHintType.POSSIBLE_FORMATS, [
      ZXing.BarcodeFormat.EAN_13, ZXing.BarcodeFormat.EAN_8,
      ZXing.BarcodeFormat.UPC_A, ZXing.BarcodeFormat.UPC_E,
      ZXing.BarcodeFormat.CODE_128, ZXing.BarcodeFormat.CODE_39,
      ZXing.BarcodeFormat.ITF, ZXing.BarcodeFormat.QR_CODE
    ]);
    zReader = new ZXing.MultiFormatReader();
    zReader.setHints(zHints);
  } catch (e) { zReader = null; }
}

async function startScan(mode) {
  scanMode = mode;
  multiMode = (mode === 'multi');
  multiList = []; recent = {}; busy = false; frameNo = 0; tries = 0;
  $('scanWrap').classList.add('on');
  $('multiBar').style.display = multiMode ? 'block' : 'none';
  renderMulti();
  scanMsg('جارٍ فتح الكاميرا...');

  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    scanMsg('الكاميرا غير متاحة'); tst('⚠ استعمل الإدخال اليدوي'); return;
  }

  // 1280×720 = التوازن الأمثل: واضح بما يكفي وسريع في المعالجة
  const cfgs = [
    { video: { facingMode: { exact: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { ideal: 30 } } },
    { video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } } },
    { video: { facingMode: 'environment' } },
    { video: true }
  ];
  let stream = null, lastErr = null;
  for (const c of cfgs) {
    try { stream = await navigator.mediaDevices.getUserMedia(c); break; }
    catch (e) { lastErr = e; }
  }
  if (!stream) {
    const n = (lastErr && lastErr.name) || '';
    let m = 'تعذّر فتح الكاميرا';
    if (n === 'NotAllowedError') m = 'إذن الكاميرا مرفوض — فعّله من إعدادات التطبيق';
    else if (n === 'NotFoundError') m = 'لا توجد كاميرا';
    else if (n === 'NotReadableError') m = 'الكاميرا مستعملة من تطبيق آخر';
    scanMsg(m); tst('⚠ ' + m); return;
  }

  scanStream = stream;
  const vid = $('scanVid');
  vid.srcObject = stream;
  vid.setAttribute('playsinline', 'true');
  try { await vid.play(); } catch (e) {}

  try {
    const track = stream.getVideoTracks()[0];
    torchTrack = camTrack = track;
    const caps = track.getCapabilities ? track.getCapabilities() : {};
    const adv = [];
    if (caps.focusMode && caps.focusMode.includes('continuous')) adv.push({ focusMode: 'continuous' });
    if (caps.exposureMode && caps.exposureMode.includes('continuous')) adv.push({ exposureMode: 'continuous' });
    if (adv.length) { try { await track.applyConstraints({ advanced: adv }); } catch (e) {} }
    $('torchBtn').style.display = caps.torch ? 'block' : 'none';
    if (caps.zoom) {
      zoomCap = caps.zoom; curZoom = caps.zoom.min || 1;
      $('zoomBar').style.display = 'flex';
      $('zoomVal').textContent = curZoom.toFixed(1) + '×';
    } else { zoomCap = null; $('zoomBar').style.display = 'none'; }
  } catch (e) {}

  initZ();
  if (!cvA) { cvA = document.createElement('canvas'); ctxA = cvA.getContext('2d', { willReadFrequently: true, alpha: false }); }
  if (!cvB) { cvB = document.createElement('canvas'); ctxB = cvB.getContext('2d', { willReadFrequently: true, alpha: false }); }

  scanMsg(multiMode ? 'امسح المنتجات واحداً تلو الآخر' : 'وجّه الكاميرا نحو الباركود');
  startT = Date.now();

  // حلقة بـ requestAnimationFrame = أسرع ما يمكن دون تعليق الواجهة
  loopScan(vid);
}

function loopScan(vid) {
  if (!scanStream) return;
  scanLoop = requestAnimationFrame(() => loopScan(vid));
  if (busy) return;
  tickFast(vid);
}

/* ===== الحلقة السريعة ===== */
async function tickFast(vid) {
  if (!vid.videoWidth) return;
  busy = true;
  frameNo++;
  try {
    const VW = vid.videoWidth, VH = vid.videoHeight;

    // منطقة المسح: الإطار البرتقالي (ثابتة = لا حسابات زائدة)
    const cw = Math.floor(VW * 0.88), ch = Math.floor(VH * 0.30);
    const cx = Math.floor((VW - cw) / 2), cy = Math.floor((VH - ch) / 2);

    if (cvA.width !== cw || cvA.height !== ch) { cvA.width = cw; cvA.height = ch; }
    ctxA.drawImage(vid, cx, cy, cw, ch, 0, 0, cw, ch);

    // ===== المرحلة 1: المحاولة السريعة (كل إطار) =====
    // الكاشف الأصلي — سريع جداً (مسرّع بالعتاد)
    if (window._bd) {
      try {
        const r = await window._bd.detect(cvA);
        if (r && r.length && r[0].rawValue) { hit(r[0].rawValue); busy = false; return; }
      } catch (e) {}
    }
    // ZXing على الصورة الخام
    let c = zDecode(cvA);
    if (c) { hit(c); busy = false; return; }

    tries++;

    // ===== المرحلة 2: معالجة خفيفة (كل إطارين) =====
    if (frameNo % 2 === 0) {
      const img = ctxA.getImageData(0, 0, cw, ch);
      // تمديد تباين سريع — رخيص جداً وفعّال
      fastContrast(img.data);
      ctxA.putImageData(img, 0, 0);
      c = zDecode(cvA);
      if (c) { hit(c); busy = false; return; }
    }

    // ===== المرحلة 3: الثقيلة فقط بعد فشل متكرر =====
    // لا تعمل إلا إذا لم يُقرأ شيء بعد ~20 محاولة (≈1.5 ثانية)
    if (tries > 20 && frameNo % 4 === 0) {
      const img2 = ctxA.getImageData(0, 0, cw, ch);
      // عتبة تكيّفية مبسّطة وسريعة (شبكة بلوكات بدل نافذة لكل بكسل)
      blockThreshold(img2.data, cw, ch);
      ctxA.putImageData(img2, 0, 0);
      c = zDecode(cvA);
      if (c) { hit(c); busy = false; return; }

      // تدوير 90° للباركود العمودي
      if (frameNo % 8 === 0) {
        if (cvB.width !== ch || cvB.height !== cw) { cvB.width = ch; cvB.height = cw; }
        ctxB.save();
        ctxB.translate(ch / 2, cw / 2);
        ctxB.rotate(Math.PI / 2);
        ctxB.drawImage(cvA, -cw / 2, -ch / 2);
        ctxB.restore();
        c = zDecode(cvB);
        if (c) { hit(c); busy = false; return; }
      }
    }

    // إرشاد المستخدم إن طال الأمر
    if (tries === 45) scanMsg('💡 قرّب الهاتف أو استعمل ＋ للتكبير');
    if (tries === 90) scanMsg('💡 جرّب 🔦 الفلاش أو أمِل الهاتف قليلاً');
  } catch (e) {}
  busy = false;
}

function zDecode(cv) {
  if (!zReader) return null;
  try {
    const ctx = cv.getContext('2d');
    const d = ctx.getImageData(0, 0, cv.width, cv.height);
    const lum = new ZXing.RGBLuminanceSource(toLum(d.data, cv.width, cv.height), cv.width, cv.height);
    const bmp = new ZXing.BinaryBitmap(new ZXing.HybridBinarizer(lum));
    const res = zReader.decode(bmp, zHints);
    zReader.reset();
    return res ? res.getText() : null;
  } catch (e) {
    try { zReader.reset(); } catch (er) {}
    return null;
  }
}

function toLum(data, w, h) {
  const out = new Uint8ClampedArray(w * h);
  for (let i = 0, j = 0; i < data.length; i += 4, j++) {
    out[j] = (data[i] * 306 + data[i + 1] * 601 + data[i + 2] * 117) >> 10;
  }
  return out;
}

/* تمديد تباين سريع — عيّنة جزئية للسرعة */
function fastContrast(d) {
  let lo = 255, hi = 0;
  for (let i = 0; i < d.length; i += 64) {
    const g = d[i];
    if (g < lo) lo = g;
    if (g > hi) hi = g;
  }
  const range = Math.max(1, hi - lo);
  if (range > 200) return;
  const sc = 255 / range;
  for (let i = 0; i < d.length; i += 4) {
    let v = (d[i] * 306 + d[i + 1] * 601 + d[i + 2] * 117) >> 10;
    v = (v - lo) * sc;
    if (v < 0) v = 0; else if (v > 255) v = 255;
    d[i] = d[i + 1] = d[i + 2] = v;
  }
}

/* عتبة بالبلوكات — أسرع 10× من Bradley مع نتيجة مشابهة */
function blockThreshold(d, w, h) {
  const B = 32;
  const cols = Math.ceil(w / B), rows = Math.ceil(h / B);
  const means = new Float32Array(cols * rows);
  for (let by = 0; by < rows; by++) {
    for (let bx = 0; bx < cols; bx++) {
      let sum = 0, n = 0;
      const y0 = by * B, y1 = Math.min(h, y0 + B);
      const x0 = bx * B, x1 = Math.min(w, x0 + B);
      for (let y = y0; y < y1; y += 2) {
        let idx = (y * w + x0) * 4;
        for (let x = x0; x < x1; x += 2, idx += 8) {
          sum += (d[idx] * 306 + d[idx + 1] * 601 + d[idx + 2] * 117) >> 10;
          n++;
        }
      }
      means[by * cols + bx] = n ? sum / n : 128;
    }
  }
  for (let y = 0; y < h; y++) {
    const by = (y / B) | 0;
    let idx = y * w * 4;
    for (let x = 0; x < w; x++, idx += 4) {
      const bx = (x / B) | 0;
      const g = (d[idx] * 306 + d[idx + 1] * 601 + d[idx + 2] * 117) >> 10;
      const v = g > means[by * cols + bx] * 0.96 ? 255 : 0;
      d[idx] = d[idx + 1] = d[idx + 2] = v;
    }
  }
}

/* التحقق من رقم المراقبة */
function validCode(code) {
  if (!code || code.length < 4) return false;
  if (/^\d{8}$|^\d{12}$|^\d{13}$/.test(code)) {
    const d = code.split('').map(Number);
    const chk = d.pop();
    let sum = 0;
    d.reverse().forEach((n, i) => { sum += n * (i % 2 === 0 ? 3 : 1); });
    return ((10 - (sum % 10)) % 10) === chk;
  }
  return true;
}

/* قبول فوري — الـ checksum يكفي للتحقق، لا حاجة لقراءة مرتين */
function hit(code) {
  code = String(code).trim();
  if (!validCode(code)) return false;

  const now = Date.now();
  if (recent[code] && now - recent[code] < 1500) return false;
  recent[code] = now;
  tries = 0;

  if (navigator.vibrate) navigator.vibrate(80);
  beep(); flash();

  if (multiMode) {
    const p = PRODS.find(x => x.bc === code);
    const ex = multiList.find(m => m.code === code);
    if (ex) ex.qty++;
    else multiList.push({ code, qty: 1, prod: p || null });
    renderMulti();
    scanMsg(p ? '✅ ' + p.name : '⚠ غير مسجّل: ' + code);
    return true;
  }
  stopScan();
  onCode(code);
  return true;
}
function onHit(c) { return hit(c); }

async function setZoom(dir) {
  if (!zoomCap || !camTrack) return;
  const step = (zoomCap.step || 0.1) * 4;
  curZoom = Math.min(zoomCap.max, Math.max(zoomCap.min, curZoom + dir * step));
  try {
    await camTrack.applyConstraints({ advanced: [{ zoom: curZoom }] });
    $('zoomVal').textContent = curZoom.toFixed(1) + '×';
  } catch (e) {}
}

async function refocus(ev) {
  if (!camTrack) return;
  try {
    const caps = camTrack.getCapabilities ? camTrack.getCapabilities() : {};
    if (caps.focusMode && caps.focusMode.includes('single-shot')) {
      await camTrack.applyConstraints({ advanced: [{ focusMode: 'single-shot' }] });
      setTimeout(() => {
        camTrack.applyConstraints({ advanced: [{ focusMode: 'continuous' }] }).catch(function(){});
      }, 800);
      scanMsg('🎯 إعادة التركيز...');
      setTimeout(() => scanMsg(multiMode ? 'امسح المنتجات واحداً تلو الآخر' : 'وجّه الكاميرا نحو الباركود'), 1000);
    }
  } catch (e) {}
}

function flash() {
  const b = document.querySelector('.scanBox');
  if (!b) return;
  b.style.borderColor = '#27C07A';
  setTimeout(() => { b.style.borderColor = 'var(--or)'; }, 260);
}

let actx = null;
function beep() {
  try {
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    const o = actx.createOscillator(), g = actx.createGain();
    o.connect(g); g.connect(actx.destination);
    o.frequency.value = 1180; o.type = 'square';
    g.gain.setValueAtTime(0.13, actx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, actx.currentTime + 0.12);
    o.start(); o.stop(actx.currentTime + 0.12);
  } catch (e) {}
}

async function toggleTorch() {
  if (!torchTrack) return;
  try {
    torchOn = !torchOn;
    await torchTrack.applyConstraints({ advanced: [{ torch: torchOn }] });
    $('torchBtn').style.background = torchOn ? 'var(--or)' : 'rgba(0,0,0,.6)';
  } catch (e) { tst('⚠ الفلاش غير مدعوم'); }
}

/* ---------- المسح المتعدد ---------- */
function renderMulti() {
  if (!multiMode) return;
  const n = multiList.reduce((a, m) => a + m.qty, 0);
  const known = multiList.filter(m => m.prod);
  const tot = known.reduce((a, m) => a + m.prod.price * m.qty, 0);
  $('m_n').textContent = n;
  $('m_t').textContent = fmt(tot) + ' دج';
  $('m_list').innerHTML = multiList.length ? [...multiList].reverse().map((m, ri) => {
    const i = multiList.length - 1 - ri;
    return `<div class="row sp" style="padding:6px 0;border-bottom:1px solid rgba(255,255,255,.12);font-size:13px">
      <span style="flex:1;${m.prod ? '' : 'color:#FFB07A'}">${m.prod ? esc(m.prod.emo + ' ' + m.prod.name) : '⚠ ' + esc(m.code)}</span>
      <div class="row" style="gap:5px">
        <button onclick="mQty(${i},-1)" style="width:24px;height:24px;border-radius:6px;border:0;background:rgba(255,255,255,.15);color:#fff">−</button>
        <b style="min-width:16px;text-align:center">${m.qty}</b>
        <button onclick="mQty(${i},1)" style="width:24px;height:24px;border-radius:6px;border:0;background:var(--or);color:#fff">+</button>
      </div>
      <b style="min-width:58px;text-align:left">${m.prod ? fmt(m.prod.price * m.qty) : '—'}</b></div>`;
  }).join('') : `<div style="text-align:center;padding:14px;opacity:.6;font-size:12.5px">امسح أول منتج...</div>`;
}
function mQty(i, d) {
  multiList[i].qty += d;
  if (multiList[i].qty <= 0) { delete recent[multiList[i].code]; multiList.splice(i, 1); }
  renderMulti();
}
function finishMulti() {
  const known = multiList.filter(m => m.prod);
  const unknown = multiList.filter(m => !m.prod);
  if (!known.length) { tst('⚠ لم يُمسح أي منتج مسجّل'); return; }
  known.forEach(m => {
    const ex = CART.find(c => c.id === m.prod.id);
    if (ex) ex.qty += m.qty;
    else CART.push({ id: m.prod.id, name: m.prod.name, price: m.prod.price, cost: m.prod.cost || 0, qty: m.qty, emo: m.prod.emo });
  });
  const nu = unknown.length;
  stopScan();
  show('s_pos');
  tst('✅ أُضيف ' + known.length + ' منتج' + (nu ? ' · ' + nu + ' غير مسجّل' : ''));
  if (nu) {
    setTimeout(() => {
      sheet(`<div class="grab"></div><h2 style="margin-bottom:6px">منتجات غير مسجّلة</h2>
        <p class="mut" style="margin-bottom:12px">هذه الباركودات غير موجودة في مخزونك. أضفها الآن:</p>
        ${unknown.map(u => `<div class="li"><div class="ic">📷</div><span style="flex:1;font-family:monospace">${esc(u.code)}</span>
          <button class="chip on" style="border:0" onclick="closeSheet();openProd(null,'${esc(u.code)}')">＋ إضافة</button></div>`).join('')}`);
    }, 700);
  }
}

function stopScan() {
  if (scanLoop) { cancelAnimationFrame(scanLoop); scanLoop = null; }
  try { if (scanStream) scanStream.getTracks().forEach(t => t.stop()); } catch (e) {}
  try {
    const v = $('scanVid');
    if (v.srcObject) v.srcObject.getTracks().forEach(t => t.stop());
    v.srcObject = null;
  } catch (e) {}
  scanStream = null; torchTrack = null; camTrack = null; torchOn = false; zoomCap = null;
  $('scanWrap').classList.remove('on');
}

function manualCode() {
  const c = prompt('أدخل رقم الباركود:');
  if (!c) return;
  const code = c.trim();
  if (multiMode) {
    const p = PRODS.find(x => x.bc === code);
    const ex = multiList.find(m => m.code === code);
    if (ex) ex.qty++; else multiList.push({ code, qty: 1, prod: p || null });
    renderMulti(); return;
  }
  stopScan(); onCode(code);
}

function onCode(code) {
  const p = PRODS.find(x => x.bc === code);
  if (scanMode === 'newprod') {
    if (p) { openProd(p.id); return; }
    openProd(null, code); tst('📷 باركود جديد: ' + code); return;
  }
  if (!p) {
    if (confirm('منتج غير مسجّل (' + code + ')\nهل تريد إضافته الآن؟')) openProd(null, code);
    return;
  }
  if (scanMode === 'cart') { addCart(p.id); tst('✅ ' + p.name); show('s_pos'); }
  else { openProd(p.id); }
}

/* الكاشف الأصلي — نجهّزه مسبقاً لتفادي تأخير أول قراءة */
(function () {
  if (!('BarcodeDetector' in window)) return;
  try {
    window._bd = new BarcodeDetector({
      formats: ['ean_13', 'ean_8', 'upc_a', 'upc_e', 'code_128', 'code_39', 'itf', 'qr_code']
    });
    // إحماء: أول استدعاء يُحمّل المكتبة الأصلية
    const c = document.createElement('canvas');
    c.width = 64; c.height = 64;
    window._bd.detect(c).then(function(){ bdReady = true; }).catch(function(){});
  } catch (e) {}
})();

/* ============================================================
   v2.4 — المنتجات بالوزن والمبلغ الحر
   ============================================================ */

/* الوحدات التي تُباع بالوزن/الحجم (كسرية) */
const FRAC_UNITS = ['كغ', 'غرام', 'لتر', 'مل', 'متر'];
const BASE_UNITS = ['قطعة', 'كغ', 'غرام', 'لتر', 'مل', 'علبة', 'كرطونة', 'متر'];

/* كل الوحدات = الأساسية + ما أضافه المستخدم */
function allUnits() {
  const custom = DB.get('units', []);
  return BASE_UNITS.concat(custom.filter(u => BASE_UNITS.indexOf(u) < 0));
}

/* إضافة وحدة جديدة */
function addUnit() {
  const v = prompt('اسم الوحدة الجديدة:\n\nمثال: صندوق · شنطة · دزينة · رزمة');
  if (v === null) return;
  const u = String(v).trim();
  if (!u) return;
  if (u.length > 12) { tst('⚠ الاسم طويل جداً'); return; }
  const all = allUnits();
  if (all.indexOf(u) >= 0) {
    tst('هذه الوحدة موجودة');
    const sel = $('p_unit'); if (sel) sel.value = u;
    unitHint();
    return;
  }
  const custom = DB.get('units', []);
  custom.push(u);
  DB.set('units', custom);
  // أعد بناء القائمة واختر الجديدة
  const sel = $('p_unit');
  if (sel) {
    const opt = document.createElement('option');
    opt.value = u; opt.textContent = u;
    sel.appendChild(opt);
    sel.value = u;
  }
  unitHint();
  tst('✅ أُضيفت وحدة «' + u + '»');
}

/* حذف وحدة مخصّصة */
function delUnit(u) {
  const used = PRODS.filter(p => p.unit === u).length;
  if (used) { tst('⚠ مستعملة في ' + used + ' منتج'); return; }
  DB.set('units', DB.get('units', []).filter(x => x !== u));
  tst('حُذفت الوحدة');
  if (curScr === 's_more') renderMore();
}

/* هل المنتج يُباع بالوزن؟ */
function isBulk(p) {
  return !!(p && (p.bulk || FRAC_UNITS.indexOf(p.unit) >= 0));
}

/* صيغة الكمية حسب الوحدة */
function qtyLabel(p, q) {
  if (!isBulk(p)) return fmt(q) + ' ' + (p.unit || 'قطعة');
  const u = p.unit || 'كغ';
  if (u === 'كغ') {
    if (q < 1) return Math.round(q * 1000) + ' غ';
    return (Math.round(q * 1000) / 1000).toString().replace(/\.?0+$/, '') + ' كغ';
  }
  if (u === 'لتر') {
    if (q < 1) return Math.round(q * 1000) + ' مل';
    return (Math.round(q * 1000) / 1000).toString().replace(/\.?0+$/, '') + ' ل';
  }
  return (Math.round(q * 1000) / 1000).toString().replace(/\.?0+$/, '') + ' ' + u;
}

/* توضيح نوع البيع حسب الوحدة المختارة */
function unitHint() {
  const el = $('unitBox');
  if (!el) return;
  const u = $('p_unit') ? $('p_unit').value : 'قطعة';
  const bulk = FRAC_UNITS.indexOf(u) >= 0;
  const sub = (u === 'كغ') ? 'غرام' : (u === 'لتر') ? 'مل' : u;

  el.innerHTML = bulk
    ? `<div class="card" style="padding:12px;border-color:var(--gold);
         background:rgba(224,178,82,.07);margin-bottom:12px">
        <b style="font-size:13px;color:var(--gold)">⚖️ بيع بالوزن</b>
        <div class="mut" style="font-size:12px;line-height:1.85;margin-top:5px">
          السعر الذي تكتبه هو <b style="color:var(--tx)">سعر ${u} واحد</b>.<br>
          عند البيع ستفتح نافذة تكتب فيها <b style="color:var(--tx)">المبلغ</b>
          أو <b style="color:var(--tx)">الوزن بالـ${sub}</b>، والتطبيق يحسب الآخر.<br>
          والمخزون يُخصم بالكسور تلقائياً.
        </div></div>`
    : `<div class="card" style="padding:11px;margin-bottom:12px">
        <div class="mut" style="font-size:12px">
          📦 بيع بالعدد — كل ضغطة تضيف ${u} واحدة للسلة.<br>
          <span style="opacity:.8">للبيع بالوزن اختر: كغ · غرام · لتر · مل · متر</span>
        </div></div>`;
}

/* ============ نافذة البيع بالوزن ============ */
let bulkProd = null;

function openBulk(id) {
  const p = PRODS.find(x => x.id === id);
  if (!p) return;
  bulkProd = p;
  const u = p.unit || 'كغ';
  const sub = (u === 'كغ') ? 'غرام' : (u === 'لتر') ? 'مل' : u;
  const inCart = CART.find(c => c.id === id);

  sheet(`<div class="grab"></div>
    <div class="row" style="gap:11px;margin-bottom:4px">
      <div class="ic" style="width:46px;height:46px;font-size:22px">${p.emo || '⚖️'}</div>
      <div style="flex:1">
        <b style="font-size:16px">${esc(p.name)}</b>
        <div class="mut" style="font-size:12.5px">
          ${fmt(p.price)} دج / ${u} · المتوفر ${qtyLabel(p, p.qty)}</div>
      </div>
    </div>

    ${inCart ? `<div class="card" style="padding:9px 12px;border-color:var(--or)">
      <div class="mut" style="font-size:12px">في السلة حالياً:
        <b style="color:var(--tx)">${qtyLabel(p, inCart.qty)}</b>
        — ${fmt(inCart.price * inCart.qty)} دج</div></div>` : ''}

    <div class="card" style="padding:14px;margin-top:11px">
      <label class="lbl">💰 المبلغ المطلوب (دج)</label>
      <div class="inp" style="margin-bottom:4px">
        <input id="bk_amt" type="number" inputmode="decimal" placeholder="مثال: 100"
          oninput="bulkFromAmount()" style="font-size:20px;font-weight:700">
        <span class="mut">دج</span>
      </div>
      <div class="mut" style="font-size:11.5px" id="bk_amt_hint">
        اكتب المبلغ وسيُحسب الوزن تلقائياً</div>
    </div>

    <div style="text-align:center;margin:8px 0;color:var(--mut);font-size:12px">— أو —</div>

    <div class="card" style="padding:14px">
      <label class="lbl">⚖️ الكمية (${sub})</label>
      <div class="inp" style="margin-bottom:4px">
        <input id="bk_qty" type="number" inputmode="decimal" placeholder="مثال: 250"
          oninput="bulkFromQty()" style="font-size:20px;font-weight:700">
        <span class="mut">${sub}</span>
      </div>
      <div class="mut" style="font-size:11.5px" id="bk_qty_hint">
        اكتب الوزن وسيُحسب المبلغ تلقائياً</div>
    </div>

    <div class="card" style="background:linear-gradient(135deg,#16293E,#1E3F5C);
         padding:14px;text-align:center;margin-top:11px">
      <div class="mut" style="font-size:12px">الإجمالي</div>
      <div style="font-size:28px;font-weight:800;color:var(--or2)" id="bk_total">0 دج</div>
      <div class="mut" style="font-size:12.5px" id="bk_detail">—</div>
    </div>

    <label class="lbl" style="margin-top:10px">مبالغ سريعة</label>
    <div class="row" style="gap:7px;flex-wrap:wrap;margin-bottom:12px">
      ${[50, 100, 200, 500, 1000].map(v =>
        `<div class="chip" onclick="bulkQuick(${v})" style="flex:1;text-align:center">
           ${v}</div>`).join('')}
    </div>

    <button class="btn" onclick="bulkAdd()">✓ أضف للسلة</button>
    ${inCart ? `<button class="btn g sm" style="margin-top:8px"
      onclick="bulkRemove('${id}')">🗑️ إزالة من السلة</button>` : ''}`);

  setTimeout(() => { const el = $('bk_amt'); if (el) el.focus(); }, 200);
}

/* المبلغ ← الكمية */
function bulkFromAmount() {
  const p = bulkProd; if (!p) return;
  const amt = +$('bk_amt').value;
  const u = p.unit || 'كغ';
  const factor = (u === 'كغ' || u === 'لتر') ? 1000 : 1;

  if (!amt || amt <= 0) {
    $('bk_qty').value = '';
    bulkShow(0, 0);
    return;
  }
  const q = amt / p.price;                  // بالوحدة الأساسية
  $('bk_qty').value = Math.round(q * factor * 100) / 100;
  bulkShow(amt, q);
}

/* الكمية ← المبلغ */
function bulkFromQty() {
  const p = bulkProd; if (!p) return;
  const raw = +$('bk_qty').value;
  const u = p.unit || 'كغ';
  const factor = (u === 'كغ' || u === 'لتر') ? 1000 : 1;

  if (!raw || raw <= 0) {
    $('bk_amt').value = '';
    bulkShow(0, 0);
    return;
  }
  const q = raw / factor;                   // بالوحدة الأساسية
  const amt = q * p.price;
  $('bk_amt').value = Math.round(amt * 100) / 100;
  bulkShow(amt, q);
}

function bulkQuick(v) {
  $('bk_amt').value = v;
  bulkFromAmount();
}

function bulkShow(amt, q) {
  const p = bulkProd; if (!p) return;
  $('bk_total').textContent = fmt(amt) + ' دج';
  $('bk_detail').textContent = q > 0
    ? qtyLabel(p, q) + ' × ' + fmt(p.price) + ' دج/' + (p.unit || 'كغ')
    : '—';

  // تحذير تجاوز المخزون
  const el = $('bk_qty_hint');
  if (el) {
    if (q > p.qty && p.qty > 0) {
      el.innerHTML = '<span style="color:var(--dan)">⚠ المتوفر فقط '
                     + qtyLabel(p, p.qty) + '</span>';
    } else {
      el.textContent = 'اكتب الوزن وسيُحسب المبلغ تلقائياً';
    }
  }
}

function bulkAdd() {
  const p = bulkProd; if (!p) return;
  const amt = +$('bk_amt').value;
  const u = p.unit || 'كغ';
  const factor = (u === 'كغ' || u === 'لتر') ? 1000 : 1;
  const q = (+$('bk_qty').value) / factor;

  if (!amt || amt <= 0 || !q || q <= 0) {
    tst('⚠ أدخل المبلغ أو الكمية');
    return;
  }
  if (q > p.qty) {
    if (!confirm('الكمية المطلوبة (' + qtyLabel(p, q) + ') أكبر من المتوفر ('
                 + qtyLabel(p, p.qty) + ').\n\nهل تريد المتابعة؟')) return;
  }

  const ex = CART.find(c => c.id === p.id);
  if (ex) { ex.qty = Math.round((ex.qty + q) * 10000) / 10000; }
  else {
    CART.push({
      id: p.id, name: p.name, price: p.price, cost: p.cost || 0,
      qty: Math.round(q * 10000) / 10000, emo: p.emo, bulk: 1, unit: u
    });
  }
  closeSheet();
  renderCart();
  tst('✓ ' + qtyLabel(p, q) + ' — ' + fmt(amt) + ' دج');
  bulkProd = null;
}

function bulkRemove(id) {
  const i = CART.findIndex(c => c.id === id);
  if (i >= 0) CART.splice(i, 1);
  closeSheet();
  renderCart();
  tst('أُزيل من السلة');
}

/* ============ بيع حر — بلا منتج مسجّل ============ */
function openFree() {
  sheet(`<div class="grab"></div>
    <h2 style="margin-bottom:4px">✏️ بيع حر</h2>
    <p class="mut" style="margin-bottom:13px">
      لمنتج غير مسجّل أو خدمة — يُضاف كمبلغ مباشر</p>

    <div class="fld">
      <label class="lbl">الوصف *</label>
      <div class="inp">🏷️<input id="fr_name" placeholder="مثال: لوز · خدمة توصيل"
        list="frl"></div>
      <datalist id="frl">
        ${freeSuggestions().map(s => `<option>${esc(s)}</option>`).join('')}
      </datalist>
    </div>

    <div class="fld">
      <label class="lbl">المبلغ (دج) *</label>
      <div class="inp">💰<input id="fr_amt" type="number" inputmode="decimal"
        placeholder="0" style="font-size:20px;font-weight:700"></div>
    </div>

    <div class="fld">
      <label class="lbl">سعر التكلفة (اختياري — لحساب الربح)</label>
      <div class="inp">💸<input id="fr_cost" type="number" inputmode="decimal"
        placeholder="0"></div>
    </div>

    <label class="lbl">مبالغ سريعة</label>
    <div class="row" style="gap:7px;flex-wrap:wrap;margin-bottom:13px">
      ${[50, 100, 200, 500, 1000].map(v =>
        `<div class="chip" onclick="$('fr_amt').value=${v}"
           style="flex:1;text-align:center">${v}</div>`).join('')}
    </div>

    <button class="btn" onclick="addFree()">✓ أضف للسلة</button>`);

  setTimeout(() => { const el = $('fr_name'); if (el) el.focus(); }, 200);
}

/* اقتراحات من آخر مبيعات حرة */
function freeSuggestions() {
  const set = {};
  SALES.slice(-60).forEach(s =>
    (s.items || []).forEach(i => { if (i.free) set[i.name] = 1; }));
  return Object.keys(set).slice(0, 12);
}

function addFree() {
  const n = ($('fr_name').value || '').trim();
  const amt = +$('fr_amt').value;
  const cost = +$('fr_cost').value || 0;

  if (!n) { tst('⚠ أدخل الوصف'); return; }
  if (!amt || amt <= 0) { tst('⚠ أدخل مبلغاً صحيحاً'); return; }

  CART.push({
    id: 'free_' + uid(), name: n, price: amt, cost: cost,
    qty: 1, emo: '✏️', free: 1
  });
  closeSheet();
  renderCart();
  tst('✓ ' + n + ' — ' + fmt(amt) + ' دج');
}

/* ---------- PRODUCTS ---------- */
const EMOS = ['📦', '🥤', '🍫', '🥛', '🥖', '🧴', '☕', '🍝', '🫒', '🧀', '🥚', '🍬', '🧻', '🧼', '💊', '👕', '🔋', '🍚', '🧂', '🥫'];
function openProd(id, bc) {
  const p = id ? PRODS.find(x => x.id === id) : null;
  sheet(`<div class="grab"></div><h2 style="margin-bottom:12px">${p ? 'تعديل منتج' : 'منتج جديد'}</h2>
    <div class="fld"><label class="lbl">الاسم *</label><div class="inp">🏷️<input id="p_name" value="${esc(p?.name || '')}" placeholder="اسم المنتج"></div></div>
    <div class="fld"><label class="lbl">الباركود</label><div class="inp">📷<input id="p_bc" value="${esc(p?.bc || bc || '')}" placeholder="امسح أو اكتب">
      <button onclick="closeSheet();startScan('newprod')" style="background:var(--or);border:0;color:#fff;padding:6px 11px;border-radius:9px;font-size:13px">مسح</button></div></div>
    <div class="grid2">
      <div class="fld" ${can('cost') ? '' : 'style="display:none"'}><label class="lbl">سعر الشراء</label><div class="inp">💸<input id="p_cost" type="number" inputmode="decimal" value="${p?.cost ?? ''}" placeholder="0"></div></div>
      <div class="fld"><label class="lbl">سعر البيع * <span class="mut" style="font-size:10.5px">(للوحدة)</span></label><div class="inp">💰<input id="p_price" type="number" inputmode="decimal" value="${p?.price ?? ''}" placeholder="0"></div></div>
    </div>
    <div class="grid2">
      <div class="fld"><label class="lbl">الكمية <span class="mut" style="font-size:10.5px" id="p_qu"></span></label><div class="inp">🔢<input id="p_qty" type="number" inputmode="decimal" step="0.001" value="${p?.qty ?? 0}"></div></div>
      <div class="fld"><label class="lbl">حد التنبيه</label><div class="inp">⚠️<input id="p_min" type="number" inputmode="numeric" value="${p?.min ?? 5}"></div></div>
    </div>
    <div class="grid2">
      <div class="fld"><label class="lbl">الوحدة</label><div class="inp">📏<select id="p_unit" onchange="unitHint()">
        ${allUnits().map(u => `<option ${p?.unit === u ? 'selected' : ''}>${esc(u)}</option>`).join('')}
      </select>
      <button onclick="addUnit()" style="background:var(--bg2);border:1px solid var(--line);color:var(--or2);padding:6px 10px;border-radius:9px;font-size:12px">＋</button></div></div>
      <div class="fld"><label class="lbl">الصنف</label><div class="inp">🗂️<input id="p_cat" value="${esc(p?.cat || '')}" placeholder="مشروبات..." list="cl">
        <datalist id="cl">${cats().map(c => `<option>${esc(c)}</option>`).join('')}</datalist></div></div>
    </div>
    <div class="fld"><label class="lbl">المورّد</label>
      <div class="inp">🏭<select id="p_sup">
        <option value="">— بلا مورّد —</option>
        ${getSups().map(sp => `<option value="${sp.id}" ${p?.sup === sp.id ? 'selected' : ''}>${esc(sp.name)}</option>`).join('')}
      </select>
      <button onclick="closeSheet();show('s_sups');openSup()" style="background:var(--bg2);border:1px solid var(--line);color:var(--or2);padding:6px 10px;border-radius:9px;font-size:12px">＋</button></div>
    </div>
    <label class="lbl">الأيقونة</label>
    <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:14px" id="emoBox">
      ${EMOS.map(e => `<div onclick="pickEmo(this,'${e}')" class="chip ${(p?.emo || '📦') === e ? 'on' : ''}" style="font-size:18px;padding:6px 9px">${e}</div>`).join('')}</div>
    <div id="unitBox"></div>
    <button class="btn" onclick="saveProd('${id || ''}')">${p ? 'حفظ التعديل' : 'إضافة المنتج'}</button>
    ${p ? `<button class="btn d sm" style="margin-top:8px" onclick="delProd('${id}')">🗑️ حذف المنتج</button>` : ''}`);
  setTimeout(unitHint, 60);
}
let pickedEmo = '📦';
function pickEmo(el, e) { pickedEmo = e; document.querySelectorAll('#emoBox .chip').forEach(c => c.classList.remove('on')); el.classList.add('on'); }
function saveProd(id) {
  const n = p_name.value.trim(), pr = +p_price.value;
  if (!n) { tst('⚠ أدخل اسم المنتج'); return; }
  if (!id && !canAdd('prod')) return;
  if (!pr || pr <= 0) { tst('⚠ أدخل سعر بيع صحيح'); return; }
  const un = p_unit.value;
  const o = { name: n, bc: p_bc.value.trim(), cost: +p_cost.value || 0, price: pr,
              qty: Math.round((+p_qty.value || 0) * 10000) / 10000,
              min: +p_min.value || 5, unit: un, cat: p_cat.value.trim(), emo: pickedEmo,
              bulk: FRAC_UNITS.indexOf(un) >= 0 ? 1 : 0,
              sup: ($('p_sup') ? $('p_sup').value : '') || undefined };
  if (id) { const i = PRODS.findIndex(x => x.id === id); PRODS[i] = { ...PRODS[i], ...o }; }
  else PRODS.push({ id: uid(), ...o });
  save(); closeSheet(); tst('✅ تم الحفظ');
  renderStock(); if (curScr === 's_pos') renderPos();
}
function delProd(id) {
  if (!confirm('حذف هذا المنتج نهائياً؟')) return;
  PRODS = PRODS.filter(x => x.id !== id); save(); closeSheet(); tst('🗑️ تم الحذف'); renderStock();
}

/* ============================================================
   v2.6 — تنبيه نفاد المخزون + طلب المورّد
   ============================================================ */

/* تصنيف حالة المنتج */
function stockState(p) {
  const m = p.min || 5;
  if (p.qty <= 0) return 'out';        // نفد
  if (p.qty <= m) return 'low';        // قارب النفاد
  if (p.qty <= m * 2) return 'warn';   // انتبه
  return 'ok';
}

/* معدل البيع اليومي لمنتج (من آخر 30 يوماً) */
function dailyRate(pid) {
  const from = new Date(Date.now() - 30 * 864e5).toISOString();
  let sold = 0;
  SALES.forEach(s => {
    if (s.date < from) return;
    (s.items || []).forEach(i => { if (i.id === pid) sold += i.qty; });
  });
  return sold / 30;
}

/* كم يوماً يكفي المخزون الحالي؟ */
function daysLeft(p) {
  const r = dailyRate(p.id);
  if (r < 0.05) return null;           // لا مبيعات تُذكر
  return Math.floor(p.qty / r);
}

/* قائمة المنتجات الناقصة مرتّبة بالأولوية */
function lowList() {
  return PRODS
    .map(p => ({ p, st: stockState(p), dl: daysLeft(p), rate: dailyRate(p.id) }))
    .filter(x => x.st === 'out' || x.st === 'low' ||
                 (x.dl !== null && x.dl <= 7))
    .sort((a, b) => {
      // النافد أولاً، ثم الأقل أياماً
      if (a.st === 'out' && b.st !== 'out') return -1;
      if (b.st === 'out' && a.st !== 'out') return 1;
      const ad = a.dl === null ? 999 : a.dl;
      const bd = b.dl === null ? 999 : b.dl;
      return ad - bd;
    });
}

/* الكمية المقترحة للطلب: تكفي 21 يوماً */
function suggestQty(x) {
  const p = x.p, m = p.min || 5;
  if (x.rate < 0.05) return Math.max(m * 2 - p.qty, m);
  const target = Math.ceil(x.rate * 21);
  return Math.max(Math.ceil(target - p.qty), 1);
}

/* ============ شاشة التنبيهات ============ */
function renderAlert() {
  const list = lowList();
  const out = list.filter(x => x.st === 'out');
  const low = list.filter(x => x.st !== 'out');

  // القيمة المطلوبة للتموين
  const cost = list.reduce((a, x) => a + suggestQty(x) * (x.p.cost || 0), 0);

  $('al_body').innerHTML = `
    <div class="grid3" style="margin-bottom:12px">
      <div class="card" style="margin:0;padding:12px;text-align:center;
           ${out.length ? 'border-color:var(--dan)' : ''}">
        <div class="mut" style="font-size:11px">نفد</div>
        <b style="font-size:21px;color:${out.length ? 'var(--dan)' : 'var(--mut)'}">${out.length}</b></div>
      <div class="card" style="margin:0;padding:12px;text-align:center;
           ${low.length ? 'border-color:var(--or)' : ''}">
        <div class="mut" style="font-size:11px">يوشك</div>
        <b style="font-size:21px;color:${low.length ? 'var(--or2)' : 'var(--mut)'}">${low.length}</b></div>
      <div class="card" style="margin:0;padding:12px;text-align:center">
        <div class="mut" style="font-size:11px">تكلفة التموين</div>
        <b style="font-size:15px">${fmt(cost)}</b></div>
    </div>

    ${list.length ? `
      <div class="row" style="gap:8px;margin-bottom:13px">
        <button class="btn sm" style="flex:2;background:linear-gradient(135deg,#25D366,#128C7E);box-shadow:none"
          onclick="orderSupplier()">📲 أرسل طلب للمورّد</button>
        <button class="btn g sm" style="flex:1" onclick="copyOrder()">📋 نسخ</button>
      </div>` : ''}

    ${!list.length ? `
      <div class="card" style="text-align:center;padding:34px 18px">
        <div style="font-size:44px">✅</div>
        <h2 style="margin:12px 0 6px">المخزون بخير</h2>
        <p class="mut" style="font-size:13px">لا توجد منتجات ناقصة حالياً</p>
      </div>` : ''}

    ${out.length ? `
      <b style="font-size:14.5px;display:block;margin:6px 0 8px;color:var(--dan)">
        🔴 نفدت تماماً (${out.length})</b>
      ${out.map(x => alertRow(x)).join('')}` : ''}

    ${low.length ? `
      <b style="font-size:14.5px;display:block;margin:14px 0 8px;color:var(--or2)">
        🟠 توشك على النفاد (${low.length})</b>
      ${low.map(x => alertRow(x)).join('')}` : ''}

    ${list.length ? `
      <div class="card" style="padding:12px;margin-top:14px">
        <div class="mut" style="font-size:11.5px;line-height:1.8">
          💡 الكمية المقترحة محسوبة من معدل بيعك في آخر 30 يوماً،
          لتكفيك ثلاثة أسابيع.</div>
      </div>` : ''}`;
}

function alertRow(x) {
  const p = x.p, sq = suggestQty(x);
  const isOut = x.st === 'out';
  return `<div class="card" style="padding:11px 13px;margin-bottom:7px;
       ${isOut ? 'border-color:rgba(255,92,92,.4)' : ''}" onclick="openProd('${p.id}')">
    <div class="row">
      <div class="ic" style="${isOut ? 'background:rgba(255,92,92,.13)' : 'background:rgba(255,122,41,.13)'}">
        ${p.emo || '📦'}</div>
      <div style="flex:1;min-width:0">
        <b style="font-size:14px">${esc(p.name)}</b>
        <div class="mut" style="font-size:11.5px;margin-top:2px">
          المتبقي: <b style="color:${isOut ? 'var(--dan)' : 'var(--or2)'}">${qtyLabel(p, p.qty)}</b>
          ${x.dl !== null && !isOut ? ` · يكفي ${x.dl} يوم` : ''}
          ${x.rate >= 0.05 ? ` · ${(x.rate * 7).toFixed(1)}/أسبوع` : ''}
        </div>
      </div>
      <div style="text-align:left;flex:0 0 auto">
        <div class="mut" style="font-size:10.5px">اطلب</div>
        <b style="font-size:15px;color:var(--ok)">${sq}</b>
      </div>
    </div></div>`;
}

/* ============ طلب المورّد ============ */
function orderText() {
  const list = lowList();
  if (!list.length) return '';
  const store = (CFG && CFG.name) || 'متجري';
  let t = 'السلام عليكم 🌿\nطلبية من *' + store + '*\n\n';
  list.forEach((x, i) => {
    t += (i + 1) + '. ' + x.p.name + ' — *' + suggestQty(x) + '* '
       + (x.p.unit || 'قطعة') + '\n';
  });
  t += '\nشكراً 🙏';
  return t;
}









/* ============ بطاقة الرئيسية ============ */
function homeAlert() {
  const el = $('homeAlert');
  if (!el) return;
  const list = lowList();
  const out = list.filter(x => x.st === 'out').length;

  if (!list.length) { el.innerHTML = ''; return; }

  const urgent = list.filter(x => x.st === 'out' ||
                 (x.dl !== null && x.dl <= 3)).length;

  el.innerHTML = `<div class="card" onclick="show('s_alert')"
    style="padding:11px 13px;margin-bottom:11px;
    border-color:${out ? 'var(--dan)' : 'var(--or)'};
    background:${out ? 'rgba(255,92,92,.08)' : 'rgba(255,122,41,.08)'}">
    <div class="row sp">
      <div class="row" style="gap:9px;flex:1">
        <div style="font-size:19px">${out ? '🔴' : '🟠'}</div>
        <div style="flex:1;min-width:0">
          <b style="font-size:13px">${
            out ? out + ' منتج نفد من المخزون' : list.length + ' منتج يوشك على النفاد'}</b>
          <div class="mut" style="font-size:11px;margin-top:2px">
            ${out && list.length > out ? 'و' + (list.length - out) + ' يوشك · ' : ''}${
            urgent ? 'اطلب الآن قبل أن تخسر مبيعات' : 'راجع قائمة التموين'}</div>
        </div>
      </div>
      <span class="chip on" style="border:0;font-size:11px">عرض</span>
    </div></div>`;
}

/* ============================================================
   v2.7 — إدارة عدة موردين
   ============================================================ */

/* قائمة الموردين */
function getSups() { return DB.get('sups', []); }
function setSups(l) { DB.set('sups', l); }
function supById(id) { return getSups().find(s => s.id === id) || null; }

/* اسم المورّد للعرض */
function supName(id) {
  const s = supById(id);
  return s ? s.name : null;
}

/* ============ شاشة إدارة الموردين ============ */
function renderSups() {
  const l = getSups();
  const counts = {};
  PRODS.forEach(p => { if (p.sup) counts[p.sup] = (counts[p.sup] || 0) + 1; });
  const noSup = PRODS.filter(p => !p.sup).length;

  $('sp_body').innerHTML = `
    <button class="btn" style="margin-bottom:13px" onclick="openSup()">＋ مورّد جديد</button>

    ${l.length ? l.map(s => `
      <div class="card" style="padding:12px 13px" onclick="openSup('${s.id}')">
        <div class="row">
          <div class="ic">🏭</div>
          <div style="flex:1;min-width:0">
            <b style="font-size:14.5px">${esc(s.name)}</b>
            <div class="mut" style="font-size:11.5px;margin-top:2px">
              ${esc(s.phone || 'بلا رقم')} · ${counts[s.id] || 0} منتج
            </div>
          </div>
          <span style="font-size:17px">›</span>
        </div></div>`).join('')
      : `<div class="empty" style="padding:30px">
           <div>🏭</div>لا يوجد موردون بعد<br>
           <small>أضف مورّدك الأول لتنظيم الطلبيات</small></div>`}

    ${noSup ? `<div class="card" style="padding:12px;border-color:var(--or)">
      <div class="mut" style="font-size:12.5px">
        ⚠️ <b style="color:var(--or2)">${noSup} منتج</b> بلا مورّد محدّد.<br>
        سيسألك التطبيق عنها عند إرسال الطلبية.</div>
      <button class="btn g sm" style="margin-top:9px" onclick="assignBulk()">
        🗂️ ربط سريع بالصنف</button>
    </div>` : ''}

    <div class="card" style="padding:12px;margin-top:11px">
      <div class="mut" style="font-size:11.5px;line-height:1.8">
        💡 حدّد المورّد في بطاقة كل منتج. عند الطلب تُقسَّم القائمة
        تلقائياً وترسل لكل مورّد ما يخصّه.</div>
    </div>`;
}

/* بطاقة مورّد */
function openSup(id) {
  const s = id ? supById(id) : null;
  const n = id ? PRODS.filter(p => p.sup === id).length : 0;

  sheet(`<div class="grab"></div>
    <h2 style="margin-bottom:12px">${s ? 'تعديل مورّد' : 'مورّد جديد'}</h2>

    <div class="fld"><label class="lbl">الاسم *</label>
      <div class="inp">🏭<input id="sp_n" value="${esc(s?.name || '')}"
        placeholder="مثال: مؤسسة الأمين للمشروبات"></div></div>

    <div class="fld"><label class="lbl">رقم الواتساب</label>
      <div class="inp">📞<input id="sp_p" value="${esc(s?.phone || '')}"
        inputmode="tel" placeholder="05 XX XX XX XX"></div></div>

    <div class="fld"><label class="lbl">ملاحظة</label>
      <div class="inp">📝<input id="sp_note" value="${esc(s?.note || '')}"
        placeholder="أيام التوصيل، شروط الدفع..."></div></div>

    ${s ? `<div class="card" style="padding:11px;margin-bottom:12px">
      <div class="row sp" style="font-size:13px">
        <span class="mut">منتجاته</span><b>${n}</b></div>
    </div>` : ''}

    <button class="btn" onclick="saveSup('${id || ''}')">
      ${s ? 'حفظ التعديل' : 'إضافة المورّد'}</button>
    ${s ? `<button class="btn d sm" style="margin-top:8px"
      onclick="delSup('${id}')">🗑️ حذف المورّد</button>` : ''}`);
}

function saveSup(id) {
  const n = ($('sp_n').value || '').trim();
  if (!n) { tst('⚠ أدخل اسم المورّد'); return; }
  const o = {
    name: n,
    phone: ($('sp_p').value || '').trim(),
    note: ($('sp_note').value || '').trim()
  };
  const l = getSups();
  if (id) {
    const i = l.findIndex(x => x.id === id);
    if (i >= 0) l[i] = { ...l[i], ...o };
  } else {
    l.push({ id: uid(), ...o });
  }
  setSups(l);
  closeSheet();
  tst('✅ تم الحفظ');
  if (curScr === 's_sups') renderSups();
}

function delSup(id) {
  const n = PRODS.filter(p => p.sup === id).length;
  if (!confirm('حذف هذا المورّد؟' + (n ? '\n\n' + n + ' منتج سيصبح بلا مورّد.' : ''))) return;
  setSups(getSups().filter(s => s.id !== id));
  PRODS.forEach(p => { if (p.sup === id) delete p.sup; });
  save();
  closeSheet();
  tst('حُذف المورّد');
  renderSups();
}

/* ============ ربط سريع بالصنف ============ */
function assignBulk() {
  const l = getSups();
  if (!l.length) { tst('⚠ أضف مورّداً أولاً'); return; }
  const cs = [...new Set(PRODS.filter(p => !p.sup).map(p => p.cat).filter(Boolean))];
  if (!cs.length) { tst('كل المنتجات مرتبطة'); return; }

  sheet(`<div class="grab"></div>
    <h2 style="margin-bottom:5px">🗂️ ربط سريع</h2>
    <p class="mut" style="margin-bottom:13px">
      اختر الصنف ثم المورّد — تُربط كل منتجاته دفعة واحدة</p>
    ${cs.map(c => {
      const n = PRODS.filter(p => !p.sup && p.cat === c).length;
      return `<div class="card" style="padding:11px 13px" onclick="pickSupFor('${esc(c)}')">
        <div class="row sp">
          <div><b style="font-size:14px">${esc(c)}</b>
            <div class="mut" style="font-size:11.5px">${n} منتج بلا مورّد</div></div>
          <span style="font-size:17px">›</span>
        </div></div>`;
    }).join('')}`);
}

function pickSupFor(cat) {
  const l = getSups();
  sheet(`<div class="grab"></div>
    <h2 style="margin-bottom:5px">مورّد صنف «${esc(cat)}»</h2>
    <p class="mut" style="margin-bottom:13px">اختر المورّد</p>
    ${l.map(s => `<div class="li" onclick="doAssign('${esc(cat)}','${s.id}')">
      <div class="ic">🏭</div>
      <div style="flex:1"><b>${esc(s.name)}</b>
        <div class="mut" style="font-size:11.5px">${esc(s.phone || '')}</div></div>
      <span>›</span></div>`).join('')}`);
}

function doAssign(cat, sid) {
  let n = 0;
  PRODS.forEach(p => { if (!p.sup && p.cat === cat) { p.sup = sid; n++; } });
  if (!save()) return;
  closeSheet();
  tst('✅ رُبط ' + n + ' منتج بـ ' + supName(sid));
  if (curScr === 's_sups') renderSups();
  if (curScr === 's_stock') renderStock();
}

/* ============ تقسيم الطلبية حسب المورّد ============ */
function ordersBySup() {
  const list = lowList();
  const groups = {};      // supId -> [items]
  const orphan = [];      // بلا مورّد

  list.forEach(x => {
    const sid = x.p.sup;
    if (sid && supById(sid)) {
      if (!groups[sid]) groups[sid] = [];
      groups[sid].push(x);
    } else {
      orphan.push(x);
    }
  });
  return { groups, orphan };
}

function supOrderText(items) {
  const store = (CFG && CFG.name) || 'متجري';
  let t = 'السلام عليكم 🌿\nطلبية من *' + store + '*\n\n';
  items.forEach((x, i) => {
    t += (i + 1) + '. ' + x.p.name + ' — *' + suggestQty(x) + '* '
       + (x.p.unit || 'قطعة') + '\n';
  });
  t += '\nشكراً 🙏';
  return t;
}

/* الشاشة الرئيسية للطلبيات */
function orderSupplier() {
  const { groups, orphan } = ordersBySup();
  const ids = Object.keys(groups);

  if (!ids.length && !orphan.length) { tst('لا توجد منتجات ناقصة'); return; }

  // لا يوجد موردون مسجّلون إطلاقاً
  if (!getSups().length) {
    sheet(`<div class="grab"></div>
      <div style="text-align:center;padding:10px 0 14px">
        <div style="font-size:42px">🏭</div>
        <h2 style="margin-top:9px">لا يوجد موردون</h2>
        <p class="mut" style="margin-top:6px">
          أضف موردينك لتقسيم الطلبيات تلقائياً</p>
      </div>
      <button class="btn" onclick="closeSheet();show('s_sups');openSup()">
        ＋ إضافة مورّد</button>
      <button class="btn g sm" style="margin-top:8px" onclick="closeSheet();sendAllOne()">
        📲 إرسال القائمة كاملة لرقم واحد</button>`);
    return;
  }

  sheet(`<div class="grab"></div>
    <h2 style="margin-bottom:5px">📲 إرسال الطلبيات</h2>
    <p class="mut" style="margin-bottom:13px">
      قُسِّمت حسب المورّد — أرسل كل واحدة على حدة</p>

    ${ids.map(sid => {
      const s = supById(sid), items = groups[sid];
      const cost = items.reduce((a, x) => a + suggestQty(x) * (x.p.cost || 0), 0);
      return `<div class="card" style="padding:12px 13px">
        <div class="row sp" style="margin-bottom:8px">
          <div style="flex:1;min-width:0">
            <b style="font-size:14.5px">🏭 ${esc(s.name)}</b>
            <div class="mut" style="font-size:11.5px;margin-top:2px">
              ${items.length} منتج · ${fmt(cost)} دج</div>
          </div>
        </div>
        <div class="mut" style="font-size:11.5px;line-height:1.7;margin-bottom:9px">
          ${items.slice(0, 3).map(x => esc(x.p.name) + ' (' + suggestQty(x) + ')').join(' · ')}
          ${items.length > 3 ? ' و' + (items.length - 3) + ' آخر...' : ''}
        </div>
        <div class="row" style="gap:7px">
          <button class="btn sm" style="flex:2;background:linear-gradient(135deg,#25D366,#128C7E);box-shadow:none"
            onclick="sendSupOrder('${sid}')">📲 إرسال</button>
          <button class="btn g sm" style="flex:1" onclick="copySupOrder('${sid}')">📋</button>
        </div></div>`;
    }).join('')}

    ${orphan.length ? `
      <div class="card" style="padding:12px 13px;border-color:var(--or)">
        <b style="font-size:14px;color:var(--or2)">❓ بلا مورّد محدّد</b>
        <div class="mut" style="font-size:11.5px;line-height:1.7;margin:6px 0 9px">
          ${orphan.slice(0, 4).map(x => esc(x.p.name)).join(' · ')}
          ${orphan.length > 4 ? ' و' + (orphan.length - 4) + ' آخر...' : ''}
        </div>
        <button class="btn g sm" onclick="askOrphan()">
          🏭 اختر مورّداً لها (${orphan.length})</button>
      </div>` : ''}`);
}

function sendSupOrder(sid) {
  const s = supById(sid);
  const { groups } = ordersBySup();
  const items = groups[sid];
  if (!items || !items.length) return;

  if (!s.phone) {
    tst('⚠ لا يوجد رقم لهذا المورّد');
    closeSheet();
    openSup(sid);
    return;
  }
  waOpen(waNum(s.phone), supOrderText(items));
  DB.set('lastOrder', new Date().toISOString());
}

function copySupOrder(sid) {
  const { groups } = ordersBySup();
  const items = groups[sid];
  if (items) copyTxt(supOrderText(items), '📋 نُسخت طلبية ' + supName(sid));
}

/* اختيار مورّد للمنتجات اليتيمة */
function askOrphan() {
  const { orphan } = ordersBySup();
  const l = getSups();

  sheet(`<div class="grab"></div>
    <h2 style="margin-bottom:5px">🏭 منتجات بلا مورّد</h2>
    <p class="mut" style="margin-bottom:13px">
      اختر مورّداً — سيُحفظ لكل منتج للمرات القادمة</p>

    <div class="card" style="padding:11px;max-height:150px;overflow-y:auto">
      ${orphan.map(x => `<div class="row sp" style="padding:5px 0;font-size:12.5px">
        <span>${esc(x.p.name)}</span>
        <b class="mut">${suggestQty(x)} ${esc(x.p.unit || '')}</b></div>`).join('')}
    </div>

    <label class="lbl" style="margin-top:12px">أرسلها إلى</label>
    ${l.map(s => `<div class="li" onclick="assignOrphan('${s.id}')">
      <div class="ic">🏭</div>
      <div style="flex:1"><b>${esc(s.name)}</b>
        <div class="mut" style="font-size:11.5px">${esc(s.phone || 'بلا رقم')}</div></div>
      <span>›</span></div>`).join('')}

    <button class="btn g sm" style="margin-top:11px"
      onclick="closeSheet();show('s_sups');openSup()">＋ مورّد جديد</button>`);
}

function assignOrphan(sid) {
  const { orphan } = ordersBySup();
  orphan.forEach(x => { x.p.sup = sid; });
  if (!save()) return;
  closeSheet();
  tst('✅ رُبطت بـ ' + supName(sid));
  setTimeout(() => sendSupOrder(sid), 300);
}

/* إرسال كل شيء لرقم واحد (حين لا موردين) */
function sendAllOne() {
  const list = lowList();
  if (!list.length) return;
  const ph = prompt('رقم الواتساب:');
  if (!ph) return;
  waOpen(waNum(ph), supOrderText(list));
}

/* نسخ القائمة كاملة */
function copyOrder() {
  const list = lowList();
  if (!list.length) { tst('لا توجد منتجات ناقصة'); return; }
  const { groups, orphan } = ordersBySup();
  const store = (CFG && CFG.name) || 'متجري';
  let t = '📋 قائمة التموين — ' + store + '\n' + today() + '\n';

  Object.keys(groups).forEach(sid => {
    t += '\n🏭 ' + supName(sid) + '\n';
    groups[sid].forEach((x, i) => {
      t += '  ' + (i + 1) + '. ' + x.p.name + ' — ' + suggestQty(x)
         + ' ' + (x.p.unit || 'قطعة') + '\n';
    });
  });
  if (orphan.length) {
    t += '\n❓ بلا مورّد\n';
    orphan.forEach((x, i) => {
      t += '  ' + (i + 1) + '. ' + x.p.name + ' — ' + suggestQty(x)
         + ' ' + (x.p.unit || 'قطعة') + '\n';
    });
  }
  copyTxt(t, '📋 نُسخت القائمة');
}

/* ---------- STOCK ---------- */
function stFilter(f, el) { stF = f; document.querySelectorAll('#s_stock .tabs .chip').forEach(c => c.classList.remove('on')); el.classList.add('on'); renderStock(); }
function renderStock() {
  $('st_val').textContent = fmt(PRODS.reduce((a, p) => a + (p.cost || 0) * p.qty, 0)) + ' دج';
  $('st_cnt').textContent = PRODS.length;
  const q = ($('st_q').value || '').trim().toLowerCase();
  let l = PRODS.filter(p => (!q || p.name.toLowerCase().includes(q) || (p.bc || '').includes(q)));
  if (stF === 'low') l = l.filter(p => p.qty <= (p.min || 5));
  $('st_list').innerHTML = l.length ? l.map(p => {
    const st = p.qty <= 0 ? ['نفد', 'r'] : p.qty <= (p.min || 5) ? ['قليل', 'o'] : ['متوفر', ''];
    return `<div class="card" style="padding:10px 13px" onclick="openProd('${p.id}')"><div class="row sp">
      <div class="row"><div class="ic">${p.emo || '📦'}</div>
      <div><b style="font-size:14px">${esc(p.name)}</b>
      <div class="mut" style="font-size:11.5px">شراء ${fmt(p.cost || 0)} · بيع ${fmt(p.price)} دج${p.bc ? ' · ' + p.bc : ''}</div></div></div>
      <div style="text-align:left"><b>${p.qty}</b><div class="pill ${st[1]}">${st[0]}</div></div></div></div>`;
  }).join('') : `<div class="empty"><div>📦</div>لا توجد منتجات<br><small>اضغط «＋ منتج» أو امسح باركود</small></div>`;
}

/* ---------- CUSTOMERS / DEBT ---------- */
function openCust(id) {
  const c = id ? CUSTS.find(x => x.id === id) : null;
  sheet(`<div class="grab"></div><h2 style="margin-bottom:12px">${c ? 'بطاقة الزبون' : 'زبون جديد'}</h2>
    <div class="fld"><label class="lbl">الاسم *</label><div class="inp">👤<input id="c_name" value="${esc(c?.name || '')}" placeholder="اسم الزبون"></div></div>
    <div class="fld"><label class="lbl">الهاتف (واتساب)</label><div class="inp">📞<input id="c_ph" value="${esc(c?.phone || '')}" inputmode="tel" placeholder="05 XX XX XX XX"></div></div>
    ${c ? `
      <div class="card" style="text-align:center;background:linear-gradient(135deg,#16293E,#1E3F5C)">
        <div class="mut" style="font-size:12px">الدين الحالي</div>
        <b style="font-size:28px;color:${c.debt > 0 ? 'var(--dan)' : 'var(--ok)'}">${fmt(c.debt)} دج</b>
      </div>
      <div class="row" style="gap:10px;margin-bottom:12px">
        <div class="card" style="flex:1;margin:0;padding:11px;text-align:center"><div class="mut" style="font-size:11px">إجمالي مشترياته</div><b style="font-size:15px">${fmt(c.spent || 0)} دج</b></div>
        <div class="card" style="flex:1;margin:0;padding:11px;text-align:center"><div class="mut" style="font-size:11px">عدد الزيارات</div><b style="font-size:15px">${c.visits || 0}</b></div>
      </div>

      <label class="lbl">➕ إضافة مبلغ على الحساب (كريدي)</label>
      <div class="inp" style="margin-bottom:6px">🧾<input id="c_add" type="number" inputmode="decimal" placeholder="المبلغ">
        <button onclick="addDebt('${c.id}')" style="background:var(--dan);border:0;color:#fff;padding:7px 13px;border-radius:9px;font-size:13px">إضافة</button></div>
      <div class="inp" style="margin-bottom:14px">📝<input id="c_note" placeholder="ملاحظة (اختياري): خبز، حليب..."></div>

      <label class="lbl">💵 تسديد دفعة</label>
      <div class="inp" style="margin-bottom:6px">💵<input id="c_pay" type="number" inputmode="decimal" placeholder="المبلغ المدفوع">
        <button onclick="payDebt('${c.id}')" style="background:var(--ok);border:0;color:#fff;padding:7px 13px;border-radius:9px;font-size:13px">تسديد</button></div>
      <button class="btn g sm" style="margin-bottom:14px" onclick="payDebtAll('${c.id}')">✓ تسديد كامل المبلغ (${fmt(c.debt)} دج)</button>

      <div class="row" style="gap:8px;margin-bottom:8px">
        <button class="btn g sm" style="flex:1" onclick="custHist('${c.id}')">🧾 السجل</button>
        <button class="btn sm" style="flex:1;background:linear-gradient(135deg,#25D366,#128C7E);box-shadow:none" onclick="waRemind('${c.id}')">📲 تذكير واتساب</button>
      </div>
    ` : ''}
    <button class="btn" onclick="saveCust('${id || ''}')">${c ? 'حفظ التعديلات' : 'إضافة الزبون'}</button>
    ${c ? `<button class="btn d sm" style="margin-top:8px" onclick="delCust('${id}')">🗑️ حذف الزبون</button>` : ''}`);
}

/* إضافة مبلغ يدوي على حساب الزبون */
function addDebt(id) {
  const c = CUSTS.find(x => x.id === id);
  const v = +$('c_add').value;
  if (!v || v <= 0) { tst('⚠ أدخل مبلغاً صحيحاً'); return; }
  const note = ($('c_note').value || '').trim();
  c.debt += v;
  c.last = today();
  c.ledger = c.ledger || [];
  c.ledger.push({ t: 'debt', v: v, d: new Date().toISOString(), note: note });
  save(); closeSheet();
  tst('➕ أُضيف ' + fmt(v) + ' دج على حساب ' + c.name);
  renderDebt();
}

function payDebtAll(id) {
  const c = CUSTS.find(x => x.id === id);
  if (c.debt <= 0) { tst('✅ لا يوجد دين'); return; }
  if (!confirm('تسديد كامل المبلغ ' + fmt(c.debt) + ' دج؟')) return;
  c.ledger = c.ledger || [];
  c.ledger.push({ t: 'pay', v: c.debt, d: new Date().toISOString() });
  c.debt = 0; c.last = today();
  save(); closeSheet(); tst('✅ سُدّد الحساب كاملاً'); renderDebt();
}

function saveCust(id) {
  const n = $('c_name').value.trim(); if (!n) { tst('⚠ أدخل اسم الزبون'); return; }
  if (!id && !canAdd('cust')) return;
  if (id) { const c = CUSTS.find(x => x.id === id); c.name = n; c.phone = $('c_ph').value.trim(); }
  else CUSTS.push({ id: uid(), name: n, phone: $('c_ph').value.trim(), debt: 0, spent: 0, visits: 0, last: today(), ledger: [] });
  save(); closeSheet(); tst('✅ تم الحفظ'); renderDebt();
}
function payDebt(id) {
  const c = CUSTS.find(x => x.id === id), v = +$('c_pay').value;
  if (!v || v <= 0) { tst('⚠ أدخل مبلغاً صحيحاً'); return; }
  c.debt = Math.max(0, c.debt - v); c.last = today();
  c.ledger = c.ledger || [];
  c.ledger.push({ t: 'pay', v: v, d: new Date().toISOString() });
  save(); closeSheet();
  tst('✅ سُدّد ' + fmt(v) + ' دج'); renderDebt();
}
function delCust(id) {
  if (!confirm('حذف هذا العميل؟')) return;
  CUSTS = CUSTS.filter(x => x.id !== id); save(); closeSheet(); renderDebt();
}
/* ====== تذكير الواتساب ====== */
function waNum(phone) {
  let ph = String(phone || '').replace(/[^0-9]/g, '');
  if (!ph) return '';
  if (ph.startsWith('00')) ph = ph.slice(2);
  if (ph.startsWith('213')) return ph;
  if (ph.startsWith('0')) return '213' + ph.slice(1);
  if (ph.length === 9) return '213' + ph;       // 6xxxxxxxx
  return ph;
}

function waTemplates(c) {
  const store = CFG?.name || 'متجرنا';
  const amt = fmt(c.debt);
  const name = c.name;
  return [
    { k: 'ودّي', t: `السلام عليكم ${name} 🌿\nتذكير ودّي من ${store}: لديكم مبلغ *${amt} دج* غير مسدّد.\nنرجو التكرم بالتسوية عند الإمكان.\nشكراً لثقتكم 🙏` },
    { k: 'رسمي', t: `السلام عليكم ${name}،\nنعلمكم أن رصيدكم لدى ${store} هو *${amt} دج*.\nنرجو تسوية المبلغ في أقرب وقت.\nمع التحية.` },
    { k: 'مختصر', t: `${name}، تذكير: ${amt} دج لدى ${store}. شكراً 🌿` },
    { k: 'مع كشف', t: `السلام عليكم ${name} 🌿\nكشف حسابكم لدى ${store}:\n${waStatement(c)}\n*الرصيد: ${amt} دج*\nنرجو التسوية عند الإمكان. شكراً 🙏` }
  ];
}

function waStatement(c) {
  const l = SALES.filter(s => s.cust === c.id && s.pay === 'credit').slice(-6);
  if (!l.length) return '—';
  return l.map(s => `• ${s.date.slice(0, 10).split('-').reverse().join('/')} — ${fmt(s.total)} دج`).join('\n');
}

/* نافذة التذكير: اختيار الصيغة + معاينة + إرسال */
function waRemind(id) {
  const c = CUSTS.find(x => x.id === id);
  if (!c) return;
  if (!c.phone) {
    sheet(`<div class="grab"></div><h2 style="margin-bottom:6px">لا يوجد رقم هاتف</h2>
      <p class="mut" style="margin-bottom:12px">أضف رقم واتساب لـ ${esc(c.name)} لإرسال التذكير.</p>
      <div class="fld"><div class="inp">📞<input id="wa_p" inputmode="tel" placeholder="05 XX XX XX XX"></div></div>
      <button class="btn" onclick="saveWaPhone('${id}')">حفظ وإرسال</button>`);
    return;
  }
  const tpl = waTemplates(c);
  sheet(`<div class="grab"></div>
    <h2 style="margin-bottom:3px">تذكير واتساب</h2>
    <div class="mut" style="margin-bottom:12px">${esc(c.name)} · <b style="color:var(--dan)">${fmt(c.debt)} دج</b></div>
    <label class="lbl">اختر الصيغة</label>
    <div class="tabs" style="padding:4px 0 10px">
      ${tpl.map((t, i) => `<div class="chip ${i === 0 ? 'on' : ''}" onclick="waPick(${i},'${id}',this)">${t.k}</div>`).join('')}
    </div>
    <label class="lbl">المعاينة (يمكنك التعديل)</label>
    <div class="inp" style="align-items:flex-start;padding:12px">
      <textarea id="wa_msg" rows="7" style="resize:none;line-height:1.7">${esc(tpl[0].t.replace(/\\n/g, '\n'))}</textarea>
    </div>
    <div class="mut" style="font-size:11.5px;margin:8px 0 12px">📲 سيُفتح واتساب على الرقم: <b dir="ltr">+${waNum(c.phone)}</b></div>
    <button class="btn" onclick="waSend('${id}')">📲 فتح واتساب وإرسال</button>
    <button class="btn g sm" style="margin-top:8px" onclick="waCopy()">📋 نسخ الرسالة فقط</button>`);
}

function waPick(i, id, el) {
  const c = CUSTS.find(x => x.id === id);
  document.querySelectorAll('#shIn .tabs .chip').forEach(x => x.classList.remove('on'));
  el.classList.add('on');
  $('wa_msg').value = waTemplates(c)[i].t.replace(/\\n/g, '\n');
}

function saveWaPhone(id) {
  const v = $('wa_p').value.trim();
  if (!v) { tst('⚠ أدخل الرقم'); return; }
  const c = CUSTS.find(x => x.id === id);
  c.phone = v; save();
  waRemind(id);
}

function waSend(id) {
  const c = CUSTS.find(x => x.id === id);
  const msg = $('wa_msg').value;
  const num = waNum(c.phone);
  if (!num) { tst('⚠ رقم غير صالح'); return; }
  c.lastRemind = today();
  save();
  closeSheet();
  waOpen(num, msg);
  renderDebt();
}

/* فتح واتساب عبر أندرويد — لا داخل التطبيق */
function waOpen(num, msg) {
  if (AND) {
    try { Android.openWhatsApp(num, msg); tst('📲 جارٍ فتح واتساب...'); return; }
    catch (e) {}
  }
  const url = 'https://wa.me/' + num + '?text=' + encodeURIComponent(msg);
  try { window.open(url, '_blank'); } catch (e) { location.href = url; }
}

function waCopy() {
  const m = $('wa_msg').value;
  try { navigator.clipboard.writeText(m); tst('📋 نُسخت الرسالة'); }
  catch (e) { tst('⚠ تعذّر النسخ'); }
}

/* تذكير جماعي لكل المدينين */
function waAll() {
  const l = CUSTS.filter(c => c.debt > 0 && c.phone);
  const noPh = CUSTS.filter(c => c.debt > 0 && !c.phone).length;
  if (!l.length) {
    tst(noPh ? '⚠ لا يوجد أرقام هواتف مسجّلة' : '✅ لا توجد ديون');
    return;
  }
  sheet(`<div class="grab"></div><h2 style="margin-bottom:4px">تذكير جماعي</h2>
    <p class="mut" style="margin-bottom:12px">${l.length} زبون عليهم ديون${noPh ? ` · ${noPh} بلا رقم هاتف` : ''}.<br>
    اضغط على كل زبون لإرسال تذكيره (واتساب يفتح واحداً تلو الآخر).</p>
    ${l.sort((a, b) => b.debt - a.debt).map(c => `<div class="li">
      <div class="ic" style="background:rgba(255,92,92,.13)">👤</div>
      <div style="flex:1"><b>${esc(c.name)}</b>
        <div class="mut" style="font-size:11.5px">${fmt(c.debt)} دج${c.lastRemind ? ' · آخر تذكير ' + c.lastRemind : ''}</div></div>
      <button class="chip on" style="border:0" onclick="waQuick('${c.id}')">📲 إرسال</button></div>`).join('')}`);
}

/* إرسال سريع بالصيغة الافتراضية */
function waQuick(id) {
  const c = CUSTS.find(x => x.id === id);
  const msg = waTemplates(c)[0].t.replace(/\\n/g, '\n');
  const num = waNum(c.phone);
  if (!num) { tst('⚠ رقم غير صالح'); return; }
  c.lastRemind = today(); save();
  waOpen(num, msg);
}

function custHist(id) {
  const c = CUSTS.find(x => x.id === id);
  const l = SALES.filter(s => s.cust === id).reverse();
  sheet(`<div class="grab"></div><h2 style="margin-bottom:4px">سجل ${esc(c.name)}</h2>
    <div class="mut" style="margin-bottom:12px">${l.length} فاتورة · ${fmt(c.spent || 0)} دج</div>
    ${l.length ? l.map(s => `<div class="li" onclick="closeSheet();viewSale('${s.id}')">
      <div class="ic">${s.pay === 'credit' ? '🤝' : '🧾'}</div>
      <div style="flex:1"><b>#${s.no}</b><div class="mut" style="font-size:11.5px">${s.date.slice(0,10).split('-').reverse().join('/')} · ${payName(s.pay)}</div></div>
      <b style="${s.pay === 'credit' ? 'color:var(--dan)' : ''}">${fmt(s.total)} دج</b></div>`).join('')
    : `<div class="empty" style="padding:28px"><div style="font-size:40px">🧾</div>لا مشتريات مسجّلة</div>`}`);
}

function renderDebt() {
  $('d_tot').textContent = fmt(CUSTS.reduce((a, c) => a + c.debt, 0));
  const l = [...CUSTS].sort((a, b) => b.debt - a.debt);
  $('d_list').innerHTML = l.length ? l.map(c => `
    <div class="card" style="padding:10px 13px" onclick="openCust('${c.id}')"><div class="row sp">
      <div class="row"><div class="ic" style="${c.debt > 0 ? 'background:rgba(255,92,92,.13)' : ''}">👤</div>
      <div><b style="font-size:14px">${esc(c.name)}</b><div class="mut" style="font-size:11.5px">${c.visits ? c.visits + ' زيارة · ' + fmt(c.spent || 0) + ' دج' : (c.phone || 'بدون رقم')}</div></div></div>
      <b style="${c.debt > 0 ? 'color:var(--dan)' : 'color:var(--ok)'}">${fmt(c.debt)} دج</b></div></div>`).join('')
    : `<div class="empty"><div>🤝</div>لا يوجد عملاء<br><small>أضف عميلاً لتسجيل الكريدي</small></div>`;
}

/* ============================================================
   v2.8 — طباعة ملصقات الباركود + تقارير PDF
   ============================================================ */

/* ============ توليد باركود EAN-13 داخلي ============ */
/* للمنتجات بلا باركود: نولّد كوداً داخلياً صالحاً */
function genBarcode() {
  // بادئة 200 محجوزة للاستعمال الداخلي عالمياً
  let base = '200';
  for (let i = 0; i < 9; i++) base += Math.floor(Math.random() * 10);
  // رقم المراقبة
  const d = base.split('').map(Number);
  let sum = 0;
  d.reverse().forEach((n, i) => { sum += n * (i % 2 === 0 ? 3 : 1); });
  const chk = (10 - (sum % 10)) % 10;
  return base + chk;
}

/* أنماط أعمدة EAN-13 */
const EAN_L = ['0001101','0011001','0010011','0111101','0100011',
               '0110001','0101111','0111011','0110111','0001011'];
const EAN_G = ['0100111','0110011','0011011','0100001','0011101',
               '0111001','0000101','0010001','0001001','0010111'];
const EAN_R = ['1110010','1100110','1101100','1000010','1011100',
               '1001110','1010000','1000100','1001000','1110100'];
const EAN_P = ['LLLLLL','LLGLGG','LLGGLG','LLGGGL','LGLLGG',
               'LGGLLG','LGGGLL','LGLGLG','LGLGGL','LGGLGL'];

/* يحوّل باركود إلى SVG */
function barcodeSVG(code, w, h) {
  code = String(code).replace(/\D/g, '');
  if (code.length !== 13) return '';
  const first = +code[0];
  const pat = EAN_P[first];
  let bits = '101';                              // حارس البداية
  for (let i = 1; i <= 6; i++) {
    bits += (pat[i - 1] === 'L' ? EAN_L : EAN_G)[+code[i]];
  }
  bits += '01010';                               // الحارس الأوسط
  for (let i = 7; i <= 12; i++) bits += EAN_R[+code[i]];
  bits += '101';                                 // حارس النهاية

  const bw = w / bits.length;
  let rects = '';
  for (let i = 0; i < bits.length; i++) {
    if (bits[i] === '1') {
      // الحُرّاس أطول قليلاً
      const guard = (i < 3) || (i >= 45 && i < 50) || (i >= 92);
      const bh = guard ? h : h - 4;
      rects += `<rect x="${(i * bw).toFixed(2)}" y="0" width="${(bw + 0.05).toFixed(2)}" height="${bh}" fill="#000"/>`;
    }
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h + 9}" viewBox="0 0 ${w} ${h + 9}">
    <rect width="${w}" height="${h + 9}" fill="#fff"/>${rects}
    <text x="${w / 2}" y="${h + 7.5}" font-family="monospace" font-size="7.5"
      text-anchor="middle" fill="#000" letter-spacing="1">${code}</text></svg>`;
}

/* ============ شاشة الملصقات ============ */
let labSel = {};

function renderLabels() {
  const q = (labQ || '').trim().toLowerCase();
  let l = PRODS.filter(p => !q || p.name.toLowerCase().includes(q)
                           || (p.bc || '').includes(q));
  const noBc = PRODS.filter(p => !p.bc).length;
  const nSel = Object.values(labSel).reduce((a, v) => a + v, 0);

  $('lb_body').innerHTML = `
    <div class="inp" style="margin-bottom:10px">🔍
      <input id="lb_q" value="${esc(labQ || '')}" placeholder="ابحث عن منتج..."
        oninput="labQ=this.value;renderLabels()"></div>

    ${noBc ? `<div class="card" style="padding:12px;border-color:var(--or)">
      <div class="mut" style="font-size:12.5px">
        ⚠️ <b style="color:var(--or2)">${noBc} منتج</b> بلا باركود.<br>
        ولّد لها أكواداً داخلية لتستطيع مسحها بالقارئ.</div>
      <button class="btn g sm" style="margin-top:9px" onclick="genAllBc()">
        🔢 توليد باركود للجميع</button>
    </div>` : ''}

    <div class="card" style="padding:11px 13px;margin-bottom:10px">
      <div class="row sp">
        <span style="font-size:13px">المحدّد: <b style="color:var(--or2)">${nSel}</b> ملصق</span>
        <div class="row" style="gap:7px">
          <span class="chip" onclick="labSelAll()">تحديد الكل</span>
          ${nSel ? `<span class="chip on" style="border:0" onclick="printLabels()">🖨️ طباعة</span>` : ''}
        </div>
      </div>
    </div>

    ${l.length ? l.map(p => {
      const c = labSel[p.id] || 0;
      return `<div class="card" style="padding:10px 12px;${c ? 'border-color:var(--or)' : ''}">
        <div class="row">
          <div class="ic">${p.emo || '📦'}</div>
          <div style="flex:1;min-width:0">
            <b style="font-size:13.5px">${esc(p.name)}</b>
            <div class="mut" style="font-size:11px;font-family:monospace;margin-top:2px">
              ${p.bc ? esc(p.bc) : '<span style="color:var(--or2)">بلا باركود</span>'}
              · ${fmt(p.price)} دج</div>
          </div>
          <div class="row" style="gap:6px">
            <button onclick="labQty('${p.id}',-1)" style="width:26px;height:26px;border-radius:7px;
              border:0;background:var(--bg2);color:#fff;font-size:15px">−</button>
            <b style="min-width:20px;text-align:center">${c}</b>
            <button onclick="labQty('${p.id}',1)" style="width:26px;height:26px;border-radius:7px;
              border:0;background:var(--or);color:#fff;font-size:15px">+</button>
          </div>
        </div></div>`;
    }).join('') : '<div class="empty"><div>🏷️</div>لا منتجات</div>'}`;
}

let labQ = '';

function labQty(id, d) {
  const p = PRODS.find(x => x.id === id);
  if (!p) return;
  if (d > 0 && !p.bc) {
    if (!confirm('هذا المنتج بلا باركود.\n\nهل تريد توليد كود داخلي له؟')) return;
    p.bc = genBarcode();
    save();
  }
  labSel[id] = Math.max(0, (labSel[id] || 0) + d);
  if (!labSel[id]) delete labSel[id];
  renderLabels();
}

function labSelAll() {
  const any = Object.keys(labSel).length;
  labSel = {};
  if (!any) PRODS.forEach(p => { if (p.bc) labSel[p.id] = 1; });
  renderLabels();
}

function genAllBc() {
  let n = 0;
  PRODS.forEach(p => { if (!p.bc) { p.bc = genBarcode(); n++; } });
  if (!save()) return;
  tst('✅ وُلّد ' + n + ' باركود');
  renderLabels();
}

/* ============ الطباعة ============ */
function printLabels() {
  const items = [];
  Object.keys(labSel).forEach(id => {
    const p = PRODS.find(x => x.id === id);
    if (p && p.bc) for (let i = 0; i < labSel[id]; i++) items.push(p);
  });
  if (!items.length) { tst('⚠ حدّد منتجاً أولاً'); return; }

  const store = (CFG && CFG.name) || '';
  const cells = items.map(p => `
    <div class="lab">
      <div class="nm">${esc(p.name)}</div>
      <div class="bc">${barcodeSVG(p.bc, 108, 30)}</div>
      <div class="pr">${fmt(p.price)} دج</div>
    </div>`).join('');

  const html = `<!DOCTYPE html><html dir="rtl"><head><meta charset="utf-8">
  <title>ملصقات</title><style>
    @page { size: A4; margin: 8mm; }
    * { box-sizing: border-box; }
    body { margin:0; font-family: Tahoma, Arial, sans-serif; }
    .grid { display:grid; grid-template-columns: repeat(4, 1fr); gap: 3mm; }
    .lab { border: 1px dashed #bbb; border-radius: 2mm; padding: 2mm 1mm;
           text-align:center; height: 26mm; display:flex; flex-direction:column;
           justify-content:space-between; page-break-inside: avoid; }
    .nm { font-size: 8pt; font-weight: bold; line-height:1.15;
          max-height: 2.4em; overflow: hidden; }
    .bc svg { width: 100%; height: auto; }
    .pr { font-size: 10pt; font-weight: 800; }
    .hd { text-align:center; font-size: 8pt; color:#666; margin-bottom: 3mm; }
    @media print { .hd { display:none; } }
  </style></head><body>
  <div class="hd">${esc(store)} — ${items.length} ملصق — ${today()}</div>
  <div class="grid">${cells}</div>
  </body></html>`;

  if (AND) { try { Android.printReceipt(html); return; } catch (e) {} }
  if (typeof pcPrint === 'function') { pcPrint(html); return; }
  const w = window.open('', '_blank');
  if (w) { w.document.write(html); w.document.close(); setTimeout(() => w.print(), 400); }
}

/* ============ تقرير PDF شهري ============ */
function monthReport(ym) {
  if (!can('reports')) { needOwner('reports'); return; }
  const m = ym || today().slice(0, 7);
  const ss = SALES.filter(s => s.date.slice(0, 7) === m);

  if (!ss.length) { tst('لا مبيعات في ' + m); return; }

  const rev = ss.reduce((a, s) => a + s.total, 0);
  const prof = ss.reduce((a, s) => a + (s.items || []).reduce(
    (x, i) => x + (i.price - (i.cost || 0)) * i.qty, 0), 0);
  const cash = ss.filter(s => s.pay !== 'credit').reduce((a, s) => a + s.total, 0);
  const cred = rev - cash;
  const tva = ss.reduce((a, s) => a + (s.tva || 0), 0);
  const ht = ss.reduce((a, s) => a + (s.ht || s.total), 0);

  // أفضل المنتجات
  const byP = {};
  ss.forEach(s => (s.items || []).forEach(i => {
    if (!byP[i.name]) byP[i.name] = { q: 0, r: 0, p: 0 };
    byP[i.name].q += i.qty;
    byP[i.name].r += i.price * i.qty;
    byP[i.name].p += (i.price - (i.cost || 0)) * i.qty;
  }));
  const top = Object.entries(byP).sort((a, b) => b[1].p - a[1].p).slice(0, 15);

  // المبيعات اليومية
  const byD = {};
  ss.forEach(s => { const d = s.date.slice(8, 10); byD[d] = (byD[d] || 0) + s.total; });
  const days = Object.keys(byD).sort();
  const maxD = Math.max(...Object.values(byD), 1);

  const c = CFG || {};
  const mName = ['يناير','فبراير','مارس','أبريل','ماي','جوان',
                 'جويلية','أوت','سبتمبر','أكتوبر','نوفمبر','ديسمبر'][+m.slice(5, 7) - 1];

  const html = `<!DOCTYPE html><html dir="rtl"><head><meta charset="utf-8">
  <title>تقرير ${m}</title><style>
    @page { size:A4; margin:12mm; }
    body { font-family: Tahoma, Arial, sans-serif; font-size:11pt; color:#111; margin:0; }
    h1 { font-size:17pt; margin:0 0 2mm; }
    h2 { font-size:12.5pt; margin:7mm 0 2mm; padding-bottom:1.5mm;
         border-bottom:2px solid #E85A0C; }
    .sub { color:#666; font-size:9.5pt; margin-bottom:5mm; }
    .box { display:flex; gap:3mm; margin-bottom:4mm; }
    .kpi { flex:1; border:1px solid #ddd; border-radius:2mm; padding:3mm; text-align:center; }
    .kpi .l { font-size:8.5pt; color:#666; }
    .kpi .v { font-size:14pt; font-weight:800; margin-top:1mm; }
    table { width:100%; border-collapse:collapse; font-size:9.5pt; }
    th,td { padding:2mm; text-align:right; border-bottom:1px solid #e4e4e4; }
    th { background:#f5f5f5; font-size:9pt; }
    .bars { display:flex; align-items:flex-end; gap:1mm; height:28mm;
            border-bottom:1px solid #ccc; padding-bottom:0; }
    .bars i { flex:1; background:#E85A0C; min-height:1px; display:block; }
    .lbl { display:flex; gap:1mm; font-size:6.5pt; color:#888; margin-top:1mm; }
    .lbl span { flex:1; text-align:center; }
    .ft { margin-top:8mm; text-align:center; color:#999; font-size:8pt;
          border-top:1px solid #eee; padding-top:3mm; }
  </style></head><body>

  <h1>${esc(c.name || 'متجري')}</h1>
  <div class="sub">
    ${c.addr ? esc(c.addr) + ' · ' : ''}${c.phone ? esc(c.phone) : ''}
    ${c.rc ? ' · RC: ' + esc(c.rc) : ''}${c.nif ? ' · NIF: ' + esc(c.nif) : ''}
  </div>

  <h2>التقرير الشهري — ${mName} ${m.slice(0, 4)}</h2>

  <div class="box">
    <div class="kpi"><div class="l">رقم الأعمال</div><div class="v">${fmt(rev)}</div></div>
    <div class="kpi"><div class="l">الربح الصافي</div>
      <div class="v" style="color:#168C5A">${fmt(prof)}</div></div>
    <div class="kpi"><div class="l">هامش الربح</div>
      <div class="v">${rev ? (prof / rev * 100).toFixed(1) : 0}%</div></div>
    <div class="kpi"><div class="l">عدد الفواتير</div><div class="v">${ss.length}</div></div>
  </div>

  <div class="box">
    <div class="kpi"><div class="l">نقداً</div><div class="v" style="font-size:12pt">${fmt(cash)}</div></div>
    <div class="kpi"><div class="l">آجل (كريدي)</div>
      <div class="v" style="font-size:12pt;color:#C82828">${fmt(cred)}</div></div>
    <div class="kpi"><div class="l">متوسط الفاتورة</div>
      <div class="v" style="font-size:12pt">${fmt(rev / ss.length)}</div></div>
    ${tva > 0 ? `<div class="kpi"><div class="l">TVA المحصّلة</div>
      <div class="v" style="font-size:12pt">${fmt(tva)}</div></div>` : ''}
  </div>

  <h2>المبيعات اليومية</h2>
  <div class="bars">
    ${days.map(d => `<i style="height:${(byD[d] / maxD * 100).toFixed(0)}%"></i>`).join('')}
  </div>
  <div class="lbl">${days.map(d => `<span>${d}</span>`).join('')}</div>

  <h2>أكثر المنتجات ربحاً</h2>
  <table>
    <tr><th style="width:8mm">#</th><th>المنتج</th><th style="width:20mm">الكمية</th>
        <th style="width:26mm">المبيعات</th><th style="width:26mm">الربح</th></tr>
    ${top.map((t, i) => `<tr>
      <td>${i + 1}</td><td>${esc(t[0])}</td><td>${t[1].q}</td>
      <td>${fmt(t[1].r)}</td><td style="color:#168C5A">${fmt(t[1].p)}</td></tr>`).join('')}
  </table>

  ${tva > 0 ? `<h2>الملخص الضريبي</h2>
  <table>
    <tr><td>المجموع خارج الضريبة (HT)</td><td style="text-align:left">${fmt(ht)} دج</td></tr>
    <tr><td>الضريبة على القيمة المضافة ${c.tva}%</td>
        <td style="text-align:left">${fmt(tva)} دج</td></tr>
    <tr><td><b>المجموع شامل الضريبة (TTC)</b></td>
        <td style="text-align:left"><b>${fmt(rev)} دج</b></td></tr>
  </table>` : ''}

  <div class="ft">
    حُرّر في ${today().split('-').reverse().join('/')} · حانوت — ميلود سوفت
  </div>
  </body></html>`;

  if (AND) { try { Android.printReceipt(html); return; } catch (e) {} }
  if (typeof pcPrint === 'function') { pcPrint(html); return; }
  const w = window.open('', '_blank');
  if (w) { w.document.write(html); w.document.close(); setTimeout(() => w.print(), 500); }
}

/* اختيار الشهر */
function pickMonth() {
  if (!can('reports')) { needOwner('reports'); return; }
  const ms = {};
  SALES.forEach(s => { ms[s.date.slice(0, 7)] = (ms[s.date.slice(0, 7)] || 0) + s.total; });
  const keys = Object.keys(ms).sort().reverse().slice(0, 12);
  if (!keys.length) { tst('لا توجد مبيعات'); return; }

  const mn = ['يناير','فبراير','مارس','أبريل','ماي','جوان',
              'جويلية','أوت','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
  sheet(`<div class="grab"></div>
    <h2 style="margin-bottom:5px">📄 تقرير شهري</h2>
    <p class="mut" style="margin-bottom:13px">اختر الشهر — يُفتح جاهزاً للطباعة أو الحفظ PDF</p>
    ${keys.map(k => `<div class="card" style="padding:12px 13px" onclick="closeSheet();monthReport('${k}')">
      <div class="row sp">
        <div><b style="font-size:14px">${mn[+k.slice(5, 7) - 1]} ${k.slice(0, 4)}</b>
          <div class="mut" style="font-size:11.5px">${fmt(ms[k])} دج</div></div>
        <span style="font-size:17px">›</span>
      </div></div>`).join('')}`);
}

/* ---------- REPORTS ---------- */
function repRange(d, el) { repD = d; document.querySelectorAll('#s_rep .tabs .chip').forEach(c => c.classList.remove('on')); el.classList.add('on'); renderRep(); }
function renderRep() {
  if (!can('reports')) {
    $('rep_full').style.display = 'none';
    $('rep_lock').style.display = 'block';
    $('rep_lock').innerHTML = `<div class="card" style="text-align:center;padding:34px 18px">
      <div style="font-size:44px">🔒</div>
      <h2 style="margin:12px 0 6px">للمالك فقط</h2>
      <p class="mut" style="font-size:13px">التقارير والأرباح متاحة للمالك.</p>
      <button class="btn g sm" style="margin-top:14px" onclick="logout()">
        🚪 تسجيل الدخول كمالك</button></div>`;
    return;
  }
  if (!lim().reports) { renderRepLocked(); return; }
  renderRepFull();
}

/* شاشة التقارير المقفلة — تعرض القيمة لا تخفيها */
function renderRepLocked() {
  const bars = [45,70,55,85,62,93,78];
  $('rep_full').style.display = 'none';
  $('rep_lock').style.display = 'block';
  $('rep_lock').innerHTML = `
    <div class="card" style="text-align:center;padding:26px 18px">
      <div style="font-size:44px">🔒</div>
      <h2 style="margin:12px 0 7px">التقارير المتقدمة</h2>
      <p class="mut" style="margin-bottom:16px;font-size:13px">
        اعرف <b style="color:var(--tx)">أرباحك الحقيقية</b> · أفضل منتجاتك<br>
        أوقات الذروة · أداء كل زبون<br>
        واتخذ قراراتك بأرقام لا بتخمين
      </p>
      <div class="bars" style="opacity:.32;margin-bottom:6px">
        ${bars.map(h=>`<i style="height:${h}%"></i>`).join('')}
      </div>
      <div style="opacity:.32;font-size:11px;margin-bottom:18px" class="mut">
        ▓▓▓▓▓▓▓ مخفي ▓▓▓▓▓▓▓</div>
      <button class="btn" onclick="showUpgrade('التقارير المتقدمة','ميزة حصرية في النسخة الكاملة')">
        🔓 فتح التقارير</button>
    </div>
    <div class="card" style="padding:13px">
      <b style="font-size:13.5px">ماذا ستحصل عليه؟</b>
      <div class="mut" style="font-size:12.5px;line-height:2;margin-top:6px">
        📈 رقم الأعمال والربح الصافي وهامش الربح<br>
        🏆 أكثر المنتجات ربحاً (لا مبيعاً فقط)<br>
        ⏰ ساعات وأيام الذروة<br>
        👥 أفضل زبائنك<br>
        📄 تصدير تقرير للطباعة
      </div>
    </div>`;
}

function renderRepFull() {
  $('rep_lock').style.display = 'none';
  $('rep_full').style.display = 'block';
  const now = new Date();
  const from = new Date(now - (repD - 1) * 864e5).toISOString().slice(0, 10);
  const S = SALES.filter(s => s.date.slice(0, 10) >= from);

  const ca = S.reduce((a, s) => a + s.total, 0);
  const pr = S.reduce((a, s) => a + s.items.reduce((x, i) => x + (i.price - (i.cost || 0)) * i.qty, 0), 0);
  const marg = ca ? pr / ca * 100 : 0;
  const cr = S.filter(s => s.pay === 'credit').reduce((a, s) => a + s.total, 0);

  $('r_ca').textContent = fmt(ca);
  $('r_pr').textContent = fmt(pr);
  $('r_n').textContent = S.length;
  $('r_av').textContent = fmt(S.length ? ca / S.length : 0);
  $('r_cr').textContent = fmt(cr);
  const mg = $('r_mg'); if (mg) mg.textContent = marg.toFixed(1) + '%';

  // الرسم اليومي
  const days = [], lbl = [];
  for (let i = repD - 1; i >= 0; i--) {
    const d = new Date(now - i * 864e5).toISOString().slice(0, 10);
    days.push(SALES.filter(s => s.date.slice(0, 10) === d).reduce((a, s) => a + s.total, 0));
    lbl.push(d.slice(8, 10));
  }
  const mx = Math.max(...days, 1);
  $('r_bars').innerHTML = days.slice(-14).map(v => `<i style="height:${Math.max(3, v / mx * 100)}%"></i>`).join('');
  $('r_lbl').innerHTML = lbl.slice(-14).map(l => `<span>${l}</span>`).join('');

  // أكثر المنتجات ربحاً
  const byP = {};
  S.forEach(s => s.items.forEach(i => {
    if (!byP[i.name]) byP[i.name] = { qty: 0, rev: 0, prof: 0 };
    byP[i.name].qty += i.qty;
    byP[i.name].rev += i.price * i.qty;
    byP[i.name].prof += (i.price - (i.cost || 0)) * i.qty;
  }));
  const top = Object.entries(byP).sort((a, b) => b[1].prof - a[1].prof).slice(0, 6);
  $('r_top').innerHTML = top.length ? top.map((t, i) => `
    <div class="card" style="padding:10px 13px;margin-bottom:7px">
      <div class="row sp">
        <span style="flex:1;font-size:13.5px">${i + 1}. ${esc(t[0])}</span>
        <span class="mut" style="font-size:11.5px">${t[1].qty} وحدة</span>
        <b style="color:var(--ok);min-width:72px;text-align:left">+${fmt(t[1].prof)}</b>
      </div></div>`).join('')
    : `<div class="empty" style="padding:24px"><div style="font-size:36px">📊</div>لا مبيعات في هذه الفترة</div>`;

  // أوقات الذروة
  const byH = new Array(24).fill(0);
  S.forEach(s => byH[new Date(s.date).getHours()] += s.total);
  const mh = Math.max(...byH, 1);
  const peak = byH.indexOf(Math.max(...byH));
  const dn = ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
  const byD = new Array(7).fill(0);
  S.forEach(s => byD[new Date(s.date).getDay()] += s.total);
  const bd = byD.indexOf(Math.max(...byD));

  $('r_peak').innerHTML = `
    <div class="bars" style="height:62px">${byH.map(v =>
      `<i style="height:${Math.max(2, v / mh * 100)}%"></i>`).join('')}</div>
    <div class="row sp" style="font-size:10px;color:var(--mut);margin-top:3px">
      <span>0h</span><span>6h</span><span>12h</span><span>18h</span><span>23h</span></div>
    ${S.length ? `<div class="mut" style="font-size:12.5px;margin-top:9px">
      🔥 ذروة المبيعات الساعة <b style="color:var(--or2)">${peak}:00</b>
      · أفضل يوم <b style="color:var(--or2)">${dn[bd]}</b></div>` : ''}`;

  // أفضل الزبائن
  const byC = {};
  S.forEach(s => { if (s.cust) { byC[s.custName || s.cust] = (byC[s.custName || s.cust] || 0) + s.total; } });
  const tc = Object.entries(byC).sort((a, b) => b[1] - a[1]).slice(0, 5);
  $('r_cust').innerHTML = tc.length ? tc.map((c, i) => `
    <div class="row sp" style="padding:7px 0;border-bottom:1px solid var(--line);font-size:13px">
      <span style="flex:1">${i + 1}. ${esc(c[0])}</span>
      <b>${fmt(c[1])} دج</b></div>`).join('')
    : `<div class="mut" style="padding:12px;text-align:center;font-size:12.5px">لا مشتريات مرتبطة بزبائن</div>`;

  // ملخص الأرشيف
  const arch = DB.get('archSum', null);
  $('r_arch').innerHTML = arch ? `
    <div class="card" style="padding:12px">
      <div class="mut" style="font-size:11.5px">📦 مضافاً إليها الأرشيف (كل الفترات)</div>
      <div class="row sp" style="margin-top:6px;font-size:13px">
        <span>إجمالي المبيعات</span><b>${fmt(arch.total + SALES.reduce((a,s)=>a+s.total,0))} دج</b></div>
      <div class="row sp" style="font-size:13px">
        <span>إجمالي الأرباح</span><b style="color:var(--ok)">${fmt(arch.profit +
          SALES.reduce((a,s)=>a+s.items.reduce((x,i)=>x+(i.price-(i.cost||0))*i.qty,0),0))} دج</b></div>
    </div>` : '';
}

/* تصدير تقرير للطباعة */
function exportRep() {
  if (!isPro()) { showUpgrade('تصدير التقارير','ميزة PRO'); return; }
  const now = new Date();
  const from = new Date(now - (repD - 1) * 864e5).toISOString().slice(0, 10);
  const S = SALES.filter(s => s.date.slice(0, 10) >= from);
  const ca = S.reduce((a, s) => a + s.total, 0);
  const pr = S.reduce((a, s) => a + s.items.reduce((x, i) => x + (i.price - (i.cost || 0)) * i.qty, 0), 0);
  const byP = {};
  S.forEach(s => s.items.forEach(i => {
    if (!byP[i.name]) byP[i.name] = { qty: 0, prof: 0 };
    byP[i.name].qty += i.qty;
    byP[i.name].prof += (i.price - (i.cost || 0)) * i.qty;
  }));
  const top = Object.entries(byP).sort((a, b) => b[1].prof - a[1].prof).slice(0, 15);
  const html = `<!DOCTYPE html><html dir="rtl"><head><meta charset="utf-8"><style>
    body{font-family:Tahoma,Arial;padding:22px;font-size:13px;color:#111}
    h1{font-size:19px;margin:0 0 3px}h2{font-size:15px;margin:18px 0 7px;border-bottom:2px solid #FF7A29;padding-bottom:4px}
    .l{display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid #eee}
    table{width:100%;border-collapse:collapse;margin-top:6px}
    th,td{padding:6px;text-align:right;border-bottom:1px solid #ddd;font-size:12px}
    th{background:#f4f4f4}.big{font-size:20px;font-weight:bold;color:#FF7A29}</style></head><body>
    <h1>${esc((CFG && CFG.name) || 'متجر')}</h1>
    <div style="color:#666;font-size:12px">تقرير الفترة: ${from} إلى ${today()} (${repD} يوماً)</div>
    <h2>الملخص المالي</h2>
    <div class="l"><span>رقم الأعمال</span><b class="big">${fmt(ca)} دج</b></div>
    <div class="l"><span>الربح الصافي</span><b>${fmt(pr)} دج</b></div>
    <div class="l"><span>هامش الربح</span><b>${(ca ? pr / ca * 100 : 0).toFixed(1)}%</b></div>
    <div class="l"><span>عدد الفواتير</span><b>${S.length}</b></div>
    <div class="l"><span>متوسط الفاتورة</span><b>${fmt(S.length ? ca / S.length : 0)} دج</b></div>
    <div class="l"><span>المبيعات الآجلة</span><b>${fmt(S.filter(s=>s.pay==='credit').reduce((a,s)=>a+s.total,0))} دج</b></div>
    <h2>أكثر المنتجات ربحاً</h2>
    <table><tr><th>#</th><th>المنتج</th><th>الكمية</th><th>الربح</th></tr>
    ${top.map((t,i)=>`<tr><td>${i+1}</td><td>${esc(t[0])}</td><td>${t[1].qty}</td><td>${fmt(t[1].prof)} دج</td></tr>`).join('')}
    </table>
    <div style="margin-top:26px;text-align:center;color:#888;font-size:11px">
      حانوت — ${today()}</div></body></html>`;
  if (AND) { try { Android.printReceipt(html); return; } catch (e) {} }
  const w = window.open('', '_blank');
  if (w) { w.document.write(html); w.document.close(); w.print(); }
}

/* ---------- HISTORY ---------- */
/* ============================================================
   سجل الفواتير v2.3 — بحث · تصفية · تحديد · حذف
   ============================================================ */
let histQ = '', histFilter = 'all', histSel = {}, histMode = false;

function renderHist() {
  const q = histQ.trim().toLowerCase();
  let l = [...SALES].reverse();

  // تصفية بالفترة
  const now = Date.now();
  if (histFilter === 'today') {
    const t = today();
    l = l.filter(s => s.date.slice(0, 10) === t);
  } else if (histFilter === 'week') {
    const w = new Date(now - 7 * 864e5).toISOString();
    l = l.filter(s => s.date >= w);
  } else if (histFilter === 'month') {
    const m = new Date(now - 30 * 864e5).toISOString();
    l = l.filter(s => s.date >= m);
  } else if (histFilter === 'credit') {
    l = l.filter(s => s.pay === 'credit');
  } else if (histFilter === 'old') {
    const y = new Date(now - 365 * 864e5).toISOString();
    l = l.filter(s => s.date < y);
  }

  // بحث
  if (q) {
    l = l.filter(s =>
      String(s.no).includes(q) ||
      (s.custName || '').toLowerCase().includes(q) ||
      s.date.slice(0, 10).includes(q) ||
      String(s.total).includes(q) ||
      (s.items || []).some(i => (i.name || '').toLowerCase().includes(q))
    );
  }

  const sum = l.reduce((a, s) => a + s.total, 0);
  const nSel = Object.keys(histSel).length;

  // شريط الأدوات
  $('hi_bar').innerHTML = `
    <div class="inp" style="margin-bottom:9px">🔍
      <input id="hi_q" value="${esc(histQ)}" placeholder="ابحث برقم الفاتورة أو الزبون أو المنتج..."
        oninput="histQ=this.value;renderHist()">
      ${histQ ? `<span onclick="histQ='';renderHist()" style="font-size:17px;opacity:.6">✕</span>` : ''}
    </div>
    <div class="tabs" style="padding:0 0 9px">
      ${[['all','الكل'],['today','اليوم'],['week','7 أيام'],['month','30 يوم'],
         ['credit','🤝 آجل'],['old','📦 أقدم من سنة']]
        .map(f => `<div class="chip ${histFilter === f[0] ? 'on' : ''}"
          onclick="histFilter='${f[0]}';histSel={};renderHist()">${f[1]}</div>`).join('')}
    </div>
    <div class="row sp" style="padding:0 2px 9px">
      <span class="mut" style="font-size:12.5px">${l.length} فاتورة · <b style="color:var(--or2)">${fmt(sum)} دج</b></span>
      ${l.length ? `<span onclick="toggleHistMode()" class="chip ${histMode ? 'on' : ''}"
        style="font-size:11.5px">${histMode ? '✕ إلغاء' : '☑️ تحديد'}</span>` : ''}
    </div>
    ${histMode ? `
      <div class="card" style="padding:10px 12px;margin-bottom:9px;border-color:var(--or)">
        <div class="row sp">
          <span style="font-size:13px"><b>${nSel}</b> محددة</span>
          <div class="row" style="gap:7px">
            <span class="chip" onclick="selAllHist(${JSON.stringify(l.map(s => s.id)).replace(/"/g, '&quot;')})">تحديد الكل</span>
            ${nSel ? `<span class="chip" style="background:var(--dan);border-color:var(--dan);color:#fff"
              onclick="delSelected()">🗑️ حذف (${nSel})</span>` : ''}
          </div>
        </div>
      </div>` : ''}`;

  // القائمة
  $('hi_list').innerHTML = l.length ? l.map(s => {
    const on = !!histSel[s.id];
    return `<div class="card" style="padding:10px 13px;${on ? 'border-color:var(--or);background:rgba(255,122,41,.07)' : ''}"
      onclick="${histMode ? `toggleSel('${s.id}')` : `viewSale('${s.id}')`}">
      <div class="row sp">
        <div class="row" style="flex:1;min-width:0">
          ${histMode ? `<div style="width:22px;height:22px;border-radius:6px;flex:0 0 auto;
            border:2px solid ${on ? 'var(--or)' : 'var(--line)'};background:${on ? 'var(--or)' : 'transparent'};
            display:grid;place-items:center;font-size:13px;color:#fff">${on ? '✓' : ''}</div>`
            : `<div class="ic" ${s.ret ? 'style="background:rgba(255,92,92,.15)"' : ''}>${s.ret ? '↩️' : (s.pay === 'credit' ? '🤝' : '🧾')}</div>`}
          <div style="min-width:0;flex:1">
            <b style="font-size:14px">#${s.no}</b>
            ${s.custName ? `<span class="mut" style="font-size:11.5px"> · ${esc(s.custName)}</span>` : ''}
            <div class="mut" style="font-size:11.5px">
              ${s.date.slice(0, 10).split('-').reverse().join('/')} ${s.date.slice(11, 16)}
              · ${s.ret ? '<span style="color:var(--dan)">إرجاع #' + s.refNo + '</span>' : payName(s.pay)}
              · ${(s.items || []).length} صنف</div>
          </div>
        </div>
        <b style="flex:0 0 auto;${s.ret ? 'color:var(--dan)' : ''}">${s.ret ? '−' : ''}${fmt(Math.abs(s.total))} دج</b>
      </div></div>`;
  }).join('') : `<div class="empty"><div>🧾</div>
    ${histQ || histFilter !== 'all' ? 'لا نتائج مطابقة' : 'لا توجد فواتير'}</div>`;
}

function toggleHistMode() {
  histMode = !histMode;
  histSel = {};
  renderHist();
}
function toggleSel(id) {
  if (histSel[id]) delete histSel[id]; else histSel[id] = 1;
  renderHist();
}
function selAllHist(ids) {
  const all = ids.every(i => histSel[i]);
  histSel = {};
  if (!all) ids.forEach(i => histSel[i] = 1);
  renderHist();
}

/* ---------- حذف المحدد ---------- */
function delSelected() {
  if (!needOwner('delete')) return;
  const ids = Object.keys(histSel);
  if (!ids.length) return;
  const del = SALES.filter(s => histSel[s.id]);
  const total = del.reduce((a, s) => a + s.total, 0);
  const nCredit = del.filter(s => s.pay === 'credit').length;
  const saved = del.reduce((a, s) => a + JSON.stringify(s).length * 2, 0);

  sheet(`<div class="grab"></div>
    <div style="text-align:center;padding:6px 0 12px">
      <div style="font-size:42px">🗑️</div>
      <h2 style="margin-top:9px">حذف ${ids.length} فاتورة</h2>
    </div>
    <div class="card" style="padding:13px">
      <div class="row sp" style="font-size:13px;padding:3px 0">
        <span class="mut">عدد الفواتير</span><b>${ids.length}</b></div>
      <div class="row sp" style="font-size:13px;padding:3px 0">
        <span class="mut">مجموع مبالغها</span><b>${fmt(total)} دج</b></div>
      <div class="row sp" style="font-size:13px;padding:3px 0">
        <span class="mut">المساحة المحررة</span><b style="color:var(--ok)">~${(saved / 1024).toFixed(0)} KB</b></div>
    </div>

    ${nCredit ? `<div class="card" style="padding:12px;border-color:var(--or)">
      <div style="font-size:12.5px;color:var(--or2)">
        ⚠️ من بينها <b>${nCredit}</b> فاتورة آجلة (كريدي).<br>
        <b>ديون الزبائن لن تتغيّر</b> — تُحذف الفاتورة فقط من السجل.</div>
    </div>` : ''}

    <div class="card" style="padding:12px;border-color:#5A2A2A;background:rgba(255,92,92,.07)">
      <div style="font-size:12.5px;color:var(--dan)">
        🔴 الحذف <b>نهائي</b> ولا يمكن التراجع عنه.<br>
        💡 يُنصح بحفظ نسخة احتياطية أو أرشفتها أولاً.</div>
    </div>

    <button class="btn g sm" onclick="closeSheet();archiveSelected()">
      🗄️ أرشفة ثم حذف (مستحسن)</button>
    <button class="btn d" style="margin-top:8px" onclick="doDelSelected()">
      🗑️ حذف نهائي بلا أرشفة</button>
    <button class="btn g sm" style="margin-top:8px" onclick="closeSheet()">إلغاء</button>`);
}

function doDelSelected() {
  const before = SALES.length;
  const ids = Object.keys(histSel);
  deleteSales(ids);
  const n = before - SALES.length;
  if (!USE_IDB && !save()) { tst('⚠ فشل الحفظ'); return; }
  histSel = {}; histMode = false;
  closeSheet();
  tst('🗑️ حُذفت ' + n + ' فاتورة · التخزين ' + storagePct().toFixed(0) + '%');
  renderHist();
}

/* أرشفة المحدد ثم حذفه */
function archiveSelected() {
  const del = SALES.filter(s => histSel[s.id]);
  if (!del.length) return;
  del.sort((a, b) => a.date < b.date ? -1 : 1);
  const total = del.reduce((a, s) => a + s.total, 0);
  const payload = JSON.stringify({
    type: 'hanout_archive', v: 2, store: CFG && CFG.name,
    from: del[0].date, to: del[del.length - 1].date,
    count: del.length, total: total, sales: del
  });
  const fname = 'hanout_أرشيف_' + today() + '_' + del.length + 'فاتورة.json';
  if (!saveFile(fname, payload)) {
    tst('⚠ لم يُحفظ الأرشيف — أُلغي الحذف');
    return;
  }
  if (AND && Android.saveInternal) { try { Android.saveInternal(fname, payload); } catch (e) {} }

  const sum = DB.get('archSum', { count: 0, total: 0, profit: 0, first: null, last: null });
  sum.count += del.length;
  sum.total += total;
  sum.profit += del.reduce((a, s) =>
    a + (s.items || []).reduce((x, i) => x + (i.price - (i.cost || 0)) * i.qty, 0), 0);
  if (!sum.first) sum.first = del[0].date;
  sum.last = del[del.length - 1].date;
  DB.set('archSum', sum);

  deleteSales(del.map(x => x.id));
  if (!USE_IDB && !save()) return;
  histSel = {}; histMode = false;
  tst('✅ أُرشفت وحُذفت ' + del.length + ' فاتورة');
  renderHist();
}

/* ---------- حذف فاتورة واحدة من شاشة عرضها ---------- */
function delOneSale(id) {
  if (!needOwner('delete')) return;
  const s = SALES.find(x => x.id === id);
  if (!s) return;
  const isCredit = s.pay === 'credit';
  sheet(`<div class="grab"></div>
    <div style="text-align:center;padding:6px 0 12px">
      <div style="font-size:40px">🗑️</div>
      <h2 style="margin-top:8px">حذف الفاتورة #${s.no}</h2>
      <p class="mut" style="margin-top:5px">${fmt(s.total)} دج ·
        ${s.date.slice(0, 10).split('-').reverse().join('/')}</p>
    </div>
    ${isCredit ? `<div class="card" style="padding:12px;border-color:var(--or)">
      <div style="font-size:12.5px;color:var(--or2)">
        ⚠️ فاتورة آجلة${s.custName ? ' لـ <b>' + esc(s.custName) + '</b>' : ''}.<br>
        <b>الدين لن يُخصم تلقائياً</b> — عدّله يدوياً من شاشة الديون إن أردت.</div>
    </div>` : ''}
    <div class="card" style="padding:12px;border-color:#5A2A2A;background:rgba(255,92,92,.07)">
      <div style="font-size:12.5px;color:var(--dan)">🔴 الحذف نهائي ولا يمكن التراجع.</div>
    </div>
    <button class="btn d" onclick="doDelOne('${id}')">🗑️ حذف نهائي</button>
    <button class="btn g sm" style="margin-top:8px" onclick="closeSheet()">إلغاء</button>`);
}

function doDelOne(id) {
  deleteSales([id]);
  if (!USE_IDB && !save()) return;
  closeSheet();
  tst('🗑️ حُذفت الفاتورة');
  show('s_hist');
}

/* ---------- حذف سريع بالفترة (من شاشة التخزين) ---------- */
function quickPurge() {
  const now = Date.now();
  const opts = [
    ['أقدم من سنتين', 730],
    ['أقدم من سنة', 365],
    ['أقدم من 6 أشهر', 180],
    ['أقدم من 3 أشهر', 90]
  ].map(o => {
    const cut = new Date(now - o[1] * 864e5).toISOString();
    const n = SALES.filter(s => s.date < cut).length;
    const sz = SALES.filter(s => s.date < cut)
      .reduce((a, s) => a + JSON.stringify(s).length * 2, 0);
    return { label: o[0], days: o[1], n, sz };
  }).filter(o => o.n > 0);

  if (!opts.length) {
    tst('لا توجد فواتير قديمة للحذف');
    return;
  }

  sheet(`<div class="grab"></div>
    <h2 style="margin-bottom:4px">🧹 تنظيف سريع</h2>
    <p class="mut" style="margin-bottom:13px">اختر الفترة — ستُؤرشف في ملف ثم تُحذف</p>
    ${opts.map(o => `<div class="card" style="padding:13px" onclick="closeSheet();archiveOld(${Math.round(o.days / 30)})">
      <div class="row sp">
        <div style="flex:1">
          <b style="font-size:14px">${o.label}</b>
          <div class="mut" style="font-size:11.5px;margin-top:2px">
            ${o.n} فاتورة · يحرّر ~${(o.sz / 1024).toFixed(0)} KB</div>
        </div>
        <span style="font-size:18px">›</span>
      </div></div>`).join('')}
    <div class="card" style="padding:12px">
      <div class="mut" style="font-size:12px">
        💡 الأرشفة تحفظ الفواتير في ملف على هاتفك، وتبقى الإحصائيات في التقارير.</div>
    </div>
    <button class="btn g sm" onclick="closeSheet();show('s_hist')">
      🔍 اختيار فواتير محددة يدوياً</button>`);
}



/* ---------- BACKUP ---------- */


/* ---------- CAMERA DIAGNOSTIC ---------- */
async function camDiag() {
  let cams = '?';
  try {
    if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
      const d = await navigator.mediaDevices.enumerateDevices();
      cams = d.filter(x => x.kind === 'videoinput').length;
    }
  } catch (e) { cams = 'خطأ'; }
  let test = 'لم يُختبر';
  try {
    const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
    s.getTracks().forEach(t => t.stop());
    test = '✅ نجح — الكاميرا تعمل';
  } catch (e) { test = '❌ ' + (e.name || e.message); }
  const rows = [
    ['العنوان', location.protocol + '//' + location.host],
    ['سياق آمن', window.isSecureContext ? '✅ نعم' : '❌ لا'],
    ['mediaDevices', navigator.mediaDevices ? '✅ متاح' : '❌ غير متاح'],
    ['عدد الكاميرات', cams],
    ['مكتبة ZXing', window.ZXing ? '✅ محمّلة' : '❌ غير محمّلة'],
    ['BarcodeDetector', ('BarcodeDetector' in window) ? '✅ متاح' : '— غير متاح'],
    ['داخل تطبيق', AND ? '✅ نعم' : 'متصفح'],
    ['اختبار الفتح', test]
  ];
  sheet(`<div class="grab"></div><h2 style="margin-bottom:12px">تشخيص الكاميرا</h2>
    ${rows.map(r => `<div class="li" style="padding:10px 3px"><span style="flex:1" class="mut">${r[0]}</span>
      <b style="font-size:12.5px;text-align:left">${esc(r[1])}</b></div>`).join('')}
    <button class="btn" style="margin-top:12px" onclick="closeSheet();startScan('lookup')">📷 جرّب المسح الآن</button>`);
}

function wipe() {
  if (!confirm('سيتم مسح كل المنتجات والفواتير والعملاء نهائياً. متأكد؟')) return;
  if (!confirm('تأكيد أخير — لا يمكن التراجع!')) return;
  const done = () => { localStorage.clear(); location.reload(); };
  try {
    if (USE_IDB) { IDB.clear().then(done).catch(done); setTimeout(done, 2500); }
    else done();
  } catch (e) { done(); }
}

/* ---------- DEMO DATA ---------- */
function loadDemo() {
  CFG = { name: 'حانوت الأمين', owner: 'محمد الأمين', phone: '0699 59 28 20', addr: 'سوق أهراس', rc: '41B0912345', nif: '000041098765432', tva: 19 };
  DB.set('cfg', CFG);
  // [الاسم, الباركود, التكلفة, البيع, الكمية, الصنف, الأيقونة, الوحدة]
  const d = [
    ['حمود بوعلام 1ل', '6130000012345', 62, 80, 48, 'مشروبات', '🥤', 'قطعة'],
    ['حليب كانديا 1ل', '6130000022345', 95, 120, 5, 'مواد غذائية', '🥛', 'قطعة'],
    ['خبز', '', 8, 15, 60, 'مخبزة', '🥖', 'قطعة'],
    ['قهوة 250غ', '6130000032345', 195, 250, 32, 'مواد غذائية', '☕', 'قطعة'],
    ['زيت عافية 1ل', '6130000042345', 520, 600, 0, 'مواد غذائية', '🫒', 'قطعة'],
    ['معكرونة 500غ', '', 70, 90, 120, 'مواد غذائية', '🍝', 'قطعة'],
    ['جافيل 2ل', '', 240, 320, 18, 'تنظيف', '🧴', 'قطعة'],
    ['شوكولا', '', 32, 45, 75, 'حلويات', '🍫', 'قطعة'],
    ['جبن 200غ', '', 155, 200, 12, 'مواد غذائية', '🧀', 'قطعة'],
    ['صابون', '', 90, 130, 40, 'تنظيف', '🧼', 'قطعة'],
    // ===== منتجات تُباع بالوزن — جرّب الضغط عليها =====
    ['لوز', '', 900, 1200, 5, 'فواكه جافة', '🌰', 'كغ'],
    ['تمر دقلة', '', 480, 650, 12, 'فواكه جافة', '🌴', 'كغ'],
    ['زيت مصبوب', '', 330, 400, 20, 'مواد غذائية', '🫗', 'لتر'],
    ['سكر مصبوب', '', 105, 130, 25, 'مواد غذائية', '🍬', 'كغ']
  ];
  PRODS = d.map(x => ({ id: uid(), name: x[0], bc: x[1], cost: x[2], price: x[3],
    qty: x[4], min: 5, unit: x[7], cat: x[5], emo: x[6],
    bulk: FRAC_UNITS.indexOf(x[7]) >= 0 ? 1 : 0 }));
  CUSTS = [
    { id: uid(), name: 'عمار بن يوسف', phone: '0661234567', debt: 6200, last: '2026-09-02' },
    { id: uid(), name: 'سامية ك.', phone: '0771234567', debt: 4800, last: '2026-09-09' },
    { id: uid(), name: 'محل الهضاب', phone: '0551234567', debt: 3400, last: '2026-09-11' }
  ];
  SALES = [];
  for (let i = 6; i >= 0; i--) {
    const n = 2 + Math.floor(Math.random() * 4);
    for (let j = 0; j < n; j++) {
      const items = [];
      const k = 1 + Math.floor(Math.random() * 3);
      for (let z = 0; z < k; z++) {
        const p = PRODS[Math.floor(Math.random() * PRODS.length)];
        items.push({ id: p.id, name: p.name, price: p.price, cost: p.cost, qty: 1 + Math.floor(Math.random() * 3), emo: p.emo });
      }
      const tot = items.reduce((a, c) => a + c.price * c.qty, 0);
      const dt = new Date(Date.now() - i * 864e5 - j * 36e5).toISOString();
      SALES.push({ id: uid(), no: 1000 + SALES.length + 1, date: dt, items, total: tot, ht: tot / 1.19, tva: tot - tot / 1.19, pay: ['cash', 'cash', 'cash', 'card', 'baridi'][Math.floor(Math.random() * 5)] });
    }
  }
  save(); tst('✅ تم تحميل البيانات التجريبية'); show('s_home');
}

/* ============================================================
   حانوت v2.1 — وحدة الملفات (تعمل فعلياً داخل أندرويد)
   ============================================================ */

/* ---------- جسر الملفات ---------- */
let _pendingFile = null;

/** يُستدعى من أندرويد عند قراءة ملف */
window._fileLoaded = function (kind, content) {
  const cb = _pendingFile;
  _pendingFile = null;
  hideLoad();
  if (!cb) return;
  try { cb(content); } catch (e) { tst('⚠ خطأ في معالجة الملف: ' + e.message); }
};
window._fileCancel = function () { _pendingFile = null; hideLoad(); };
window._saveDone = function (name) { hideLoad(); };
window._saveCancel = function () { hideLoad(); };

/** مؤشر انتظار */
function showLoad(msg) {
  let el = $('loadOv');
  if (!el) {
    el = document.createElement('div');
    el.id = 'loadOv';
    el.style.cssText = 'position:fixed;inset:0;background:rgba(11,27,43,.82);z-index:600;' +
      'display:flex;align-items:center;justify-content:center;flex-direction:column;gap:14px';
    document.body.appendChild(el);
  }
  el.innerHTML = `<div style="width:44px;height:44px;border:4px solid rgba(255,122,41,.25);
    border-top-color:var(--or);border-radius:50%;animation:spin .8s linear infinite"></div>
    <div style="font-size:14px">${esc(msg || 'جارٍ المعالجة...')}</div>`;
  el.style.display = 'flex';
}
function hideLoad() { const el = $('loadOv'); if (el) el.style.display = 'none'; }

/** حفظ ملف — يستعمل أندرويد إن توفّر وإلا المتصفح */
function saveFile(name, content, opts) {
  opts = opts || {};
  if (AND) {
    try {
      if (opts.chooseLocation && Android.saveAs) {
        showLoad('اختر مكان الحفظ...');
        Android.saveAs(name, content);
        setTimeout(hideLoad, 1200);
        return true;
      }
      if (Android.saveToDownloads) {
        const p = Android.saveToDownloads(name, content);
        return !!p;
      }
    } catch (e) {}
  }
  // متصفح
  try {
    const blob = new Blob([content], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    return true;
  } catch (e) { tst('⚠ تعذّر الحفظ'); return false; }
}

/** فتح ملف وقراءته */
function openFile(kind, cb) {
  if (AND && Android.pickFile) {
    _pendingFile = cb;
    showLoad('اختر الملف...');
    try { Android.pickFile(kind); setTimeout(() => { if (_pendingFile) hideLoad(); }, 1500); }
    catch (e) { _pendingFile = null; hideLoad(); tst('⚠ تعذّر فتح الملفات'); }
    return;
  }
  // متصفح
  const i = document.createElement('input');
  i.type = 'file';
  i.accept = kind === 'csv' ? '.csv,.txt' : '.json,.txt';
  i.onchange = e => {
    const f = e.target.files[0];
    if (!f) return;
    const r = new FileReader();
    r.onload = ev => {
      let t = ev.target.result;
      if (t.charCodeAt(0) === 0xFEFF) t = t.slice(1);
      cb(t);
    };
    r.onerror = () => tst('⚠ تعذّرت قراءة الملف');
    r.readAsText(f, 'UTF-8');
  };
  i.click();
}

/* ============ النسخ الاحتياطي ============ */

function backupPayload() {
  return JSON.stringify({
    app: 'hanout', v: 2, date: new Date().toISOString(),
    store: (CFG && CFG.name) || '',
    counts: { prods: PRODS.length, custs: CUSTS.length, sales: SALES.length },
    cfg: CFG, prods: PRODS, custs: CUSTS, sales: SALES,
    archSum: DB.get('archSum', null), lic: DB.get('lic', null)
  });
}

function bkName() {
  const st = ((CFG && CFG.name) || 'متجر').replace(/[^\u0600-\u06FFa-zA-Z0-9]/g, '_').slice(0, 20);
  const d = new Date();
  const hm = String(d.getHours()).padStart(2, '0') + String(d.getMinutes()).padStart(2, '0');
  return 'hanout_' + st + '_' + today() + '_' + hm + '.json';
}

/* حفظ سريع في التنزيلات */
function expJSON() {
  const data = backupPayload();
  const name = bkName();
  const okSave = saveFile(name, data);
  if (okSave) {
    DB.set('lastBackup', new Date().toISOString());
    DB.set('lastBackupName', name);
    if (AND && Android.saveInternal) {
      try { Android.saveInternal(name, data); } catch (e) {}
    }
    tst('💾 حُفظت النسخة: ' + name);
    if (curScr === 's_store') renderStore();
  }
}

/* شاشة النسخ الاحتياطي الكاملة */
function backupMenu() {
  const sz = (backupPayload().length / 1024).toFixed(0);
  sheet(`<div class="grab"></div>
    <h2 style="margin-bottom:4px">💾 النسخة الاحتياطية</h2>
    <p class="mut" style="margin-bottom:14px">
      ${PRODS.length} منتج · ${CUSTS.length} زبون · ${SALES.length} فاتورة
      <span style="opacity:.7">(~${sz} كيلوبايت)</span></p>

    <div class="card" style="padding:13px">
      <b style="font-size:14px">📥 حفظ في التنزيلات</b>
      <p class="mut" style="font-size:12px;margin:5px 0 9px">
        الأسرع — تجده في مجلد Download بهاتفك</p>
      <button class="btn sm" onclick="closeSheet();expJSON()">حفظ الآن</button>
    </div>

    <div class="card" style="padding:13px">
      <b style="font-size:14px">📂 حفظ باسم (اختر المكان)</b>
      <p class="mut" style="font-size:12px;margin:5px 0 9px">
        تختار المجلد بنفسك — Drive أو بطاقة الذاكرة</p>
      <button class="btn g sm" onclick="expAs()">اختر المكان</button>
    </div>

    <div class="card" style="padding:13px;border-color:#25D366">
      <b style="font-size:14px;color:#25D366">📲 إرسال لنفسك عبر واتساب</b>
      <p class="mut" style="font-size:12px;margin:5px 0 9px">
        ⭐ الأأمن — احفظها في محادثتك الخاصة ولن تضيع أبداً</p>
      <button class="btn sm" style="background:linear-gradient(135deg,#25D366,#128C7E);box-shadow:none"
        onclick="shareBackup()">مشاركة الملف</button>
    </div>

    <div class="card" style="padding:13px">
      <b style="font-size:14px">📤 استرجاع نسخة</b>
      <p class="mut" style="font-size:12px;margin:5px 0 9px">
        ⚠️ سيُستبدل كل المحتوى الحالي</p>
      <button class="btn g sm" onclick="closeSheet();impJSON()">اختر ملف النسخة</button>
    </div>

    ${autoBackupCard()}`);
}

function expAs() {
  const data = backupPayload();
  const name = bkName();
  if (AND && Android.saveAs) {
    closeSheet();
    Android.saveAs(name, data);
    DB.set('lastBackup', new Date().toISOString());
    DB.set('lastBackupName', name);
    setTimeout(() => { if (curScr === 's_store') renderStore(); }, 800);
  } else {
    closeSheet();
    saveFile(name, data);
    DB.set('lastBackup', new Date().toISOString());
  }
}

function shareBackup() {
  const data = backupPayload();
  const name = bkName();
  if (AND && Android.shareFile) {
    closeSheet();
    try {
      Android.shareFile(name, data);
      DB.set('lastBackup', new Date().toISOString());
      DB.set('lastBackupName', name);
      setTimeout(() => { if (curScr === 's_store') renderStore(); }, 900);
      return;
    } catch (e) {}
  }
  saveFile(name, data);
  DB.set('lastBackup', new Date().toISOString());
  closeSheet();
}

/* النسخ التلقائي */
function autoBackupCard() {
  const on = DB.get('autoBk', true);
  const lastAuto = DB.get('lastAutoBk', null);
  return `<div class="card" style="padding:13px">
    <div class="row sp">
      <div style="flex:1">
        <b style="font-size:14px">🔄 نسخة تلقائية يومية</b>
        <div class="mut" style="font-size:11.5px;margin-top:3px">
          تُحفظ داخل التطبيق تلقائياً (آخر 5 نسخ)
          ${lastAuto ? '<br>آخر نسخة: ' + lastAuto : ''}</div>
      </div>
      <div onclick="toggleAutoBk()" style="width:48px;height:27px;border-radius:14px;
        background:${on ? 'var(--ok)' : '#3A4A5C'};position:relative;transition:.2s;flex:0 0 auto">
        <div style="width:21px;height:21px;border-radius:50%;background:#fff;position:absolute;
          top:3px;${on ? 'left:3px' : 'right:3px'};transition:.2s"></div></div>
    </div>
    ${on && AND ? `<button class="btn g sm" style="margin-top:10px" onclick="showAutoBks()">
      📁 عرض النسخ التلقائية</button>` : ''}
  </div>`;
}

function toggleAutoBk() {
  DB.set('autoBk', !DB.get('autoBk', true));
  backupMenu();
}

function showAutoBks() {
  if (!AND || !Android.listBackups) { tst('متاح داخل التطبيق فقط'); return; }
  let list = [];
  try { list = JSON.parse(Android.listBackups()); } catch (e) {}
  if (!list.length) { tst('لا توجد نسخ تلقائية بعد'); return; }
  list.sort((a, b) => b.time - a.time);
  sheet(`<div class="grab"></div><h2 style="margin-bottom:10px">📁 النسخ التلقائية</h2>
    <p class="mut" style="margin-bottom:12px;font-size:12.5px">
      محفوظة داخل التطبيق · تُحذف مع إزالته<br>
      💡 احفظ نسخة خارجية أيضاً للأمان</p>
    ${list.map(f => `<div class="li">
      <div class="ic">📄</div>
      <div style="flex:1">
        <b style="font-size:13px">${esc(f.name)}</b>
        <div class="mut" style="font-size:11px">
          ${(f.size / 1024).toFixed(0)} كيلوبايت ·
          ${new Date(f.time).toLocaleDateString('ar-DZ')}</div>
      </div>
      <button class="chip on" style="border:0" onclick="restoreAuto('${esc(f.name)}')">استرجاع</button>
    </div>`).join('')}`);
}

function restoreAuto(name) {
  if (!confirm('استرجاع «' + name + '»؟\n\nسيُستبدل كل المحتوى الحالي.')) return;
  let txt = '';
  try { txt = Android.readInternal(name); } catch (e) {}
  if (!txt) { tst('⚠ تعذّرت قراءة الملف'); return; }
  applyBackup(txt);
}

/* تنفيذ النسخة التلقائية */
function runAutoBackup() {
  if (!DB.get('autoBk', true)) return;
  if (!AND || !Android.saveInternal) return;
  if (SALES.length < 5) return;
  const last = DB.get('lastAutoBk', null);
  if (last === today()) return;
  try {
    const name = 'auto_' + today() + '.json';
    if (Android.saveInternal(name, backupPayload())) {
      DB.set('lastAutoBk', today());
    }
  } catch (e) {}
}

/* ---------- الاسترجاع ---------- */
function impJSON() {
  openFile('json', txt => applyBackup(txt));
}

function applyBackup(txt) {
  let d;
  try { d = JSON.parse(txt); }
  catch (e) { tst('❌ الملف تالف أو ليس نسخة احتياطية'); return; }

  if (d.type === 'hanout_archive') {
    restoreArchive(d);
    return;
  }
  if (!d || (!d.prods && !d.sales && !d.cfg)) {
    tst('❌ هذا ليس ملف نسخة احتياطية لحانوت');
    return;
  }

  const np = (d.prods || []).length, nc = (d.custs || []).length, ns = (d.sales || []).length;
  const dt = d.date ? d.date.slice(0, 10) : 'غير معروف';

  sheet(`<div class="grab"></div>
    <h2 style="margin-bottom:5px">📤 استرجاع نسخة احتياطية</h2>
    <div class="card" style="padding:13px">
      <div class="row sp" style="font-size:13px;padding:3px 0">
        <span class="mut">المتجر</span><b>${esc(d.store || (d.cfg && d.cfg.name) || '—')}</b></div>
      <div class="row sp" style="font-size:13px;padding:3px 0">
        <span class="mut">تاريخ النسخة</span><b>${dt}</b></div>
      <div style="border-top:1px solid var(--line);margin:8px 0"></div>
      <div class="row sp" style="font-size:13px;padding:3px 0">
        <span class="mut">المنتجات</span><b>${np} <span class="mut" style="font-size:11px">(حالياً ${PRODS.length})</span></b></div>
      <div class="row sp" style="font-size:13px;padding:3px 0">
        <span class="mut">الزبائن</span><b>${nc} <span class="mut" style="font-size:11px">(حالياً ${CUSTS.length})</span></b></div>
      <div class="row sp" style="font-size:13px;padding:3px 0">
        <span class="mut">الفواتير</span><b>${ns} <span class="mut" style="font-size:11px">(حالياً ${SALES.length})</span></b></div>
    </div>
    <div class="card" style="border-color:#5A2A2A;background:rgba(255,92,92,.07);padding:12px">
      <div style="font-size:12.5px;color:var(--dan)">
        ⚠️ سيُستبدل <b>كل</b> المحتوى الحالي بمحتوى هذه النسخة.</div>
    </div>
    <button class="btn d" onclick="doRestore()">استبدال كل البيانات</button>
    <button class="btn g sm" style="margin-top:8px" onclick="closeSheet()">إلغاء</button>`);
  window._pendRestore = d;
}

function doRestore() {
  const d = window._pendRestore;
  if (!d) return;
  // نسخة أمان قبل الاستبدال
  try {
    if (AND && Android.saveInternal && SALES.length) {
      Android.saveInternal('before_restore_' + today() + '.json', backupPayload());
    }
  } catch (e) {}

  CFG = d.cfg || CFG;
  PRODS = d.prods || [];
  CUSTS = d.custs || [];
  SALES = d.sales || [];
  if (d.archSum) DB.set('archSum', d.archSum);
  DB.set('cfg', CFG);
  if (!save()) return;
  window._pendRestore = null;
  closeSheet();
  buildNav();
  tst('✅ استُرجعت ' + SALES.length + ' فاتورة و' + PRODS.length + ' منتج');
  show('s_home');
}

/* استرجاع أرشيف ودمجه */
function restoreArchive(d) {
  const n = (d.sales || []).length;
  if (!n) { tst('⚠ الأرشيف فارغ'); return; }
  sheet(`<div class="grab"></div>
    <h2 style="margin-bottom:5px">🗄️ ملف أرشيف</h2>
    <p class="mut" style="margin-bottom:12px">
      ${n} فاتورة من ${(d.from || '').slice(0, 10)} إلى ${(d.to || '').slice(0, 10)}</p>
    <div class="card" style="padding:12px">
      <div class="mut" style="font-size:12.5px">
        يمكنك إعادة دمج هذه الفواتير مع بياناتك الحالية للاطلاع عليها في التقارير.<br><br>
        ⚠️ سيزيد حجم التخزين المستعمل.</div>
    </div>
    <button class="btn" onclick="mergeArchive()">➕ دمج مع البيانات الحالية</button>
    <button class="btn g sm" style="margin-top:8px" onclick="closeSheet()">إلغاء</button>`);
  window._pendArch = d;
}

function mergeArchive() {
  const d = window._pendArch;
  if (!d) return;
  const have = {};
  SALES.forEach(s => have[s.id] = 1);
  let added = 0;
  (d.sales || []).forEach(s => { if (!have[s.id]) { SALES.push(s); added++; } });
  SALES.sort((a, b) => a.date < b.date ? -1 : 1);
  // اخصم من ملخص الأرشيف
  const sum = DB.get('archSum', null);
  if (sum && added) {
    sum.count = Math.max(0, sum.count - added);
    sum.total = Math.max(0, sum.total - (d.total || 0));
    DB.set('archSum', sum);
  }
  if (!save()) return;
  window._pendArch = null;
  closeSheet();
  tst('✅ دُمجت ' + added + ' فاتورة');
  if (curScr === 's_store') renderStore();
}

/* ============ استيراد المنتجات ============ */

function importSheet() {
  if (!isPro()) {
    showUpgrade('استيراد المنتجات', 'أضف مئات المنتجات دفعة واحدة — ميزة PRO');
    return;
  }
  sheet(`<div class="grab"></div><h2 style="margin-bottom:5px">📥 استيراد المنتجات</h2>
    <p class="mut" style="margin-bottom:13px">من ملف CSV (يُصدَّر من Excel)</p>

    <div class="card" style="padding:13px">
      <b style="font-size:13.5px">ترتيب الأعمدة</b>
      <div style="font-family:monospace;font-size:11px;margin-top:7px;line-height:1.9;
        color:var(--or2);direction:ltr;text-align:left;overflow-x:auto;white-space:nowrap">
        الاسم , الباركود , البيع , الشراء , الكمية , الصنف</div>
      <div class="mut" style="font-size:11.5px;margin-top:8px;line-height:1.8">
        • الاسم والسعر <b>إلزاميان</b>، والباقي اختياري<br>
        • السطر الأول (العناوين) يُتخطّى<br>
        • يقبل الفاصلة <b>,</b> أو الفاصلة المنقوطة <b>;</b></div>
    </div>

    <button class="btn" onclick="pickCSV()">📂 اختر الملف</button>
    <button class="btn g sm" style="margin-top:8px" onclick="dlTemplate()">📄 تحميل نموذج جاهز</button>

    <div class="card" style="margin-top:14px;padding:12px">
      <div class="mut" style="font-size:12px">
        عندك مئات المنتجات ولا وقت لديك؟ نحن ندخلها لك في يوم واحد.</div>
      <button class="btn g sm" style="margin-top:9px"
        onclick="orderService('إدخال المخزون — ' + fmt(SELLER.priceStock) + ' دج')">
        🙋 اطلب خدمة الإدخال</button>
    </div>`);
}

function dlTemplate() {
  const csv = '\uFEFF' +
    'الاسم,الباركود,سعر البيع,سعر الشراء,الكمية,الصنف\n' +
    'قهوة 250غ,6132528200014,250,195,20,مواد غذائية\n' +
    'خبز,,15,8,50,مخبوزات\n' +
    'حليب 1ل,6132528200021,90,72,30,مواد غذائية\n';
  if (saveFile('نموذج_المنتجات.csv', csv)) tst('📄 حُمّل النموذج — افتحه بـ Excel');
}

function pickCSV() {
  closeSheet();
  openFile('csv', txt => previewCSV(txt));
}

/* تحليل CSV مع دعم علامات الاقتباس */
function parseCSVLine(line) {
  const out = [];
  let cur = '', q = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (q) {
      if (c === '"' && line[i + 1] === '"') { cur += '"'; i++; }
      else if (c === '"') q = false;
      else cur += c;
    } else {
      if (c === '"') q = true;
      else if (c === ',' || c === ';' || c === '\t') { out.push(cur); cur = ''; }
      else cur += c;
    }
  }
  out.push(cur);
  return out.map(x => x.trim());
}

function num(v) {
  if (v === undefined || v === null) return 0;
  const n = parseFloat(String(v).replace(/\s/g, '').replace(',', '.').replace(/[^\d.\-]/g, ''));
  return isNaN(n) ? 0 : n;
}

/* ⭐ معاينة قبل الاستيراد */
let impMode = 'smart';   // smart | new | update

function previewCSV(txt) {
  if (!txt || !txt.trim()) { tst('⚠ الملف فارغ'); return; }
  const lines = txt.split(/\r?\n/).filter(l => l.trim());
  if (lines.length < 2 && lines.length < 1) { tst('⚠ الملف لا يحوي بيانات'); return; }

  const fresh = [], upd = [], errs = [];
  const byBc = {}, byName = {};
  PRODS.forEach(p => {
    if (p.bc) byBc[String(p.bc).trim()] = p;
    byName[p.name.trim().toLowerCase()] = p;
  });

  // هل السطر الأول عناوين؟
  const first = parseCSVLine(lines[0]);
  const startIdx = (isNaN(parseFloat(first[2])) || first[0].includes('اسم')) ? 1 : 0;

  const seenBc = {};
  for (let i = startIdx; i < lines.length; i++) {
    const p = parseCSVLine(lines[i]);
    const name = (p[0] || '').trim();
    const bc = (p[1] || '').trim();
    const price = num(p[2]);

    if (!name) { errs.push({ line: i + 1, why: 'بلا اسم' }); continue; }
    if (!price || price <= 0) { errs.push({ line: i + 1, why: 'سعر غير صالح: ' + name }); continue; }

    const row = {
      name, bc, price,
      cost: num(p[3]),
      qty: num(p[4]),
      cat: (p[5] || 'عام').trim() || 'عام'
    };

    // تكرار داخل الملف نفسه
    if (bc && seenBc[bc]) { errs.push({ line: i + 1, why: 'مكرر داخل الملف: ' + name }); continue; }
    if (bc) seenBc[bc] = 1;

    // موجود في المخزون؟ (بالباركود أولاً ثم بالاسم)
    const ex = (bc && byBc[bc]) || byName[name.toLowerCase()];
    if (ex) {
      upd.push({ ...row, id: ex.id, oldPrice: ex.price, oldQty: ex.qty, oldName: ex.name });
    } else {
      fresh.push(row);
    }
  }

  if (!fresh.length && !upd.length) {
    sheet(`<div class="grab"></div>
      <div style="text-align:center;padding:14px 0">
        <div style="font-size:42px">⚠️</div>
        <h2 style="margin-top:10px">لم يُقرأ أي منتج</h2>
      </div>
      <div class="card" style="padding:12px">
        <div class="mut" style="font-size:12.5px;line-height:1.9">
          تأكد أن الملف بصيغة CSV وأن الأعمدة بالترتيب:<br>
          <b style="color:var(--or2)">الاسم , الباركود , البيع , الشراء , الكمية , الصنف</b>
          ${errs.length ? '<br><br>الأخطاء:<br>' + errs.slice(0, 6)
            .map(e => '• سطر ' + e.line + ': ' + esc(e.why)).join('<br>') : ''}
        </div>
      </div>
      <button class="btn g sm" onclick="closeSheet();importSheet()">↩ رجوع</button>`);
    return;
  }

  window._impFresh = fresh;
  window._impUpd = upd;
  impMode = upd.length && !fresh.length ? 'update' : 'smart';
  showImportPreview(errs);
}

function showImportPreview(errs) {
  const fresh = window._impFresh || [];
  const upd = window._impUpd || [];
  errs = errs || [];

  // ما الذي سيُنفَّذ حسب الوضع؟
  const willAdd = (impMode === 'update') ? 0 : fresh.length;
  const willUpd = (impMode === 'new') ? 0 : upd.length;

  const addVal = fresh.reduce((a, r) => a + r.price * r.qty, 0);
  const changed = upd.filter(u => u.price !== u.oldPrice || u.qty !== u.oldQty);

  sheet(`<div class="grab"></div>
    <h2 style="margin-bottom:4px">📥 معاينة الاستيراد</h2>
    <p class="mut" style="margin-bottom:12px">اختر ما تريد فعله ثم أكّد</p>

    <div class="grid3" style="margin-bottom:12px">
      <div class="card" style="margin:0;padding:11px;text-align:center">
        <div class="mut" style="font-size:11px">جديد</div>
        <b style="font-size:19px;color:var(--ok)">${fresh.length}</b></div>
      <div class="card" style="margin:0;padding:11px;text-align:center">
        <div class="mut" style="font-size:11px">موجود</div>
        <b style="font-size:19px;color:var(--or2)">${upd.length}</b></div>
      <div class="card" style="margin:0;padding:11px;text-align:center">
        <div class="mut" style="font-size:11px">خطأ</div>
        <b style="font-size:19px;color:${errs.length ? 'var(--dan)' : 'var(--mut)'}">${errs.length}</b></div>
    </div>

    <label class="lbl">ماذا تريد أن نفعل؟</label>
    <div style="margin-bottom:13px">
      ${[
        ['smart', '🔄 إضافة الجديد + تحديث الموجود', 'الأفضل — يضيف ' + fresh.length + ' ويحدّث ' + upd.length],
        ['new', '➕ الجديد فقط', 'يتجاهل الموجود ولا يغيّره'],
        ['update', '✏️ تحديث الأسعار والكميات فقط', 'لا يضيف منتجات جديدة']
      ].map(m => `
        <div class="card" style="padding:11px 12px;margin-bottom:7px;
             ${impMode === m[0] ? 'border-color:var(--or);background:rgba(255,122,41,.08)' : ''}"
             onclick="impMode='${m[0]}';showImportPreview()">
          <div class="row">
            <div style="width:20px;height:20px;border-radius:50%;flex:0 0 auto;
                 border:2px solid ${impMode === m[0] ? 'var(--or)' : 'var(--line)'};
                 background:${impMode === m[0] ? 'var(--or)' : 'transparent'};
                 display:grid;place-items:center;color:#fff;font-size:11px">
              ${impMode === m[0] ? '✓' : ''}</div>
            <div style="flex:1">
              <b style="font-size:13.5px">${m[1]}</b>
              <div class="mut" style="font-size:11px;margin-top:2px">${m[2]}</div>
            </div>
          </div></div>`).join('')}
    </div>

    ${willAdd ? `
      <b style="font-size:13.5px;display:block;margin:10px 0 6px;color:var(--ok)">
        ➕ سيُضاف (${willAdd})</b>
      <div class="card" style="padding:10px;max-height:130px;overflow-y:auto">
        ${fresh.slice(0, 6).map(r => `
          <div class="row sp" style="padding:5px 0;font-size:12.5px;border-bottom:1px solid var(--line)">
            <span style="flex:1">${esc(r.name)}</span>
            <span class="mut" style="font-size:11px">${r.qty}</span>
            <b style="min-width:58px;text-align:left">${fmt(r.price)}</b></div>`).join('')}
        ${fresh.length > 6 ? `<div class="mut" style="text-align:center;padding:6px;font-size:11.5px">
          و${fresh.length - 6} آخر...</div>` : ''}
      </div>
      <div class="card" style="padding:10px;margin-top:6px">
        <div class="row sp" style="font-size:12.5px">
          <span class="mut">قيمة المخزون المضاف</span>
          <b style="color:var(--or2)">${fmt(addVal)} دج</b></div>
      </div>` : ''}

    ${willUpd ? `
      <b style="font-size:13.5px;display:block;margin:12px 0 6px;color:var(--or2)">
        ✏️ سيُحدَّث (${willUpd})</b>
      <div class="card" style="padding:10px;max-height:150px;overflow-y:auto">
        ${upd.slice(0, 6).map(u => {
          const pc = u.price !== u.oldPrice;
          const qc = u.qty !== u.oldQty;
          return `<div style="padding:6px 0;border-bottom:1px solid var(--line);font-size:12.5px">
            <b>${esc(u.name)}</b>
            <div class="mut" style="font-size:11px;margin-top:2px">
              ${pc ? `السعر: <span style="text-decoration:line-through">${fmt(u.oldPrice)}</span>
                     → <b style="color:var(--or2)">${fmt(u.price)}</b>` : 'السعر: ' + fmt(u.price)}
              ${qc ? ` · الكمية: <span style="text-decoration:line-through">${u.oldQty}</span>
                     → <b style="color:var(--ok)">${u.qty}</b>` : ` · الكمية: ${u.qty}`}
            </div></div>`;
        }).join('')}
        ${upd.length > 6 ? `<div class="mut" style="text-align:center;padding:6px;font-size:11.5px">
          و${upd.length - 6} آخر...</div>` : ''}
      </div>
      ${changed.length === 0 ? `<div class="mut" style="font-size:11.5px;margin-top:6px">
        ℹ️ لا تغيير فعلي — نفس الأسعار والكميات</div>` : ''}` : ''}

    ${errs.length ? `
      <div class="card" style="padding:11px;margin-top:11px;border-color:#5A2A2A">
        <b style="font-size:12.5px;color:var(--dan)">${errs.length} سطر به خطأ</b>
        <div class="mut" style="font-size:11.5px;margin-top:5px">
          ${errs.slice(0, 3).map(e => 'سطر ' + e.line + ': ' + esc(e.why)).join('<br>')}
          ${errs.length > 3 ? '<br>و' + (errs.length - 3) + ' آخر...' : ''}</div>
      </div>` : ''}

    <button class="btn" style="margin-top:12px" onclick="confirmImport()"
      ${(!willAdd && !willUpd) ? 'disabled style="opacity:.5;margin-top:12px"' : ''}>
      ✅ ${willAdd && willUpd ? 'إضافة ' + willAdd + ' وتحديث ' + willUpd
          : willAdd ? 'إضافة ' + willAdd + ' منتج'
          : willUpd ? 'تحديث ' + willUpd + ' منتج' : 'لا شيء لتنفيذه'}</button>
    <button class="btn g sm" style="margin-top:8px" onclick="closeSheet()">إلغاء</button>`);
}

function confirmImport() {
  const fresh = window._impFresh || [];
  const upd = window._impUpd || [];
  const before = PRODS.map(p => ({ ...p }));   // نسخة للتراجع
  let nAdd = 0, nUpd = 0;

  if (impMode !== 'update') {
    fresh.forEach(r => {
      PRODS.push({
        id: uid(), name: r.name, bc: r.bc, price: r.price, cost: r.cost,
        qty: r.qty, min: 5, unit: 'قطعة', cat: r.cat, emo: '📦'
      });
      nAdd++;
    });
  }

  if (impMode !== 'new') {
    upd.forEach(u => {
      const p = PRODS.find(x => x.id === u.id);
      if (!p) return;
      p.price = u.price;
      p.qty = u.qty;
      if (u.cost) p.cost = u.cost;
      if (u.bc && !p.bc) p.bc = u.bc;
      if (u.cat && u.cat !== 'عام') p.cat = u.cat;
      nUpd++;
    });
  }

  if (!save()) { PRODS = before; return; }

  window._impFresh = null; window._impUpd = null;
  closeSheet();
  const msg = [];
  if (nAdd) msg.push('أُضيف ' + nAdd);
  if (nUpd) msg.push('حُدّث ' + nUpd);
  tst('✅ ' + msg.join(' · ') + ' منتج');
  show('s_stock');
}

/* تصدير المنتجات إلى CSV */
function exportProds() {
  if (!PRODS.length) { tst('⚠ لا توجد منتجات'); return; }
  const esc2 = v => {
    const s = String(v === undefined || v === null ? '' : v);
    return /[",;\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  };
  let csv = '\uFEFF' + 'الاسم,الباركود,سعر البيع,سعر الشراء,الكمية,الصنف\n';
  PRODS.forEach(p => {
    csv += [p.name, p.bc || '', p.price, p.cost || 0, p.qty || 0, p.cat || 'عام']
      .map(esc2).join(',') + '\n';
  });
  if (saveFile('منتجات_' + today() + '.csv', csv)) tst('📤 صُدّرت ' + PRODS.length + ' منتج');
}

/* ---------- شاشة الإعدادات الديناميكية ---------- */
function renderMore() {
  // بطاقة الترخيص
  const lc = $('licCard');
  if (lc) {
    if (isPro()) {
      lc.innerHTML = `<div class="card" style="background:linear-gradient(135deg,#2A2416,#1E3F5C);border-color:var(--gold)">
        <div class="row sp" style="margin-bottom:6px">
          <b style="font-size:16px;color:var(--gold)">⭐ حانوت PRO</b>
          <span class="pill">مفعّل</span></div>
        <div class="mut" style="font-size:12px">
          مُفعّل منذ ${LIC.date} · بلا حدود<br>
          الجهاز: <span style="font-family:monospace">${deviceId()}</span></div>
      </div>`;
    } else {
      const d = trialLeft();
      const g = graceLeft();
      const over = trialOver(), grace = inGrace();
      const ttl = over ? '🔴 توقّف التسجيل' : grace ? '⏳ مهلة السماح' : '🎁 نسخة تجريبية';
      const pil = over ? 'منتهية' : grace ? g + (g === 1 ? ' يوم' : ' أيام') : d + ' يوماً';
      lc.innerHTML = `<div class="card" onclick="showUpgrade('ترقية إلى PRO','افتح كل الميزات بلا حدود')"
        style="border-color:${over ? 'var(--dan)' : 'var(--or)'};background:rgba(255,122,41,.07)">
        <div class="row sp" style="margin-bottom:7px">
          <b style="font-size:15px">${ttl}</b>
          <span class="pill ${over ? 'r' : grace ? 'o' : (d > 7 ? 'o' : 'r')}">${pil}</span></div>
        ${grace ? `<div class="mut" style="font-size:11.5px;margin-bottom:6px;color:var(--or2)">
          انتهت التجربة — تعمل الآن بمهلة ${GRACE_DAYS} أيام</div>` : ''}
        ${over ? `<div class="mut" style="font-size:11.5px;margin-bottom:6px;color:var(--dan)">
          التسجيل متوقف · التصفّح والطباعة والنسخ تعمل</div>` : ''}
        <div class="mut" style="font-size:12px;line-height:1.9">
          المنتجات: ${PRODS.length}/${LIMITS.free.prods} · الزبائن: ${CUSTS.length}/${LIMITS.free.custs}<br>
          فواتير اليوم: ${SALES.filter(x => x.date.slice(0,10) === today()).length}/${LIMITS.free.salesPerDay}</div>
        <button class="btn sm" style="margin-top:10px">🔓 ترقية إلى PRO — ${fmt(SELLER.priceP)} دج</button>
      </div>`;
    }
  }
  // أقفال الميزات
  const bl = $('brandLock'); if (bl) bl.innerHTML = isPro() ? '' : '<span class="pill o" style="font-size:9.5px">PRO</span>';
  const il = $('impLock');   if (il) il.innerHTML = isPro() ? '' : '<span class="pill o" style="font-size:9.5px">PRO</span>';
  // معلومات التخزين
  const si = $('stInfo');
  if (si) {
    const p = storagePct();
    const c = p > 90 ? 'var(--dan)' : p > 75 ? 'var(--or2)' : 'var(--mut)';
    si.innerHTML = `<span style="color:${c}">${p.toFixed(0)}% مستعمل · ${SALES.length} فاتورة</span>`;
  }
  // معلومات النسخة الاحتياطية
  const bi = $('bkInfo');
  if (bi) {
    const lb = DB.get('lastBackup', null);
    if (!lb) bi.innerHTML = '<span style="color:var(--or2)">⚠️ لم تحفظ نسخة بعد</span>';
    else {
      const d = Math.floor((Date.now() - new Date(lb)) / 864e5);
      const c = d > 14 ? 'var(--dan)' : d > 7 ? 'var(--or2)' : 'var(--ok)';
      bi.innerHTML = `<span style="color:${c}">${d === 0 ? 'آخر نسخة: اليوم' : 'آخر نسخة منذ ' + d + ' يوماً'}</span>`;
    }
  }
  // الوحدات المخصّصة
  const cu = DB.get('units', []);
  const uc = $('unitsCard');
  if (uc) {
    uc.innerHTML = cu.length ? `<div class="card" style="padding:12px">
      <b style="font-size:13.5px">📏 وحداتك المخصّصة</b>
      <div class="row" style="gap:6px;flex-wrap:wrap;margin-top:8px">
        ${cu.map(u => `<span class="chip" onclick="delUnit('${esc(u)}')">
          ${esc(u)} <span style="color:var(--dan);font-size:11px">✕</span></span>`).join('')}
      </div>
      <div class="mut" style="font-size:11px;margin-top:7px">
        اضغط على الوحدة لحذفها · تُضاف من بطاقة المنتج بزر ＋</div>
    </div>` : '';
  }
  // معلومات المستخدمين
  const ui = $('usInfo');
  if (ui) {
    const us = getUsers();
    ui.innerHTML = us.length
      ? us.length + ' مستخدم' + (USER ? ' · أنت: <b style="color:var(--or2)">' + esc(USER.name) + '</b>' : '')
      : '<span style="color:var(--or2)">معطّل — أي شخص يرى كل شيء</span>';
  }
  // عدد الموردين
  const spi = $('supInfo');
  if (spi) {
    const ns = getSups().length;
    const nop = PRODS.filter(p => !p.sup).length;
    spi.innerHTML = ns
      ? ns + ' مورّد' + (nop ? ` · <span style="color:var(--or2)">${nop} منتج بلا مورّد</span>` : '')
      : 'أضف موردينك لتنظيم الطلبيات';
  }
  // بطاقة الدعم
  const sc = $('supCard'); if (sc) sc.innerHTML = supportCard();
  // رقم الجهاز
  const dt = $('devTag'); if (dt) dt.textContent = 'ID: ' + deviceId();
}

/* ---------- شريط التجربة في الرئيسية ---------- */
function trialBanner() {
  const el = $('trialBar');
  if (!el) return;
  if (isPro()) {
    el.innerHTML = `<div class="card" style="padding:9px 13px;margin-bottom:11px;
      background:linear-gradient(135deg,rgba(224,178,82,.14),rgba(224,178,82,.05));border-color:var(--gold)">
      <div class="row sp"><b style="font-size:12.5px;color:var(--gold)">⭐ النسخة الكاملة PRO</b>
      <span class="mut" style="font-size:11px">مفعّلة</span></div></div>`;
    return;
  }
  const d = trialLeft();
  const g = graceLeft();
  const over = trialOver();
  const grace = inGrace();

  let label, sub, col, bg;
  if (over) {
    label = '🔴 توقّف التسجيل — فعّل للمتابعة';
    sub = 'التصفّح والطباعة والنسخ الاحتياطي تعمل';
    col = 'var(--dan)'; bg = 'rgba(255,92,92,.10)';
  } else if (grace) {
    label = '⏳ مهلة سماح — ' + g + (g === 1 ? ' يوم أخير' : ' أيام');
    sub = 'كل شيء يعمل · بعدها يتوقف تسجيل المبيعات';
    col = 'var(--or)'; bg = 'rgba(255,122,41,.13)';
  } else {
    label = '🎁 نسخة تجريبية — ' + d + (d === 1 ? ' يوم أخير' : ' يوماً متبقياً');
    sub = PRODS.length + '/' + LIMITS.free.prods + ' منتج · '
        + CUSTS.length + '/' + LIMITS.free.custs + ' زبون';
    col = d <= 7 ? 'var(--or)' : 'var(--line)';
    bg = d <= 7 ? 'rgba(255,122,41,.10)' : 'transparent';
  }

  el.innerHTML = `<div class="card" style="padding:10px 13px;margin-bottom:11px;border-color:${col};background:${bg}"
    onclick="showUpgrade('${over ? 'انتهت التجربة والمهلة' : grace ? 'مهلة السماح' : 'النسخة التجريبية'}','${over ? 'فعّل لمواصلة العمل' : 'افتح كل الميزات بلا حدود'}')">
    <div class="row sp">
      <div style="flex:1">
        <b style="font-size:12.5px">${label}</b>
        <div class="mut" style="font-size:11px;margin-top:2px">${sub}</div>
      </div>
      <span class="chip on" style="border:0">🔓 ترقية</span>
    </div></div>`;
}

/* ---------- BOOT ---------- */
buildNav();
(async function boot() {
  try { await migrateToIDB(); } catch (e) { USE_IDB = false; }
  if (CFG) {
    if (lockScreen()) return;      // شاشة الدخول
    applyRole();
    show('s_home');
    setTimeout(() => { trialBanner(); runAutoBackup(); trialWarn(); backupReminder(); }, 400);
  } else {
    show('s_setup');
  }
})();
