/* ============================================================
   حانوت PC v1.0 — وحدة الحاسوب
   قارئ USB · طباعة المتصفح · اختصارات · ملء الشاشة
   ============================================================ */

const PC = true;

/* ============ 1) قارئ الباركود USB ============ */
/*
   قارئ USB (المسدس) يعمل كلوحة مفاتيح:
   يكتب أرقام الباركود بسرعة عالية ثم يضغط Enter.
   الحيلة: نقيس الزمن بين الحروف — الإنسان بطيء والقارئ سريع جداً.
*/
let _sbuf = '';
let _slast = 0;
let _sTimer = null;
let usbEnabled = true;
let usbLastCode = '';
let usbLastAt = 0;

const USB_MAX_GAP = 45;    // أقصى فارق بين حرفين (ميلي ثانية)
const USB_MIN_LEN = 4;     // أقل طول مقبول

function isTypingField(el) {
  if (!el) return false;
  const t = (el.tagName || '').toLowerCase();
  return t === 'input' || t === 'textarea' || t === 'select' || el.isContentEditable;
}

document.addEventListener('keydown', function (e) {
  if (!usbEnabled) return;

  // تجاهل إن كان المستخدم يكتب في حقل (عدا حقول المسح المخصصة)
  const inField = isTypingField(document.activeElement);
  const isScanField = document.activeElement &&
                      document.activeElement.dataset &&
                      document.activeElement.dataset.scan === '1';
  if (inField && !isScanField) return;

  const now = Date.now();
  const gap = now - _slast;
  _slast = now;

  if (e.key === 'Enter') {
    if (_sbuf.length >= USB_MIN_LEN) {
      const code = _sbuf;
      _sbuf = '';
      e.preventDefault();
      onUsbScan(code);
      return;
    }
    _sbuf = '';
    return;
  }

  // حرف واحد فقط (أرقام وحروف)
  if (e.key.length !== 1) return;

  // فارق كبير = إنسان يكتب، ابدأ من جديد
  if (gap > USB_MAX_GAP) _sbuf = '';
  _sbuf += e.key;

  // حماية: صفّر المخزن إن توقّف التدفق
  clearTimeout(_sTimer);
  _sTimer = setTimeout(() => { _sbuf = ''; }, 300);
});

function onUsbScan(code) {
  code = String(code).trim();
  if (!code) return;

  // منع التكرار الفوري
  const now = Date.now();
  if (code === usbLastCode && now - usbLastAt < 600) return;
  usbLastCode = code; usbLastAt = now;

  // تحقق من صحة الباركود (نفس دالة الأندرويد)
  if (typeof validCode === 'function' && !validCode(code)) {
    // قد يكون كوداً داخلياً غير قياسي — نقبله إن وُجد في المخزون
    const known = PRODS.some(p => p.bc === code);
    if (!known) { pcBeep(false); tst('باركود غير صالح: ' + code); return; }
  }

  pcBeep(true);
  pcFlash();

  // إن كانت شاشة المسح المتعدد مفتوحة
  if (typeof multiMode !== 'undefined' && multiMode &&
      $('scanWrap') && $('scanWrap').classList.contains('on')) {
    const p = PRODS.find(x => x.bc === code);
    const ex = multiList.find(m => m.code === code);
    if (ex) ex.qty++;
    else multiList.push({ code, qty: 1, prod: p || null });
    renderMulti();
    return;
  }

  // السلوك حسب الشاشة الحالية
  const p = PRODS.find(x => x.bc === code);

  if (curScr === 's_stock') {
    if (p) openProd(p.id);
    else { tst('منتج جديد: ' + code); openProd(null, code); }
    return;
  }

  // الافتراضي: أضف للسلة
  if (!p) {
    tst('باركود غير مسجّل: ' + code);
    if (confirm('منتج غير مسجّل (' + code + ')\nهل تريد إضافته الآن؟')) {
      openProd(null, code);
    }
    return;
  }

  if (curScr !== 's_pos') show('s_pos');
  addCart(p.id);
  tst('✓ ' + p.name);
}

/* صافرة */
let _pcActx = null;
function pcBeep(ok) {
  try {
    _pcActx = _pcActx || new (window.AudioContext || window.webkitAudioContext)();
    const o = _pcActx.createOscillator(), g = _pcActx.createGain();
    o.connect(g); g.connect(_pcActx.destination);
    o.frequency.value = ok ? 1180 : 380;
    o.type = 'square';
    g.gain.setValueAtTime(0.10, _pcActx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, _pcActx.currentTime + (ok ? 0.10 : 0.22));
    o.start(); o.stop(_pcActx.currentTime + (ok ? 0.10 : 0.22));
  } catch (e) {}
}

/* وميض أخضر أعلى الشاشة */
function pcFlash() {
  let el = $('pcFlash');
  if (!el) {
    el = document.createElement('div');
    el.id = 'pcFlash';
    el.style.cssText = 'position:fixed;top:0;left:0;right:0;height:4px;' +
      'background:var(--ok);z-index:9999;opacity:0;transition:opacity .18s';
    document.body.appendChild(el);
  }
  el.style.opacity = '1';
  setTimeout(() => { el.style.opacity = '0'; }, 220);
}

/* ============ 2) شريط حالة القارئ ============ */
function pcScanBar() {
  const el = $('pcBar');
  if (!el) return;
  el.innerHTML = `
    <div class="row sp" style="padding:7px 14px;background:var(--bg2);
         border-bottom:1px solid var(--line);font-size:12.5px">
      <div class="row" style="gap:9px">
        <span style="color:${usbEnabled ? 'var(--ok)' : 'var(--mut)'}">
          ● قارئ USB ${usbEnabled ? 'جاهز' : 'معطّل'}</span>
        <span class="mut">امسح الباركود مباشرة — لا حاجة للضغط على شيء</span>
      </div>
      <div class="row" style="gap:7px">
        <span class="chip" onclick="toggleUsb()" style="font-size:11px">
          ${usbEnabled ? 'تعطيل' : 'تفعيل'}</span>
        <span class="chip" onclick="startScan('cart')" style="font-size:11px">
          📷 كاميرا</span>
        <span class="chip" onclick="pcHelp()" style="font-size:11px">؟</span>
      </div>
    </div>`;
}

function toggleUsb() {
  usbEnabled = !usbEnabled;
  _sbuf = '';
  pcScanBar();
  tst(usbEnabled ? 'قارئ USB مفعّل' : 'قارئ USB معطّل');
}

/* ============ 3) اختصارات لوحة المفاتيح ============ */
document.addEventListener('keydown', function (e) {
  // تجاهل داخل الحقول
  if (isTypingField(document.activeElement)) {
    if (e.key === 'Escape') document.activeElement.blur();
    return;
  }

  // F1..F6 للتنقل
  const nav = { F1:'s_home', F2:'s_pos', F3:'s_stock',
                F4:'s_debt', F5:'s_rep', F6:'s_more' };
  if (nav[e.key]) { e.preventDefault(); show(nav[e.key]); return; }

  // F9 = دفع نقدي سريع
  if (e.key === 'F9') {
    e.preventDefault();
    if (curScr === 's_pos' && CART.length) openPay();
    return;
  }

  // Escape
  if (e.key === 'Escape') {
    e.preventDefault();
    if ($('scanWrap') && $('scanWrap').classList.contains('on')) { stopScan(); return; }
    if ($('sh') && $('sh').classList.contains('on')) { closeSheet(); return; }
    if (curScr !== 's_home') show('s_home');
    return;
  }

  // Delete = تفريغ السلة
  if (e.key === 'Delete' && curScr === 's_pos' && CART.length) {
    e.preventDefault();
    if (confirm('تفريغ السلة؟')) { clearCart(); renderPos(); }
    return;
  }

  // Ctrl+P طباعة آخر فاتورة
  if (e.ctrlKey && e.key.toLowerCase() === 'p') {
    e.preventDefault();
    if (lastSale) { buildReceipt(lastSale); show('s_rcpt'); setTimeout(doPrint, 300); }
    return;
  }

  // Ctrl+S نسخة احتياطية
  if (e.ctrlKey && e.key.toLowerCase() === 's') {
    e.preventDefault();
    expJSON();
    return;
  }

  // Ctrl+F بحث في نقطة البيع
  if (e.ctrlKey && e.key.toLowerCase() === 'f') {
    e.preventDefault();
    if (curScr === 's_pos' && $('pos_q')) $('pos_q').focus();
    if (curScr === 's_stock' && $('st_q')) $('st_q').focus();
    return;
  }
});

function pcHelp() {
  sheet(`<div class="grab"></div>
    <h2 style="margin-bottom:12px">⌨️ اختصارات لوحة المفاتيح</h2>

    <div class="card" style="padding:13px">
      <b style="font-size:13.5px">التنقل</b>
      ${[['F1','الرئيسية'],['F2','نقطة البيع'],['F3','المخزون'],
         ['F4','الديون'],['F5','التقارير'],['F6','الإعدادات']]
        .map(k => `<div class="row sp" style="padding:5px 0;font-size:13px">
          <span class="mut">${k[1]}</span>
          <b style="font-family:monospace;background:var(--bg2);
             padding:2px 9px;border-radius:6px">${k[0]}</b></div>`).join('')}
    </div>

    <div class="card" style="padding:13px">
      <b style="font-size:13.5px">العمليات</b>
      ${[['F9','دفع سريع'],['Delete','تفريغ السلة'],['Esc','رجوع / إغلاق'],
         ['Ctrl+P','طباعة آخر فاتورة'],['Ctrl+S','نسخة احتياطية'],
         ['Ctrl+F','بحث']]
        .map(k => `<div class="row sp" style="padding:5px 0;font-size:13px">
          <span class="mut">${k[1]}</span>
          <b style="font-family:monospace;background:var(--bg2);
             padding:2px 9px;border-radius:6px">${k[0]}</b></div>`).join('')}
    </div>

    <div class="card" style="padding:13px;border-color:var(--or)">
      <b style="font-size:13.5px;color:var(--or2)">🔌 قارئ الباركود USB</b>
      <div class="mut" style="font-size:12.5px;line-height:1.9;margin-top:6px">
        وصّل القارئ بمنفذ USB — يعمل فوراً بلا إعداد.<br>
        امسح أي باركود في أي شاشة، والمنتج يُضاف للسلة تلقائياً.<br>
        لا تحتاج للنقر في أي حقل قبل المسح.<br><br>
        <b style="color:var(--tx)">في شاشة المخزون:</b>
        المسح يفتح بطاقة المنتج للتعديل.
      </div>
    </div>`);
}

/* ============ 4) الطباعة على الحاسوب ============ */
function pcPrint(html) {
  const w = window.open('', '_blank', 'width=420,height=650');
  if (!w) { tst('اسمح بالنوافذ المنبثقة للطباعة'); return; }
  w.document.write(html);
  w.document.close();
  w.focus();
  setTimeout(() => { w.print(); }, 400);
}

/* ============ 5) تكييف الواجهة للشاشة الكبيرة ============ */
function pcLayout() {
  document.body.classList.add('pc');
  // شريط القارئ أعلى الشاشة
  if (!$('pcBar')) {
    const bar = document.createElement('div');
    bar.id = 'pcBar';
    document.body.insertBefore(bar, document.body.firstChild);
  }
  pcScanBar();
}

/* ============ 6) الإقلاع ============ */
window.addEventListener('DOMContentLoaded', function () {
  setTimeout(() => {
    pcLayout();
    // تذكير بالنسخ الاحتياطي على الحاسوب أيضاً
    if (typeof backupReminder === 'function') backupReminder();
  }, 300);
});
